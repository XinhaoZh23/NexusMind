# 调试日志：修复 `reset_dev_db.sh` 脚本

**故障现象**:
在运行 `bash scripts/reset_dev_db.sh` 时，脚本在中途失败，并输出以下错误信息：
```
unable to find user nexusmind_user: no matching entries in passwd file
```

**根本原因分析**:
该错误由 `docker exec -u nexusmind_user ...` 命令引起。该命令试图在 `nexusmind_postgres` 容器内部切换到名为 `nexusmind_user` 的 **Linux 系统用户**，但该系统用户在容器中并不存在（容器的默认用户是 `postgres`）。而 `docker-compose.yml` 中定义的 `POSTGRES_USER: nexusmind_user` 创建的是一个 **PostgreSQL 数据库角色**，而非一个 Linux 系统用户。

---

## 调试步骤

### 步骤 1：修正脚本中的数据库连接用户

- **计划**:
    1.  打开 `scripts/reset_dev_db.sh` 文件。
    2.  找到执行 `psql` 的那一行。
    3.  移除错误的 `-u nexusmind_user` 参数，该参数是针对 `docker exec` 的。
    4.  为 `psql` 命令本身添加正确的 `-U nexusmind_user` 参数，以指定数据库连接的用户。
    5.  同时，为了清晰，修改该行上方的注释，使其准确反映实际情况。

- **记录**:
  ```
  <!-- 此处将记录修改后的命令和结果 -->
  ```
- **最终状态**:
    - **修改后的文件**: `scripts/reset_dev_db.sh`
    - **关键代码行**: `docker exec "$CONTAINER_NAME" psql -U nexusmind_user -d "$DB_NAME" -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"`
    - **测试命令**: `bash scripts/reset_dev_db.sh`
    - **测试结果**:
      ```
      --- Resetting Development Database ---
      ✅ Docker container 'nexusmind_postgres' is running.
      ⏳ Dropping and recreating the 'public' schema...
      NOTICE:  drop cascades to 3 other objects
      DETAIL:  drop cascades to table alembic_version
      drop cascades to type filestatusenum
      drop cascades to table file
      CREATE SCHEMA
      ✅ 'public' schema has been reset.
      ⏳ Applying all database migrations...
      INFO  [alembic.runtime.migration] Context impl PostgresqlImpl.
      INFO  [alembic.runtime.migration] Will assume transactional DDL.
      INFO  [alembic.runtime.migration] Running upgrade  -> c1a696167488, Create initial tables
      ✅ All migrations have been applied.
      --- Database reset complete! ---
      ```
- **结论**: 故障已成功修复。 