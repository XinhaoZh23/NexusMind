# 开发日志: 15a - 全栈 Docker 集成与 Nginx 部署

本文档记录了 `docs/15a_DOCKER_INTEGRATION_FULLSTACK.md` 中定义的任务的实现过程、遇到的问题和解决方案。

## 2023-10-27

### 任务 1: 为 Node.js 网关创建 Dockerfile

*   **状态**: `已完成`
*   **操作**:
    1.  在 `websocket_gateway/` 目录下创建了一个 `Dockerfile`。
    2.  该文件基于 `node:18-alpine` 镜像。
    3.  实现了标准的 Node.js 应用容器化流程：设置工作目录、复制 `package.json`、安装依赖、复制源代码、暴露端口并设置启动命令。
*   **测试建议**:
    *   在项目根目录下，打开终端，进入 `websocket_gateway` 目录：`cd websocket_gateway`
    *   执行 Docker 构建命令：`docker build -t nexusmind-websocket-gateway .`
    *   **预期结果**: 该命令应该能够成功执行，无任何报错信息，并最终显示 "Successfully tagged nexusmind-websocket-gateway:latest"。这证明 Dockerfile 语法正确，并且所有依赖都能被成功安装。
*   **结论**: 用户测试通过。任务完成。

### 任务 2: 为 React 前端创建生产 Dockerfile

*   **状态**: `已完成`
*   **操作**:
    1.  在 `frontend/` 目录下创建了一个 `Dockerfile.prod`。
    2.  该 Dockerfile 采用了多阶段构建技术，以优化最终镜像的大小和安全性。
    3.  **构建阶段**: 使用 `node:18-alpine` 镜像来安装依赖并执行 `npm run build`，生成静态文件。
    4.  **生产阶段**: 使用 `nginx:1.21-alpine` 镜像，并仅将构建阶段生成的静态文件复制到 Nginx 服务目录中。
*   **测试建议**:
    *   在项目根目录下，打开终端，进入 `frontend` 目录：`cd frontend`
    *   执行 Docker 构建命令：`docker build -t nexusmind-frontend -f Dockerfile.prod .`
    *   **预期结果**: 该命令应该能成功执行。您会看到它先执行 `npm install` 和 `npm run build`，然后切换到 Nginx 镜像并完成构建。最终会显示 "Successfully tagged nexusmind-frontend:latest"。
*   **结论**: `测试失败`。

#### 任务 2.1: 修复生产构建失败问题

*   **状态**: `已完成`
*   **问题描述**: `docker build` 命令在执行 `npm run build` 步骤时失败。日志显示了多个 `TS6133` 错误。
*   **根本原因**: TypeScript 在生产构建模式下，将“未使用的变量/导入”视为致命错误。
*   **解决方案**:
    1.  编辑 `src/App.tsx`，移除了未使用的导入。
    2.  编辑 `src/components/FileUpload.tsx`，移除了未使用的 `response` 变量。
    3.  编辑 `src/hooks/useWebSocket.ts`，移除了未使用的 `SOCKET_URL` 常量。
*   **结论**: 用户测试通过。任务完成。

### 任务 3: 创建 Nginx 配置文件

*   **状态**: `已完成`
*   **操作**:
    1.  在项目根目录创建了 `nginx/` 文件夹。
    2.  在 `nginx/` 文件夹内创建了 `nginx.conf` 文件。
    3.  该配置文件定义了三个核心的路由规则：
        *   `/` -> 提供 React 前端的静态文件。
        *   `/api/` -> 反向代理到 `nexusmind-api` 服务 (端口 `5001`)。
        *   `/ws/` -> 反向代理 WebSocket 连接到 `websocket-gateway` 服务 (端口 `8080`)。
*   **测试建议**:
    *   这个配置文件本身无法直接测试，它的正确性将在下一步，当我们把所有服务整合进 `docker-compose.yml` 并启动时得到验证。因此，这一步没有独立的测试命令。
*   **结论**: 文件已创建，等待下一步集成。

### 任务 4: 更新 `docker-compose.yml`

*   **状态**: `进行中`
*   **操作**:
    1.  对 `docker-compose.yml` 进行了重大更新，以整合所有服务。
    2.  **添加了 `nginx` 服务**:
        *   作为应用的统一入口，将主机的 `80` 端口映射到容器的 `80` 端口。
        *   使用 `frontend/Dockerfile.prod` 构建，负责提供 React 应用的静态文件。
        *   挂载 `nginx/nginx.conf` 以实现反向代理。
        *   设置了 `depends_on` 来确保它在后端服务启动后再启动。
    3.  **添加了 `websocket-gateway` 服务**:
        *   使用 `websocket_gateway/Dockerfile` 构建。
        *   在 Docker 内部网络与 Nginx 通信，无需对主机暴露端口。
    4.  **修改了 `nexusmind-api` 服务**: 移除了其 `ports` 映射，所有流量现在由 Nginx 统一管理。
    5.  **移除了 `minio` 服务**: 暂时移除了 `minio` 及其相关配置，以使本次任务聚焦于 Nginx 整合。
*   **测试进展**:
    *   **2023-10-27**:
        *   执行 `docker compose up --build -d` 命令成功。
        *   **问题**: 后端 `nexusmind-api` 和 `nexusmind_worker` 容器进入 `Restarting` (崩溃循环) 状态。
        *   **诊断**: 查看 `docker logs nexusmind_api`，发现 Pydantic 抛出 `ValidationError`，因为代码强制加载 `MinioConfig`，但在环境中找不到必须的 `MINIO_ENDPOINT` 环境变量。
        *   **根本原因**: 代码与环境配置不一致。`docker-compose.yml` 移除了 `minio` 服务及其环境变量，但 `src/nexusmind/config.py` 仍然强制要求这些配置。
*   **修复计划**:
    1.  修改 `src/nexusmind/config.py`，将 `minio` 配置项变为可选。
    2.  只有在检测到 `MINIO_ENDPOINT` 环境变量存在时，才尝试加载 `MinioConfig`。
*   **结论**:
    *   **2023-10-27 (续)**:
        *   代码修复后，执行 `docker compose down --remove-orphans` 和 `docker compose up --build -d`。
        *   `docker ps` 命令显示所有容器，包括 `nexusmind-api` 和 `nexusmind_worker`，均处于稳定的 `Up` 状态。崩溃循环问题已解决。
        *   **端到端测试-1**: API 路由 (`/api/*`) 和 WebSocket 路由 (`/ws/*`) 经测试均已通过 Nginx 成功代理，核心通信功能正常。
        *   **问题**: 前端应用加载失败，浏览器控制台报错 `Failed to load module script: ... MIME type of "text/plain"`.
        *   **诊断**: Nginx 配置缺少 MIME 类型定义，导致 `.js` 文件被错误地当作纯文本文件提供给浏览器。
*   **结论**:
    *   **2023-10-27 (续)**:
        *   代码修复后，所有容器均稳定运行。
        *   **端到端测试-1**: API 和 WebSocket 路由通过 Nginx 成功代理。
        *   **问题**: 前端加载失败，浏览器持续报 `MIME type of "text/plain"` 错误。
        *   **诊断-1 (失败)**: 在 `nginx.conf` 中添加 `include /etc/nginx/mime.types;` 并重启服务后，问题依旧。
        *   **诊断-2 (被证伪)**: 执行 `docker exec nexusmind_nginx ls -l /etc/nginx/` 后发现，`mime.types` 文件确实存在于该路径。因此“路径不正确”的推论是错误的。
        *   **诊断-3 (被证伪)**: `cat` 命令显示容器内的 `nginx.conf` 内容正确，证明配置文件已正确加载。
        *   **诊断-4 (被证伪)**: `vite.config.ts` 显示 Vite 默认构建目录就是 `dist`。
        *   **最终诊断**: 经过逐一排除，唯一剩下的可能性是 Docker 多阶段构建中的 `COPY --from=build` 命令虽然语法正确，但由于缓存或其他底层原因，实际上未能成功将 `build` 阶段的产物复制到 `nginx` 阶段。
*   **结论**:
    *   **2023-10-27 (最终)**:
        *   在 `frontend/Dockerfile.prod` 中加入 `RUN ls -R /app/dist` 强制生成构建产物后，MIME type 错误得到解决，前端框架成功加载。
        *   **新问题**: 浏览器控制台报告 `GET /api/brains 502 (Bad Gateway)` 和 WebSocket 连接失败。
        *   **诊断**: `502` 错误表明 Nginx 无法从上游的 `nexusmind-api` 服务获取有效响应。这通常意味着后端服务虽然容器已启动，但其内部应用进程可能已崩溃或无法正常处理请求。
*   **修复计划**:
    1.  **验证**: 再次使用 `docker ps -a` 确认所有容器的健康状况，并使用 `docker logs nexusmind_api` 和 `docker logs nexusmind_nginx` 深入检查后端和代理的日志，以定位根本原因。
*   **下一步**: 等待用户提供最新的容器状态和日志。

### 任务 5: 端到端测试与最终修复

*   **状态**: `已完成`
*   **问题描述-1**: API 服务 (`nexusmind_api`) 启动后反复崩溃，导致前端报 `502 Bad Gateway`。
    *   **根本原因**: `docker-compose.yml` 移除了 `minio` 服务，但 `main.py` 仍然无条件地尝试初始化 S3 客户端，导致在 `config.minio` 为 `None` 时抛出 `AttributeError`。
    *   **解决方案**: 修改 `main.py`，在 `on_startup` 函数中加入 `if config.minio:` 判断，仅在配置存在时才初始化 S3 客户端。
*   **问题描述-2**: WebSocket 仍然无法连接。
    *   **根本原因**: 前端 `useWebSocket.ts` 中 Socket.IO 的连接路径是 `/socket.io/`，而 Nginx 的反向代理监听的是 `/ws/` 路径，两者不匹配。
    *   **解决方案**: 修改 `useWebSocket.ts`，将连接路径改为 `/ws/socket.io/`，与 Nginx 配置统一。
*   **问题描述-3**: 聊天时无法收到 LLM 回复。
    *   **根本原因**: `websocket-gateway` 容器尝试连接硬编码的 `localhost:8000` 来访问 API 服务，但在 Docker 网络中，`localhost` 指向其自身而非 `nexusmind-api` 容器。
    *   **解决方案**:
        1.  修改 `websocket_gateway/index.js`，使其从环境变量 `FASTAPI_URL` 和 `API_KEY` 读取配置。
        2.  修改 `docker-compose.yml`，为 `websocket-gateway` 服务注入这两个环境变量，并指向正确的内部服务地址 `http://nexusmind-api:5001/chat`。
*   **最终测试**:
    *   **状态**: `测试通过`
    *   **结果**: 用户确认，在 `http://localhost` 可以正常加载应用，API 和 WebSocket 通信均正常，并且能够根据不同的大脑上下文收到正确的 LLM 回复。
*   **结论**: `15a` 任务中定义的所有目标均已实现。整个全栈应用已成功通过 Docker 和 Nginx 集成，并可在单一入口下协同工作。项目达到一个重要的部署里程碑。 