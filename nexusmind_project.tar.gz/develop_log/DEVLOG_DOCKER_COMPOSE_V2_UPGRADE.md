# 开发日志: 升级 Docker Compose v2

本文档记录了将 `docker-compose` (Standalone) 升级到 `docker compose` (Plugin) 的过程，以从根本上解决 `KeyError: 'ContainerConfig'` 的兼容性问题。

## 1. 检查当前版本

*   **任务**: 确认当前 Docker 引擎和 `docker-compose` v1 的确切版本。
*   **目的**: 了解系统环境，确保升级路径正确。
*   **状态**: 完成 (Completed)
*   **结果**:
    *   `Docker version 27.5.1, build 27.5.1-0ubuntu3~22.04.2`
    *   `docker-compose version 1.29.2, build unknown`
*   **分析**: Docker 引擎版本现代，而 `docker-compose` 是存在兼容性问题的 v1 版本。

## 2. 安装 Docker Compose v2

*   **任务**: 通过 `apt` 包管理器安装 Docker Compose v2 插件。
*   **目的**: 为系统添加现代、集成的 Docker Compose 功能。
*   **状态**: 失败 (Failed)
*   **结果**: `sudo apt-get install docker-compose-plugin` 命令失败，返回 `E: Unable to locate package docker-compose-plugin`。
*   **分析**: 这个错误表明系统中没有配置 Docker 官方的 APT 软件包仓库。系统默认的 Ubuntu 软件源不包含 `docker-compose-plugin` 这个包。

## 3. 配置 Docker 官方 APT 仓库

*   **任务**: 按照官方流程，添加 Docker 的 GPG 密钥并设置其 APT 仓库。
*   **目的**: 使 `apt` 工具能够找到并安装来自 Docker 官方的软件包。
*   **状态**: 完成 (Completed)
*   **结果**: `sudo apt-get update` 的输出中成功包含了来自 `download.docker.com` 的条目，证明仓库已配置成功。

## 4. 再次尝试安装 Docker Compose v2

*   **任务**: 在配置好官方仓库后，再次尝试安装 `docker-compose-plugin`。
*   **目的**: 完成最终的升级。
*   **状态**: 完成 (Completed)
*   **结果**: `sudo apt-get install docker-compose-plugin` 命令成功执行，安装了 `docker-compose-plugin` 和 `docker-buildx-plugin`。

## 5. 验证新版本并清理

*   **任务**: 验证 `docker compose` v2 命令是否可用，并卸载旧的 v1 版本以避免混淆。
*   **目的**: 确保系统环境干净，只存在一个 `compose` 命令。
*   **状态**: 失败 (Failed)
*   **结果**:
    *   `docker compose version` 成功返回 v2 版本。
    *   `sudo pip uninstall docker-compose` 失败，错误为 `Not uninstalling docker-compose at /usr/lib/python3/dist-packages`。
*   **分析**: `pip` 出于安全考虑，拒绝卸载由系统包管理器 (`apt`) 安装的软件包。我们必须使用 `apt` 来卸载旧版的 `docker-compose`。

## 6. 使用 APT 清理旧版本

*   **任务**: 使用 `apt-get remove` 命令来正确卸载旧版的 `docker-compose`。
*   **目的**: 彻底清理环境，避免新旧版本命令冲突。
*   **状态**: 完成 (Completed)
*   **结果**:
    *   `sudo apt-get remove docker-compose` 成功卸载了 v1。
    *   `docker compose version` 验证了 v2 的存在。
    *   `docker-compose --version` 确认了 v1 命令已被移除。
*   **结论**: Docker Compose V2 升级任务圆满完成。系统环境现在是干净、现代且一致的。 