# 调试日志: 12b - 'ContainerConfig' 错误复现问题排查

## 背景

在通过 `git reset` 将项目恢复到一个已知的健康状态后，我们开始了 `12b` 监控功能的开发。然而，在仅仅添加了 `starlette-exporter` 依赖并修改了 `main.py` 之后，再次运行 `docker-compose up --build` 时，我们遇到了之前已经解决过的 `KeyError: 'ContainerConfig'` 错误。

这个错误与应用代码无关，是 Docker Compose 在重建容器时的内部错误。它的复现表明问题根源在于我们的开发工作流与 Docker 环境状态管理的交互方式。

**核心假设**:
`docker-compose` (v1) 的状态管理存在不稳定性。`docker-compose up -d` 创建的运行中容器，其元数据可能被后续的 `docker-compose run` 命令所破坏，导致在下一次 `up` (重建) 时失败。

---

## 步骤 1: 验证通过清理环境可临时解决问题

**目标**: 证明问题的直接原因确实是损坏的 Docker 容器状态，通过彻底清理环境可以暂时恢复正常。

*   **操作**: 执行 `docker-compose down --volumes` 命令。
*   **目的**: 停止并删除所有容器、网络和数据卷，将 Docker 环境恢复到一个完全干净的初始状态。这会消除当前已损坏的容器状态。
*   **状态**: 已完成 (Done)
*   **结果**: 命令成功执行，所有相关的 Docker 对象都已被彻底清除。

---

## 步骤 2: 从干净状态启动以验证修复 (已完成)

**目标**: 验证在清除了损坏的 Docker 状态后，包含了 `starlette-exporter` 相关修改的应用能够正常启动。

*   **操作**: 执行 `docker-compose up --build -d` 启动所有服务，然后通过 `curl` 测试 `/metrics` 端点。
*   **目的**: 如果此操作成功，则证明我们对问题的根本原因（Docker 状态损坏）的诊断是正确的。
*   **状态**: 已完成 (有新错误)
*   **结果**: `ContainerConfig` 错误消失，服务成功创建。然而，`curl` 命令返回 `Connection refused`。

---

## 步骤 3: 检查应用日志以定位崩溃原因 (已完成)

**目标**: 找到导致 `nexusmind-api` 容器启动失败的 Python 应用代码错误。

*   **操作**: 执行 `docker-compose logs nexusmind-api` 命令。
*   **结果**: 日志明确显示 `ModuleNotFoundError: No module named 'starlette_exporter'`。
*   **分析**: 应用在启动时因无法导入 `starlette_exporter` 模块而崩溃。根本原因是 Docker 在执行 `docker-compose up --build` 时，错误地使用了 `poetry install` 步骤的缓存层，导致新添加的依赖没有被安装到最终的镜像中。

---

## 步骤 4: 强制重新构建镜像 (不使用缓存) - 失败

**目标**: 解决 `ModuleNotFoundError`。

*   **操作**: 使用 `docker-compose up --build --no-cache -d` 命令。
*   **目的**: 强制 Docker 重新构建镜像并启动服务。
*   **状态**: 失败 (Failed)
*   **结果**: 命令失败。`docker-compose` 打印了 `up` 命令的帮助文档后退出，因为 `--no-cache` 不是 `up` 命令的有效参数。
*   **分析**: 这是一个命令语法错误。我们必须将“构建”和“启动”分开，以便正确使用 `--no-cache` 标志。

---

## 步骤 5: 分步执行：强制无缓存构建，然后启动

**目标**: 采用正确的命令语法，真正解决 `ModuleNotFoundError`。

### 5.1: 强制无缓存构建

*   **操作**: 执行 `docker-compose build --no-cache`。
*   **目的**: 这将强制 Docker 重新构建 `nexusmind-api` 服务的镜像，忽略所有缓存层，确保 `poetry install` 会被重新执行。
*   **状态**: 已完成 (Done)
*   **结果**: 命令成功执行，新的 `nexusmind-api` 镜像已构建。

### 5.2: 启动服务并测试

*   **操作**: 在成功构建后，执行 `docker-compose up -d`。
*   **状态**: 失败 (Failed)
*   **结果**: 命令再次因 `KeyError: 'ContainerConfig'` 而失败。
*   **最终分析**: 问题的根源极度顽固。这证明了 `docker-compose` 的内部状态管理存在严重问题。即使在无缓存构建了一个新镜像后，`up` 命令在尝试“替换”旧容器时，依然会因为读取到损坏的旧容器元数据而崩溃。我们不能再依赖 `up` 命令来自动处理容器的替换。

---

## 步骤 6: 最终解决方案：彻底清理后，再从零启动

**目标**: 采用最彻底的流程，绕过 `docker-compose` 的状态管理缺陷，最终成功启动服务。

### 6.1: 再次彻底清理环境

*   **操作**: 执行 `docker-compose down --volumes`。
*   **目的**: 这是至关重要的一步。在**每一次**尝试启动前，我们都必须手动、彻底地清除所有旧的容器和状态，确保接下来的 `up` 命令是在一个完全空白的环境中执行“创建”，而不是在一个可能已损坏的环境中执行“替换”。
*   **状态**: 已完成 (Done)
*   **结果**: 命令成功执行，环境已彻底清理。

### 6.2: 从零开始启动并最终测试

*   **操作**: 在彻底清理后，执行 `docker-compose up --build -d && sleep 15 && curl http://localhost:8000/metrics`。
*   **目的**: 在一个完全干净的环境中构建并启动服务。由于不存在需要“替换”的旧容器，`ContainerConfig` 错误将不再有触发的条件。
*   **状态**: 失败 (Failed)
*   **结果**: `ContainerConfig` 错误没有出现，容器成功创建。但是，`curl` 命令返回 `Connection refused`。
*   **分析**: 成功绕过了 `ContainerConfig` 错误，但应用本身启动失败。构建日志显示 `poetry install` 步骤使用了缓存，极有可能导致 `starlette_exporter` 依赖未能安装，从而引发 `ModuleNotFoundError` 并导致容器崩溃。

---

## 步骤 7: 解决构建缓存问题并最终启动

**目标**: 采用最彻底的流程，强制重新安装依赖，并最终成功启动服务。

### 7.1: 确认应用崩溃日志

*   **操作**: 执行 `docker-compose logs nexusmind-api`。
*   **目的**: 获取应用容器的实际错误日志，以确认它是否如我们所料，因为 `ModuleNotFoundError` 而崩溃。
*   **状态**: 已完成 (Done)
*   **结果**: 日志明确显示 `ModuleNotFoundError: No module named 'starlette_exporter'`。这完全证实了我们的猜想：Docker 构建缓存导致依赖未安装，应用启动时崩溃。

### 7.2: 强制无缓存构建并最终启动

*   **操作**:
    1.  `docker-compose down --volumes` (再次清理，确保无旧容器状态残留)
    2.  `docker-compose build --no-cache` (强制重新构建，忽略缓存)
    3.  `docker-compose up -d` (启动服务)
    4.  `sleep 15 && curl http://localhost:8000/metrics` (最终测试)
*   **目的**: 通过强制重新构建来解决 `ModuleNotFoundError`，并最终成功启动所有服务。
*   **状态**: 待办 (To-Do) 