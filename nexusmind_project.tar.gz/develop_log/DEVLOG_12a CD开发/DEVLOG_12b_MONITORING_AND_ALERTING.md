# 第 12b 步：实现应用监控与告警

## 任务目标

为我们的 FastAPI 应用集成基本的监控和可观测性能力。这包括一个健康检查端点，以及通过 Prometheus 和 Grafana 实现的性能指标监控。

## 提示词 (Prompt)

"为了在生产环境中监控我们的应用，我们需要实现以下功能：

1.  **健康检查端点**:
    *   在 FastAPI 应用 (`main.py` 或你的 API router 中) 添加一个新的路由 `/health`。
    *   这个端点应该非常简单，只返回一个 HTTP 200 OK 状态码和一个 JSON 响应，例如 `{"status": "ok"}`。这用于外部服务（如负载均衡器或 uptime 监控器）检查应用是否正在运行。

2.  **暴露 Prometheus 指标**:
    *   将 `starlette-exporter` 这个库添加到你的项目依赖中 (`poetry add starlette-exporter`)。
    *   在 FastAPI 的中间件 (middleware) 中，集成 `starlette-exporter`，让它在 `/metrics` 路径上自动暴露一系列标准的性能指标（如请求延迟、请求总数、错误数等）。

3.  **设置监控基础设施**:
    *   在项目根目录创建一个 `docker-compose.monitoring.yml` 文件。
    *   在该文件中，定义两个新的服务：`prometheus` 和 `grafana`。
    *   **Prometheus 服务**:
        *   使用官方的 `prom/prometheus` 镜像。
        *   创建一个 `prometheus.yml` 配置文件，将其挂载到容器中。这个配置文件需要包含一个抓取任务（scrape job），用于定期从我们的 FastAPI 应用的 `/metrics` 端点拉取数据。请注意，在 Docker 网络中，Prometheus 需要通过 `host.docker.internal:8000` 或服务名 `api:8000` 来访问 API 服务，而不是 `localhost`。
    *   **Grafana 服务**:
        *   使用官方的 `grafana/grafana` 镜像。
        *   将 Grafana 服务暴露在 `3000` 端口。
        *   可以预先配置一个数据源，使其自动连接到 `prometheus` 服务。
        *   （可选）可以预先配置一个仪表盘（Dashboard）的 JSON 文件，用于可视化 `/metrics` 端点收集到的关键指标。"

## 测试方法

**测试计划**：
1.  **启动所有服务**:
    *   使用命令 `docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up --build` 同时启动应用和监控服务。
2.  **验证端点**:
    *   在浏览器或使用 `curl` 访问 `http://localhost:8000/health`。**断言**：应返回 `{"status": "ok"}` 和 200 状态码。
    *   访问 `http://localhost:8000/metrics`。**断言**：应返回一个文本格式的、符合 Prometheus 规范的指标列表。
3.  **配置并验证 Grafana**:
    *   访问 `http://localhost:3000` 打开 Grafana。默认用户名/密码通常是 `admin`/`admin`。
    *   **断言**：你应该能成功登录。
    *   导航到 "Connections" -> "Data sources"，确认 Prometheus 数据源已存在且连接正常。
    *   导航到 "Dashboards"，创建一个新的仪表盘。添加一个图表（Panel），选择 Prometheus 作为数据源，然后在查询（query）字段中输入一个指标名称（例如 `starlette_requests_total`）。
    *   **断言**：图表上应该能显示出数据。可以向你的 API 发送一些请求，观察图表上的数据变化，以确认整个监控链路是通的。 

- 经过漫长的调试，最终定位到问题根源是在 `src/nexusmind/base_config.py` 文件中，`PostgresConfig` 类的 `host` 字段被硬编码为 `"localhost"`。这个配置在之前的裸机开发环境中可以工作，但在 Docker Compose 的网络环境中是错误的。
- **解决方案**: 将该硬编码值修正为正确的服务名 `"postgres"`。
- **状态**: 修复已应用。通过 `sudo docker-compose up -d --build` 重启服务后，`curl http://localhost:8000/health` 已成功返回 `{"status":"ok"}`。本地开发环境的容器化问题已彻底解决。

### 下一步

继续执行 `12b_MONITORING_AND_ALERTING.md` 中的测试计划，验证下一个端点。

### 验证 /metrics 端点失败

- **进展**: `/health` 端点验证成功。
- **问题**: 执行 `curl http://localhost:8000/metrics` 返回 `{"detail":"Not Found"}`。
- **分析**: 这个 FastAPI 的标准错误表明 `/metrics` 这条路由根本没有在应用中被注册。根据任务要求，这个路由应该由 `starlette-exporter` 中间件自动创建。因此，最可能的原因是我们忘记了将这个中间件添加到 FastAPI 应用中。
- **下一步**: 检查 `main.py` 文件，确认 `starlette-exporter` 中间件是否已被正确添加。

### 解决 /metrics 端点缺失问题

- **发现**: 经检查 `main.py` 文件，确认了问题原因：代码中完全没有添加 `starlette-exporter` 中间件的逻辑。
- **解决方案**: 需要在 `main.py` 中导入 `PrometheusMiddleware`，并将其添加到 FastAPI 应用实例 `app` 中。这将自动创建 `/metrics` 端点。
- **下一步**: 修改 `main.py` 文件以集成该中间件。

### 解决 `ModuleNotFoundError` 并成功验证

- **进展**: 在 `main.py` 中添加了中间件后，应用启动失败，日志显示 `ModuleNotFoundError: No module named 'starlette_exporter'`。
- **分析**: 这是因为我们忘记了将 `starlette-exporter` 添加到项目的依赖中。
- **解决方案**: 执行 `poetry add starlette-exporter` 添加了缺失的依赖。
- **状态**: 在添加依赖并使用 `sudo docker-compose down` 和 `sudo docker-compose up -d --build` 重启服务后，`curl http://localhost:8000/metrics` 已成功返回 Prometheus 指标。`/health` 和 `/metrics` 端点均已验证通过。

### 创建监控配置文件

- **问题**: 执行 `docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up` 命令失败，错误为 `FileNotFoundError`。
- **分析**: 这是我的疏忽。我忘记了指导创建 `docker-compose.monitoring.yml` 和 `prometheus.yml` 这两个文件，它们是启动监控服务所必需的。
- **下一步**: 创建这两个配置文件，然后重新尝试启动服务。

### 解决 `ContainerConfig` 状态错误

- **问题**: 在创建了监控配置文件后，执行 `docker-compose up` 命令再次失败，抛出 `KeyError: 'ContainerConfig'` 错误。
- **分析**: 这是一个环境状态问题，而非代码或配置错误。`docker-compose up` 命令试图“重新创建”一个已存在的、处于不稳定状态的 `nexusmind_api` 容器，导致其在读取旧配置时失败。
- **解决方案**: 唯一的可靠方法是先用 `down` 命令彻底清理所有服务，然后再用 `up` 命令在一个干净的环境中启动它们。
- **下一步**: 执行 `down` 和 `up` 命令。

### 解决本地端口冲突并访问 Grafana

- **问题**: 即便所有远程服务都已成功启动，在本地浏览器通过端口转发访问 `localhost:3000` 时，看到的仍然是一个不相关的 "Open WebUI" 登录页面。
- **分析**: 用户提出了一个关键的洞察：问题根源在于本地的 Windows 电脑，而非远程服务器。本地的 `3000` 端口已被一个本地运行的服务 ("Open WebUI") 占用。这导致 SSH 端口转发无法绑定到本地的 `3000` 端口，所有浏览器请求都被这个本地服务拦截，永远无法到达远程的 Grafana 容器。
- **解决方案**: 修改 VS Code 中的端口转发规则，将远程的 `3000` 端口映射到一个本地未被占用的端口，例如 `3001`。
- **下一步**: 在本地浏览器中访问新的转发地址 `http://localhost:3001`，登录 Grafana 并验证数据源。

### 手动配置 Grafana 数据源

- **问题**: 成功登录 Grafana 后，发现“Data sources”列表为空，没有预期的 Prometheus 数据源。
- **分析**: 这是因为 `docker-compose.monitoring.yml` 文件中没有包含为 Grafana 自动配置数据源的逻辑。因此，我们需要手动在 Grafana UI 中完成此项配置。
- **下一步**: 手动添加 Prometheus 作为数据源，并验证其连通性。

### 任务完成：监控系统验证成功

- **状态**: 成功在 Grafana 中手动添加了 Prometheus 数据源。在配置页面中，使用地址 `http://prometheus:9090` 进行“Save & test”，获得了“Successfully queried the Prometheus API”的成功提示。
- **结论**: 整条监控链路（API -> Prometheus -> Grafana）已全部打通。
- **下一步**: 在 Grafana 中创建一个简单的仪表盘来可视化一个指标，作为最终的功能性验证。

### 下一步

继续执行 `12b_MONITORING_AND_ALERTING.md` 中的测试计划，配置并验证 Grafana。 