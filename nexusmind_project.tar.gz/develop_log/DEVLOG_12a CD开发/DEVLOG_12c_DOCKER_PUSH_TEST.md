# 开发日志：12a - 测试 Docker 镜像推送

**目标**: 验证 CI/CD 流水线中的 Docker 镜像构建和推送功能是否正常工作。

**相关文件**: `.github/workflows/ci.yml`

---

## 当前状态

我们已经在 `.github/workflows/ci.yml` 的 `deploy` 作业中添加了以下步骤：
*   使用 `docker/login-action@v3` 登录到 Docker Hub。
*   使用 `docker/build-push-action@v5` 构建 Docker 镜像并将其推送到 Docker Hub。

## 测试步骤详解

请完全按照以下步骤操作，以测试我们的修改。

### 第 1 步：在 GitHub 配置 Secrets (如果尚未配置)

1.  在你的 GitHub 仓库页面，点击 **Settings** -> **Secrets and variables** -> **Actions**。
2.  点击 **New repository secret** 按钮，创建以下两个秘密：
    *   `DOCKER_USERNAME`: 你的 Docker Hub 用户名。
    *   `DOCKER_PASSWORD`: 你的 Docker Hub 密码或访问令牌 (Access Token)。

### 第 2 步：在本地提交并推送代码

在你的终端中，依次执行以下命令，将我们刚刚的修改推送到 GitHub。

```bash
# 1. 将 ci.yml 文件的修改添加到暂存区
git add .github/workflows/ci.yml

# 2. 创建一个提交，并附带清晰的说明
git commit -m "feat: add docker build and push to CI"

# 3. 将代码推送到 GitHub 远程仓库
git push
```

### 第 3 步：检查 GitHub Actions 运行状态

1.  代码推送后，打开你的 GitHub 仓库页面。
2.  点击页面顶部的 **Actions** 标签。
3.  你会看到一个新的工作流正在运行。点击进入这个工作流。
4.  在左侧，你会看到 `build_and_lint`、`test` 和 `deploy` 三个作业。
5.  **验证**: `build_and_lint` 和 `test` 作业成功后，`deploy` 作业会自动开始。点击 `deploy` 作业，确认 "Log in to Docker Hub" 和 "Build and push Docker image" 这两个步骤都成功完成（显示绿色对勾）。

### 第 4 步：在 Docker Hub 验证镜像

1.  打开浏览器，访问 [Docker Hub](https://hub.docker.com/) 并登录。
2.  **验证**: 你应该能看到一个名为 `nexusmind` 的新镜像仓库（如果你的 Docker Hub 用户名是 `testuser`，那么仓库全名是 `testuser/nexusmind`）。
3.  点击进入该仓库，查看它的标签（Tags）。
4.  **验证**: 你应该能看到两个新的标签：`latest` 和一个由 Git commit SHA 组成的长字符串标签。

---

请在完成以上所有步骤后，告诉我测试结果。如果任何步骤失败，请将 GitHub Actions 中的错误日志链接或截图发给我。 