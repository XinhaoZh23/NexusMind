# 开发日志：12f - SSH 连接 Secrets 配置指南

**目标**: 理解并配置部署所需的 SSH 相关 GitHub Secrets。

---

## 状态更新

*   **完成**: `ci.yml` 和 `docker-compose.yml` 已更新，加入了最终部署的逻辑。
*   **阻塞**: 需要配置 `SSH_HOST`, `SSH_USERNAME`, `SSH_PRIVATE_KEY` 这三个 Secrets 才能进行下一步。
*   **确认**: 用户猜测正确，这些 SSH 信息指向的是我们希望部署应用的目标服务器。

## Secrets 详解与获取方法

为了让 GitHub Actions 能够自动登录你的服务器并执行部署脚本，我们需要为它提供 SSH 连接凭证。

### 1. `SSH_HOST`

*   **用途**: 你目标服务器的 IP 地址或域名。
*   **如何获取**: 查看你平时使用的 `ssh` 命令，它是 `@` 符号后面的部分。
    *   *示例*: `ssh myuser@123.45.67.89` -> `SSH_HOST` 是 `123.45.67.89`。

### 2. `SSH_USERNAME`

*   **用途**: 你登录目标服务器时使用的用户名。
*   **如何获取**: 查看你平时使用的 `ssh` 命令，它是 `@` 符号前面的部分。
    *   *示例*: `ssh myuser@123.45.67.89` -> `SSH_USERNAME` 是 `myuser`。

### 3. `SSH_PRIVATE_KEY`

*   **用途**: SSH 私钥，是允许 GitHub Actions 免密登录服务器的“数字钥匙”。
*   **如何获取**:
    1.  在你的 **本地电脑** (你用来发起 SSH 连接的机器) 打开终端。
    2.  执行命令 `cat ~/.ssh/id_rsa` 来显示你的私钥内容。
    3.  **完整地复制** 其输出内容，必须包含 `-----BEGIN...-----` 和 `-----END...-----` 这两行。
    4.  将复制的完整内容粘贴到 GitHub Secret `SSH_PRIVATE_KEY` 的值中。

---

**下一步**:
1.  请根据以上指南，在你的 GitHub 仓库 `Settings -> Secrets and variables -> Actions` 中创建并填入这三个 Secrets。
2.  确保你的目标服务器上 `~/nexusmind` 目录中，有最新的 `docker-compose.yml` 和 `.env` 文件。
3.  完成准备后，即可通过合并 PR 到 `main` 分支来触发完整的 CI/CD 流程并进行最终测试。 