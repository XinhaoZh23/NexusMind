# 开发日志：第 12a 步 - 建立 CD (持续部署) 流水线

**目标**: 将现有的 CI 流水线升级为包含 CD 的完整 CI/CD 流水线，实现代码合并到 `main` 分支后自动部署。

**相关文档**: [docs/12a_CD_PIPELINE.md](docs/12a_CD_PIPELINE.md)

---

## 开发步骤与记录

### 准备工作

- [ ] 阅读并完全理解 `12a_CD_PIPELINE.md` 中的任务目标和所有提示。
- [ ] 确认已在 GitHub 仓库中配置好以下 Secrets:
    - [ ] `DOCKER_USERNAME`
    - [ ] `DOCKER_PASSWORD`
    - [ ] `SSH_HOST`
    - [ ] `SSH_USERNAME`
    - [ ] `SSH_PRIVATE_KEY`

### 步骤 1：修改 CI/CD 工作流文件

- [ ] 打开 `.github/workflows/ci.yml` 文件。
- [ ] 在 `test` 作业之后，添加一个新的作业，命名为 `deploy`。
- [ ] **配置 `deploy` 作业**:
    - [ ] 设置 `if: github.ref == 'refs/heads/main'`，确保只在 `main` 分支上运行。
    - [ ] 设置 `needs: test`，确保 `deploy` 作业在 `test` 作业成功后才开始。
    - [ ] 设置 `runs-on: ubuntu-latest`。
- **记录**:
  ```
  <!-- 记录对 yml 文件的修改 -->
  ```

### 步骤 2：实现构建和推送 Docker 镜像

- [ ] 在 `deploy` 作业中，添加以下步骤：
    - [ ] **登录 Docker Hub**: 使用 `docker/login-action@v2`，并传入 `DOCKER_USERNAME` 和 `DOCKER_PASSWORD` 秘密。
    - [ ] **构建并推送**: 使用 `docker/build-push-action@v4`，配置好镜像名称、`latest` 和 Git SHA 标签，并推送到 Docker Hub。
- **记录**:
  ```
  <!-- 记录具体的 action 配置 -->
  ```

### 步骤 3：实现远程服务器部署

- [ ] 在 `deploy` 作业中，构建步骤之后，添加以下步骤：
    - [ ] **执行远程部署**: 使用 `appleboy/ssh-action@master`。
    - [ ] 配置 `host`, `username`, `key` 等参数，传入对应的 GitHub Secrets。
    - [ ] 在 `script` 部分，编写需要在服务器上执行的命令，例如：
        ```bash
        cd /path/to/your/project
        docker-compose pull
        docker-compose up -d
        ```
- **记录**:
  ```
  <!-- 记录 SSH action 的配置和脚本命令 -->
  ```

### 步骤 4：测试完整的 CI/CD 流水线

- [ ] 将修改后的 `.github/workflows/ci.yml` 文件提交并推送到一个特性分支。
- [ ] 创建一个 Pull Request，将其合并到 `main` 分支。
- [ ] **验证**:
    - [ ] 在 GitHub Actions 页面，观察到 `test` 作业成功后，`deploy` 作업被触发并成功执行。
    - [ ] 登录 Docker Hub，验证带有 `latest` 和 Git SHA 标签的新镜像已被推送。
    - [ ] SSH 登录到服务器，验证服务已是最新版本。
- **记录**:
  ```
  <!-- 记录最终测试的结果 -->
  ```

### 最终提交

- [ ] 将修改后的 `.github/workflows/ci.yml` 文件添加到暂存区。
- [ ] 创建一个清晰的 `git commit`。 