# 开发日志: 15b - 混合 MVP 部署 (Hybrid MVP Deployment) 至 AWS

## 任务目标

将 15a 中完成的全栈 Docker 化应用，以一种兼具速度与简历亮点的混合模式部署到 AWS。此方案将使用 AWS 托管的数据库 (RDS) 和缓存 (ElastiCache) 服务，同时将应用本身容器化部署在一台 EC2 服务器上，最终实现一个稳定、可演示、易于迭代的生产级 MVP (最小可行产品)。

## 前置要求

必须首先完成 `docs/15a_DOCKER_INTEGRATION_FULLSTACK.md` 中定义的所有任务。本地的全栈 Docker 环境必须能够通过 `docker-compose up` 成功运行，并通过 Nginx 统一入口访问。

## 1. 基础设施准备：配置 AWS 托管服务

### 1.1 创建 RDS PostgreSQL 数据库实例

*   **状态**: `已完成`
*   **产出**:
    *   **Endpoint**: `nexusmind-prod-db.cduy4ksmo4pb.us-east-2.rds.amazonaws.com`
*   **任务描述**: 登录 AWS 管理控制台，使用 RDS 服务创建一个新的 PostgreSQL 数据库实例。在创建过程中，需要设置主用户名和密码，并选择合适的实例规格。创建完成后，记录下数据库实例的 Endpoint (主机地址)、端口、用户名和密码。
*   **测试方法**:
    *   **连接性测试**: `已通过`。在开发服务器上，使用 `psql` 命令行工具成功连接到了 RDS 实例。安全组已正确配置，允许来自服务器 IP 的访问。
    *   **断言**: 必须能够成功建立连接。这验证了数据库实例已正常运行，并且其网络配置（如安全组）允许来自本地环境的访问。

### 1.2 创建 ElastiCache Redis 实例

*   **状态**: `已完成`
*   **产出**:
    *   **Endpoint**: `master.nexusmind-prod-redis.ougqj6.use2.cache.amazonaws.com`
*   **任务描述**: 登录 AWS 管理控制台，使用 ElastiCache 服务创建一个新的 Redis (Cluster Mode Disabled) 集群。创建完成后，记录下 Redis 实例的 Primary Endpoint (主机地址) 和端口。
*   **测试方法**:
    *   **连接性测试**: `已通过`。在重建集群并修正所有网络配置后，在 EC2 服务器上使用 `redis-cli` PING 命令成功返回 `PONG`。
    *   **故障排查日志**:
        *   **阶段一：定位测试环境** - 初步在本地开发机测试连接，返回 `Network is unreachable`，确诊必须在 EC2 服务器内部进行测试。
        *   **阶段二：解决 SSH 访问** - 尝试 SSH 登录 EC2 服务器失败，连接超时。经排查，发现用于连接的公网 IP 地址不正确。修正 IP 后，再次因安全组未对当前 IP 开放 22 端口而失败。最终通过在安全组中设置正确的 SSH 源 IP，成功登录 EC2 服务器。
        *   **阶段三：解决客户端工具** - 在 EC2 上执行 `redis-cli` 命令时，提示 `command not found`。通过 `sudo apt install redis-tools` 成功安装了客户端。
        *   **阶段四：排查安全组** - 从 EC2 连接 Redis 依然超时。检查发现，EC2 与 Redis 共用同一个安全组 (`sg-0d8bf158d28a11a2f`)。该安全组的 Redis (6379端口) 规则的源是外部 IP，而非其自身。已修正该规则，将源设置为安全组 ID 本身，允许组内成员互相通信。
        *   **阶段五：排查子网与路由** - 连接依然超时。检查 ElastiCache 的子网组，确认 EC2 实例所在的子网 (`subnet-07fc32eb6cdfb1eab`) 已包含在内，排除了跨子网的路由问题。
        *   **阶段六：排查网络 ACL** - 检查与子网关联的网络 ACL (`acl-0d9c6509d2feff9d0`)，确认其入站和出站规则均为默认的“全部允许”，排除了网络 ACL 的问题。
        *   **最终诊断**: 在系统性地排除了所有网络层面的配置错误后（安全组、子网、网络ACL），唯一剩下的可能性是 ElastiCache Redis 实例自身处于某种不可恢复的异常状态。
    *   **解决方案**:
        1.  **删除并重建**: 决定采用删除并重建 ElastiCache 集群的方案来解决此问题。
        2.  **应对新版UI**: 在重建过程中发现，AWS 新版UI强制在创建时启用“传输中加密(TLS)”，且无法在创建时选择安全组。
        3.  **新策略**: 采用“先创建，后修改”的策略。首先使用“标准创建”流程完成集群创建，然后立即进入修改页面，手动将“传输中加密”禁用，并确认安全组为我们已配置好的共享安全组 (`sg-0d8bf158d28a11a2f`)。
    *   **最终结果**: 重建并正确配置后，连接测试成功。
    *   **断言**: 在 `redis-cli` 中执行 `PING` 命令应返回 `PONG`。这验证了 Redis 实例已正常运行，并且其网络配置允许访问。

### 1.3 创建并配置 EC2 服务器

*   **状态**: `已完成`
*   **任务描述**: 使用 AWS EC2 服务，启动一台新的 Linux 虚拟服务器（推荐 Amazon Linux 2 或 Ubuntu）。在此服务器上，需要安装最新版本的 Docker 和 Docker Compose。同时，配置其关联的安全组，预先开放 80 端口 (HTTP) 和 22 端口 (SSH) 的入站访问。
*   **测试方法**:
    *   **SSH 连接测试**: `已通过`。已成功通过 SSH 连接到 EC2 实例。
    *   **Docker & Docker Compose 版本验证**: `已通过`。`docker --version` 和 `docker compose version` 命令均成功返回版本号，无权限错误。
    *   **断言**: 两个命令都应成功返回版本号，无报错。这证明了应用运行所需的基础环境已准备就绪。

## 2. 应用配置改造：适配生产环境

### 2.1 管理生产环境变量

*   **状态**: `已完成`
*   **任务描述**: 在项目根目录中，创建一个 `.env.prod` 文件，用于专门存放生产环境的敏感信息。将之前步骤中获取的 RDS 数据库和 ElastiCache Redis 的连接信息（主机、端口、用户、密码）填入此文件。同时，也需要包含生产环境的 `API_KEY` 和其他必要的配置。此文件**绝对不能**提交到 Git 仓库，应将其路径添加到 `.gitignore` 文件中。
*   **测试方法**:
    *   **文件存在性与忽略验证**: `已通过`。`.env.prod` 文件已在本地创建，并且 `git status` 的输出中不包含此文件，证明其已被 `.gitignore` 规则正确忽略。
    *   **断言**: `git status` 的输出中不应包含 `.env.prod` 文件。这证明了敏感配置不会被意外泄露。

### 2.2 使应用支持多环境配置

*   **状态**: `已完成`
*   **任务描述**: 修改后端应用的配置加载逻辑（可能位于 `src/nexusmind/config.py` 或类似文件），使其能够根据一个特定的环境变量（例如 `APP_ENV=production`）来决定是加载本地的 `.env` 文件还是生产的 `.env.prod` 文件。
*   **当前任务 (Step 2.2):** 我们正处于 **`2.2 使应用支持多环境配置`** 的**起点**。
*   **进展更新 (TDD "Red" Phase)**:
    *   **步骤 1 (创建失败测试)**: 已创建 `tests/test_config.py` 并添加 `test_initial_config_loading_fails_without_env` 测试用例，预期在无环境变量时抛出 `ValidationError`。
    *   **步骤 2 (意外成功)**: 运行测试后发现，测试意外失败，原因为“未抛出 ValidationError”。这证明了 `pytest-dotenv` 插件自动加载了项目根目录的 `.env` 文件，导致配置成功创建，与测试意图相悖。
    *   **步骤 3 (隔离环境)**: 使用 `patch.dict` 成功创建了隔离的测试环境。再次运行测试，按预期得到了 `AttributeError`，这证明了 `get_core_config` 函数缺少缓存装饰器，我们的“红灯”测试已准备就绪。
    *   **步骤 4 (修复缓存)**: 为 `get_core_config` 添加 `@lru_cache` 装饰器后，之前的“无配置”测试成功通过，但暴露了由于缓存导致的测试间状态污染问题。
    *   **步骤 5 (最终修复)**: 通过在每个测试中强制清除缓存 (`cache_clear()`) 并使用 `monkeypatch` fixture 来独立设置环境变量，最终实现了所有配置单元测试的完全隔离和通过。

**核心思想：** 不再让 Python 代码内部去判断加载哪个 `.env` 文件，而是将这个责任交给外部工具（Docker Compose 和 Pytest）。代码本身只负责从环境变量中读取配置，保持简单。
*   **测试方法**:
    *   **单元测试**: `已通过`.
    *   **问题分析**: `已确认`。错误堆栈跟踪明确指出，问题发生在 `CoreConfig` 类定义被加载时，其内部的 `PostgresConfig()` 被立即执行，早于 `get_core_config` 函数中加载 `.env` 文件的逻辑。
    *   **进展更新**: 使用 `Field(default_factory=...)` 的修正方案成功解决了“过早实例化”的问题。测试用例现在可以被 Pytest `collected 2 items`。然而，两个测试在执行时均失败，抛出与之前相同的 `ValidationError`，表明即使在运行时，嵌套的 `PostgresConfig` 模型也未能从指定的 `.env` 文件中读取到配置。
    *   **二次分析**: 添加 `env_nested_delimiter='__'` 的尝试并未改变错误输出。这验证了一个关键点：`env_nested_delimiter` 机制主要用于将**环境变量**映射到嵌套模型，但它并**不会**指导嵌套的 `BaseSettings` 子模型（如 `PostgresConfig`）从父模型指定的 `.env` 文件中读取配置。子模型在被 `default_factory` 创建时，仍然是一个独立的、不知道 `.env` 文件上下文的配置对象，因此无法找到任何值。
    *   **三次分析与突破**: 将嵌套配置类改为继承 `BaseModel` 并更新测试 `.env` 文件后，测试失败情况发生变化：
        *   `test_loads_prod_env_when_app_env_is_production` (生产环境测试) 的失败原因从 `PostgresConfig` 变成了 `RedisConfig`。**这是一个重大突破**，它证明了 `tests/.env.prod` 文件被成功加载，并且 `POSTGRES__*` 变量被正确解析，`PostgresConfig` 成功创建！失败转移到 `RedisConfig` 是因为我们尚未在测试文件中提供其所需变量。
        *   `test_loads_dev_env_by_default` (开发环境测试) 的失败原因**仍然是 `PostgresConfig`**。这强烈表明，测试运行时未能找到或正确读取 `tests/.env` 这个文件。
    *   **四次分析与最终定位**: 在为测试`.env`文件补充`REDIS__*`变量后，两个测试的失败原因均转移为`CoreConfig`自身的`ValidationError`（缺少`storage_base_path`等字段）。这最终证明：
        1.  嵌套配置加载机制 (`env_nested_delimiter`) 已完全正常工作。
        2.  `tests/.env` 和 `tests/.env.prod` 文件现在都已被成功找到并读取。
        3.  当前唯一的遗留问题是在测试`.env`文件中缺少`CoreConfig`自身的必要变量。
*   **五次分析与最终解决**: 补充所有顶层变量后，`ValidationError`完全消失。新的错误为 `AttributeError: 'PostgresConfig' object has no attribute 'db_host'`。这明确地暴露出问题是一个简单的笔误：测试代码中断言的属性名 `db_host` 与 `PostgresConfig` 模型中定义的实际属性名 `host` 不符。配置加载流程已完全打通。
*   **六次分析与最终胜利**: 修正笔误后，`test_loads_dev_env_by_default`测试**成功通过**。但`test_loads_prod_env_when_app_env_is_production`测试失败，断言错误显示它仍然加载了开发环境的配置。这明确地将问题定位在`@lru_cache`上：缓存导致`get_core_config`在第二次调用时返回了第一次的旧结果，无视了`APP_ENV`的变化。
*   **七次分析与根源定位**: 在测试fixture中添加`cache_clear()`后，测试结果**没有任何变化**。这最终证明了问题的根源在于`get_core_config`函数的设计本身。它是一个**非纯函数**，其返回值不依赖于输入参数（它没有参数），而是依赖于一个外部的、隐藏的全局状态（`os.getenv`）。无论是`@lru_cache`还是我们手写的缓存，都无法在这种设计下可靠地工作，因为对于缓存系统来说，每次无参数的调用都是完全相同的，它无法感知到外部环境变量的变化。
*   **八次分析与回归修正**: 将`get_core_config`纯函数化并简化测试后，测试重新失败并退回至`ValidationError`。错误日志显示，新的路径计算逻辑错误地将项目根目录定位到`src/`，导致无法找到任何`.env`文件。最终问题被确认为`os.path.dirname`层级计算错误。
*   **九次分析与最终谜题**: 修正路径问题后，测试结果再次回到“1 passed, 1 failed”的状态，`AssertionError`表明生产环境测试仍然错误地加载了开发环境的配置。这证明了将函数“纯化”并重新使用`@lru_cache`的方案**同样失败了**。这个反常的结果表明，问题的根源并非我们之前所想的任何一种缓存策略，而是一个更底层的、导致`get_core_config(app_env="production")`的调用结果被错误覆盖的未知机制。
*   **十次分析与真相大白**: 通过隔离实验，单独运行生产环境测试，结果依然失败。这**彻底推翻了**关于“状态污染”的假设。失败断言 `assert 'localhost-dev' == 'remote-prod-db'` 证明，即便是 `get_core_config(app_env="production")` 这个调用本身，返回的也是从 `.env` 文件加载的配置。这揭示了问题的最终根源：Pydantic `BaseSettings` 在其复杂的初始化流程中，可能存在某种形式的**首次加载锁定**或内部类级别缓存，导致一旦 `CoreConfig` 类被首次用于加载某个 `.env` 文件后，后续即便传入不同的 `_env_file` 路径，也无法覆盖其初次加载的数据源。
*   **最终方案：回归标准实践**: 鉴于无法在代码运行时可靠地切换`.env`文件源，最终决定采用行业标准实践——“关注点分离”。将环境切换的责任从Python代码中剥离，交由启动应用的基础设施（Pytest, Docker Compose）负责。Python代码将被简化，只负责加载默认的`.env`文件，而测试和生产环境将通过各自的工具配置来确保正确的环境变量被加载。
*   **最终修正**: 在安装`pytest-dotenv`后，测试依然失败。警告日志 `Unknown config option: dotenv_files` 明确指出 `pytest.ini` 中的配置键名错误。正确的键名应为 `env_files`。修正此笔误是解决问题的最后一步。
*   **最终胜利**: 修正 `pytest.ini` 中的笔误后，`poetry run pytest tests/test_config.py` 命令成功执行，测试通过。这标志着应用已成功改造为由基础设施（Pytest）负责注入环境变量的模式，彻底解决了多环境配置的难题。
*   **回归测试失败**: 运行完整的 `poetry run pytest` 测试套件时，在测试收集阶段 `tests/test_api.py` 抛出 `AttributeError: 'RedisConfig' object has no attribute 'redis_host'`。这暴露出之前的配置重构存在疏漏：`RedisConfig`模型中的字段已从`redis_host`改为`host`，但代码中使用该配置的地方（如`celery_app.py`）未被同步更新。
*   **最终测试失败与根源定位**: 修正 `celery_app.py` 后，`test_config.py` 依然通过，但 `test_api.py` 中的多个测试在建立数据库连接时抛出 `OperationalError: could not translate host name "localhost-dev" to address`。这最终定位到问题根源：`tests/.env` 文件中的主机名（如 `localhost-dev`）是为 Docker 网络环境设计的，在直接于本地主机运行的 Pytest 环境中无法被解析。
*   **最终根源暴露**: 在修正`tests/.env`后，测试在收集阶段再次失败，抛出`ValidationError`，提示缺少`minio`相关字段。这最终暴露出两个深层问题：1. `config.py`中存在一个过时的`@validator("minio", ...)`，它与Pydantic的嵌套加载机制冲突，导致`minio`配置无法被正确解析。2. `celery_app.py`中使用了`CoreConfig()`直接实例化，而非统一的`get_core_config()`函数，破坏了配置加载的单例模式。
*   **CI/CD 测试失败与最终诊断**: 在本地通过所有测试后，GitHub Actions 中的 `pytest` 运行失败，再次抛出 `ValidationError`，提示 `PostgresConfig` 缺少所有必需字段。这最终定位到问题的核心：CI/CD 环境是纯净的，它不会包含任何本地的 `.env` 文件。尽管本地的 `pytest` 通过 `pytest-dotenv` 和 `tests/.env` 文件可以成功运行，但这个 `.env` 文件并未（也不应该）提交到 Git 仓库。因此，当 `pytest` 在 CI 环境中收集 `test_api.py` 时，其导入链条在模块加载时就触发了配置实例化，但由于没有任何环境变量注入，导致验证失败，测试在收集阶段就宣告崩溃。
*   **手动验证**:
        1.  在本地终端中，通过设置环境变量并运行应用来测试，例如：`APP_ENV=production poetry run uvicorn ...`
        2.  观察应用启动日志。
    *   **断言**: 应用启动时不应出现配置相关的错误，并且如果有日志打印，应显示连接的是远程 RDS 数据库。

### 3. 部署与启动

#### 3.1 修改 Docker Compose 文件

*   **状态**: `已完成`
*   **任务描述**: 复制一份 `docker-compose.yml` 并重命名为 `docker-compose.prod.yml`。编辑这个新的生产用编排文件，将 `postgres` 和 `redis` 这两个服务**完全移除**，因为它们的功能已经被 AWS 的 PaaS 服务替代。
*   **测试方法**:
    *   **文件语法验证**: `已通过`。在 EC2 服务器上运行 `docker compose -f docker-compose.prod.yml config` 命令成功输出了完整的配置，确认了文件语法无误。
*   **断言**: 该命令应能成功解析文件并打印出最终的配置，无任何语法错误。这证明了编排文件的结构是正确的。

### 3.2 部署代码并启动应用

*   **状态**: `已完成`
*   **任务描述**: 将整个项目代码（除了 `.git`, `node_modules` 等）以及 `.env.prod` 文件安全地上传到之前创建的 EC2 服务器上。在服务器的项目根目录中，执行 `docker compose -f docker-compose.prod.yml --env-file .env.prod up -d --build` 命令来构建并启动所有应用服务。
*   **进展**:
    *   `.env.prod` 文件已通过 `scp` 安全上传至 EC2 服务器。
    *   `docker compose up --build` 命令已成功执行，所有服务的镜像构建成功，容器已全部启动。
*   **测试方法**:
    *   **容器状态检查**: `已失败`。`docker ps` 命令输出为空，`docker ps -a` 显示所有容器均在启动后立即 `Exited (1)`。
    *   **日志检查**:
        *   `api-server` 日志显示 `ModuleNotFoundError: No module named 'nexusmind'`。
        *   `worker` 日志显示 `ModuleNotFoundError: No module named 'nexusmind'`。
    *   **根本原因分析**: `ModuleNotFoundError` 表明在容器内，Python 解释器无法找到位于 `/app/src` 目录下的 `nexusmind` 模块。这很可能是因为 `/app/src` 目录没有被添加到 Python 的模块搜索路径 (`PYTHONPATH`) 中。
*   **验证过程**:
    1.  通过 `docker run -it --rm ubuntu-api-server bash` 进入临时容器。
    2.  直接运行 `python -c "from nexusmind.brain.brain import Brain"` 成功复现了 `ModuleNotFoundError: No module named 'nexusmind'`，并确认 `/app/src` 不在 `sys.path` 中。
    3.  运行 `PYTHONPATH=$PYTHONPATH:/app/src python -c ...` 后，错误变为 `ModuleNotFoundError: No module named 'pydantic'`。这证明 `PYTHONPATH` 的修正是有效的（Python 已能找到 `nexusmind` 模块），新的错误是由于在交互式测试中未激活 Poetry 虚拟环境导致的，从而验证了 `PYTHONPATH` 是根本问题。
*   **第二次失败分析**:
    1.  将修正后的 `Dockerfile` 上传至 EC2 并重新构建后，所有容器依然 `Exited (1)`。
    2.  `ubuntu-websocket-gateway-1` 的日志明确指出 `FATAL ERROR: The FASTAPI_URL and API_KEY environment variables must be set.`。
    3.  **根本原因定位**: 这表明为服务间通信定义的架构级环境变量（如 `FASTAPI_URL`）没有在生产环境中被设置。这些变量不属于应放在 `.env.prod` 文件中的敏感信息，因此在启动时被遗漏了。
*   **第三次失败分析**:
    1.  修正 `websocket-gateway` 的环境变量并重新构建后，`api-server` 和 `nginx` 依然启动失败。
    2.  `api-server` 的日志显示 `ERROR: Error loading ASGI app. Could not import module "src.main"`.
    3.  **根本原因定位**: 在 `Dockerfile` 中添加 `ENV PYTHONPATH ...:/app/src` 后，Python 的模块搜索根路径变为了 `/app/src`。因此，`uvicorn` 的启动命令需要从 `src.main:app` 相应地调整为 `main:app`，以匹配新的模块路径。
*   **第四次失败分析**:
    1.  修正所有服务的启动命令和代码导入路径后，`api-server`, `worker`, `websocket-gateway` 均成功启动，但 `nginx` 启动失败。
    2.  `nginx` 日志显示 `[emerg] host not found in upstream "nexusmind-api:5001"`。
    3.  **根本原因定位**: `nginx/nginx.conf` 配置文件中硬编码了错误的上游服务地址和端口。正确的主机名应为 `api-server` (Compose 中的服务名)，端口应为 `8000`。
*   **第五次失败分析**:
    1.  修正 `nginx.conf` 并重新部署后，所有服务均启动失败。
    2.  `api-server` 日志显示 `ImportError: cannot import name 'File' from 'nexusmind.files.file'`.
    3.  `websocket-gateway` 日志显示 `FATAL ERROR: The FASTAPI_URL and API_KEY environment variables must be set.`。
    4.  **根本原因定位 (双重问题)**:
        *   **`api-server`**: 存在笔误。`brain.py` 尝试 `import File`，而正确的类名是 `NexusFile`。
        *   **`websocket-gateway`**: 配置文件回滚。在部署过程中，上传的 `tar` 包覆盖了已修改的 `docker-compose.prod.yml`，导致其回退到缺少 `environment` 定义的旧版本。
*   **第六次失败分析**:
    1.  在修正所有已知问题并重新部署后，除 `websocket-gateway` 外所有服务均成功启动。
    2.  **根本原因定位**: 最终的配置统一方案移除了 `websocket-gateway` 服务中的 `environment` 定义，但其需要的 `FASTAPI_URL` 变量并不存在于 `.env.prod` 文件中，导致其无法获取该必要的非敏感配置而启动失败。
*   **第七次失败分析 (前端部署问题)**:
    1.  在修正所有后端服务配置并集成前端构建流程后，所有容器均成功启动。
    2.  然而，浏览器访问公网 IP 依然显示 Nginx 默认欢迎页。
    3.  **初步推测**: Nginx 容器未能从 `frontend_build` 共享卷中正确加载由 `frontend` 服务构建的前端静态文件。
    4.  **验证**: 通过 `docker exec` 进入 `nginx` 容器，确认了 `/usr/share/nginx/html` 目录为空。通过 `docker logs` 查看 `frontend` 服务日志，发现它错误地启动了一个 Nginx 服务器，而不是执行构建。
    5.  **根本原因定位**: `frontend/Dockerfile.prod` 采用了“构建并服务”一体化的多阶段构建，其最终产物是一个独立的 Web 服务器，而不是我们架构所期望的、只包含静态文件的“数据容器”。这导致 `frontend_build` 卷为空。
*   **第八次失败分析 (前端部署问题)**:
    1.  在使用优化的、纯构建的多阶段 `Dockerfile.prod` 重新部署后，浏览器访问公网 IP 依然显示 Nginx 默认欢迎页。
    2.  **初步推测**: 尽管 `Dockerfile.prod` 已被修正为生成一个包含静态文件的数据容器，但 `frontend` 服务容器的文件系统内容未能通过 `frontend_build` 共享卷成功传递给 `nginx` 服务。
*   **最终解决方案**:
    1.  保留 `frontend/Dockerfile.prod` 的多阶段构建优势。
    2.  修改其第二阶段，不再使用 `nginx` 镜像，而是使用一个极度轻量化的 `alpine` 镜像。
    3.  第二阶段的唯一任务是从第一阶段（构建阶段）复制出构建好的静态文件，从而生成一个纯粹的、小巧的“数据容器”，完美适配我们现有的“关注点分离”架构。
*   **最终部署成功**: 在修正所有已知问题后，`docker compose up -d` 命令成功启动了所有服务。`docker ps` 命令确认 `api-server`, `worker`, `websocket-gateway`, `nginx` 四个容器全部稳定运行。
*   **断言**: 应该能看到 `api-server`, `worker`, `websocket-gateway`, `nginx` 对应的容器都处于 `Up` (运行中) 状态。
*   **日志检查**: 分别使用 `docker logs [container_name]` 命令检查每个容器的启动日志。
*   **断言**: `api-server` 和 `worker` 的日志中不应有连接数据库或 Redis 失败的错误。`nginx` 的日志应显示已成功启动并监听 80 端口。

## 4. 端到端验证

### 4.1 验证应用可访问性与核心功能

*   **状态**: `进行中`
*   **任务描述**: 这是最终的验收测试。通过 EC2 的公网 IP 地址或配置好的域名，在浏览器中访问应用。
*   **进展**:
    *   **重大突破**: 导入问题已解决。`docker ps` 命令确认 `api-server` 容器在修复后能够成功启动并保持 `Up` 状态。
    *   **新问题**: 浏览器开发者控制台依然显示 `502 Bad Gateway` 错误。这表明 `api-server` 在处理 API 请求时遇到了一个新的、我们之前未见的**运行时错误**。
    *   **回归失败**: 在对代码进行修复并重新部署后，`api-server` 依然因为旧的 `ModuleNotFoundError` 而启动失败。这表明代码修复未能成功应用到最终运行的容器中，问题可能出在文件同步或 Docker 镜像构建缓存上。
*   **测试方法**:
    *   **场景模拟**:
        1.  在浏览器中打开 `http://[EC2_Public_IP]`。
        2.  创建一个新的大脑。
        3.  上传一个文件到该大脑。
        4.  与该大脑进行聊天，提出与上传文件相关的问题。
    *   **断言**:
        1.  网页前端界面能被正确加载。
        2.  创建大脑的请求成功，新大脑出现在列表中。
        3.  文件上传成功，文件出现在文件列表中（检查浏览器开发者工具的网络请求，确认请求路径是 `/api/upload`）。
        4.  WebSocket 连接成功建立（网络请求路径为 `/ws/`）。
        5.  聊天功能正常，能够根据上传的文件内容给出正确回答。
    *   **数据库验证**: SSH 登录到 EC2 服务器，使用 `psql` 工具连接到远程的 RDS 数据库，检查 `file` 表和 `brain` 表中是否存在刚刚创建的数据。
    *   **断言**: 能够查询到与测试操作相对应的数据记录。这最终确认了整个应用的数据流，从 Nginx -> API Server -> RDS，是完全通畅的。 