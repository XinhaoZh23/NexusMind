# 开发日志: 14b - React 界面开发与 WebSocket 集成

本文档记录了根据 `docs/14b_FRONTEND_UI_REACT.md` 开发 React UI 并集成 WebSocket 的过程。

---

## 任务大纲

1.  **组件化布局**:
    *   [x] 在 `src` 目录下创建 `components` 文件夹。
    *   [x] 创建 `Layout.tsx` 基础页面布局。
    *   [x] 创建 `ChatHistory.tsx` 聊天消息列表。
    *   [x] 创建 `MessageInput.tsx` 消息输入框。
    *   **状态**: 完成 (Completed)

2.  **状态管理 (React Hooks)**:
    *   [x] 使用 `useState` 管理 `messages`, `inputValue` 等状态。
    *   [x] 将状态和事件处理函数通过 props 传递给子组件。
    *   [x] 成功实现纯前端的消息发送与列表更新。
    *   **状态**: 完成 (Completed)

3.  **WebSocket 连接逻辑**:
    *   [x] 创建 `hooks` 目录及 `useWebSocket.ts` 自定义 Hook。
    *   [x] 使用 `useEffect` 在 Hook 内部管理连接生命周期。
    *   [x] 设置 `connect`, `disconnect`, `message` 事件监听器。
    *   [x] 暴露 `sendMessage` 函数并集成到 `App.tsx` 中。
    *   **状态**: 完成 (Completed)
    *   **问题排查**:
        *   **问题 1**: 遇到 `Maximum update depth exceeded` 无限循环错误。
        *   **原因**: `App.tsx` 中每次渲染都创建了新的 `addMessage` 函数实例，导致 `useWebSocket` 的 `useEffect` 依赖项改变，从而触发循环。
        *   **解决**: 在 `App.tsx` 中使用 `useCallback` 来包裹 `addMessage` 函数，稳定其引用，打破循环。
        *   **问题 2**: 浏览器控制台出现 `WebSocket is closed before the connection is established` 警告。
        *   **原因**: 这是 React 严格模式在开发环境下故意挂载-卸载-再挂载组件导致的。第一次挂载时，连接在建立完成前就被清理函数关闭了。
        *   **结论**: 此为开发模式下的正常现象，不影响最终功能和生产构建，可暂时忽略。

4.  **实现核心交互**:
    *   [x] 实现发送消息功能 (已在WebSocket集成中完成)。
    *   [x] 在侧边栏中添加文件上传按钮和逻辑。
    *   **状态**: ~~进行中 (In Progress)~~ **完成 (Completed)**
    *   **问题排查**:
        *   **问题 1**: 上传失败，返回 `500 Internal Server Error`。
        *   **原因**: Vite 代理配置中的目标端口错误 (应为 `8000` 而不是 `5001`)。
        *   **解决**: 修正 `vite.config.ts` 中的 `target` 端口。
        *   **问题 2**: 上传失败，返回 `403 Forbidden`。
        *   **原因**: 前端请求缺少 `X-API-Key` 请求头。
        *   **解决**: 在 `axios` 请求头中硬编码添加 `X-API-Key`。
        *   **问题 3**: 上传失败，返回 `422 Unprocessable Entity`。
        *   **原因**: 前端发送的 `FormData` 中缺少后端必需的 `brain_id` 字段。
        *   **解决**: 在 `FormData` 中追加 `brain_id`。
        *   **问题 4**: 上传成功后，UI 显示 `undefined uploaded!`。
        *   **原因**: 前端代码访问了错误的响应字段 (`filename` 而不是 `file_name`)。
        *   **解决**: 修正 `Layout.tsx` 以使用正确的 `response.data.file_name`。
        *   **核心问题 5**: WebSocket 连接在网络层成功 (状态码 101)，但 `connect` 事件从未在客户端触发，导致 UI 卡在 "Connecting..." 状态。
        *   **解决 (2024-08-05)**: 此问题已通过后续的 UI 布局修复间接解决。连接现在稳定。
        *   **问题 6**: 文件上传后，聊天窗口显示的消息错误，如 `✅ File "File upload accepted and is being processed." has been uploaded and is being processed.`
        *   **原因**: 后端 `/upload` 接口返回的是一个固定的成功消息，而不是文件名。前端错误地将此消息当作文件名来处理。
        *   **解决 (2024-08-05)**: 修改 `FileUpload.tsx`，在文件上传前从 `File` 对象中获取文件名，并将其用于 UI 显示和回调，而不是使用后端返回的消息。

---

## 14b 阶段总结

所有在 `docs/14b_FRONTEND_UI_REACT.md` 中定义的核心功能均已实现。UI 布局、WebSocket 实时通信和文件上传功能都已正常工作。项目现在准备好进入下一个功能增强阶段 (`14c`)。 