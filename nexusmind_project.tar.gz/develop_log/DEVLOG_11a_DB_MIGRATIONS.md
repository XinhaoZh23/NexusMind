# 开发日志：第 11a 步 - 集成 Alembic 数据库迁移

**目标**: 为项目集成 `Alembic`，实现数据库结构的自动化、版本化管理。

**相关文档**: [docs/11a_DATABASE_MIGRATIONS.md](docs/11a_DATABASE_MIGRATIONS.md)

---

## 开发步骤与记录

### 准备工作

- [x] 阅读并完全理解 `11a_DATABASE_MIGRATIONS.md` 中的任务目标和所有提示。

### 步骤 1：添加依赖

- [x] 将 `alembic` 添加到 `pyproject.toml` 的 `[tool.poetry.dependencies]` 中。
- [x] 运行 `poetry install` 或 `poetry add alembic` 来更新 `poetry.lock` 文件。
- **记录**:
  - **目的**: 为项目引入 Alembic 库，这是进行数据库迁移的基础。
  - **工具与命令**: 使用 `poetry add alembic` 命令。
  - **结果**: 命令成功执行，输出了包的安装过程 (`Installing mako`, `Installing alembic`)。这与我们的预期完全一致，表明依赖已成功添加到项目中。
  - **验证**:
    - `pyproject.toml` 中新增了 `alembic = "^1.16.3"`。
    - `poetry.lock` 文件已被更新。

### 步骤 2：初始化 Alembic

- [x] 在项目根目录运行 `poetry run alembic init alembic`。
- [x] 检查 `alembic` 目录和 `alembic.ini` 文件是否已成功创建。
- **记录**:
  - **目的**: 创建 Alembic 的基础配置文件和目录结构，为后续的自定义配置做准备。
  - **工具与命令**: 使用 `poetry run alembic init alembic`。
  - **结果**: 命令成功执行，日志清晰地显示了创建 `alembic/` 目录、`alembic.ini` 文件及其他模板文件的过程。这正是我们所期待的输出。
  - **验证**:
    - 项目根目录下出现了 `alembic.ini` 文件和 `alembic/` 目录。

### 步骤 3 & 4：配置 Alembic

- [ ] **配置 `alembic.ini`**:
    - [ ] 修改 `sqlalchemy.url`，暂时指向从环境变量加载的数据库连接串。
- [ ] **配置 `alembic/env.py`**:
    - [ ] 导入 `SQLModel` 基类和所有在 `src/nexusmind/models/` 中定义的模型。
    - [ ] 找到 `target_metadata = None`，将其设置为 `SQLModel.metadata`。
    - [ ] 在 `env.py` 中实现从 `CoreConfig` 加载数据库 URL 的逻辑，并将其提供给 Alembic 的 `context`。
- **记录**:
  ```
  <!-- 记录修改的关键代码片段或配置思路 -->
  ```

### 步骤 5：创建第一个迁移脚本

- [x] 运行 `poetry run alembic revision --autogenerate -m "Create initial tables"`。
- [x] **验证**:
    - [x] 检查 `alembic/versions/` 目录下是否有名为 `..._create_initial_tables.py` 的新文件。
    - [x] 打开该文件，确认 `upgrade()` 函数中包含 `op.create_table('file', ...)` 等代码，并且 `downgrade()` 函数中包含对应的 `op.drop_table()`。
- **记录**:
  - **目的**: 在一个干净的数据库上，自动生成与当前代码模型匹配的数据库迁移脚本。
  - **命令**: `poetry run alembic revision --autogenerate -m "Create initial tables"`
  - **结果**: **巨大成功！** 经过漫长的调试后，命令成功生成了一个非空的迁移脚本 `c1a696167488_create_initial_tables.py`。
  - **验证**: 脚本中的 `upgrade()` 函数包含了正确的 `op.create_table('file', ...)` 指令，所有列和索引都与 `models/files.py` 中的定义完全匹配。

### 步骤 6：应用并测试迁移

- [x] **应用迁移**:
    - [x] 运行 `poetry run alembic upgrade head`。
    - [x] 连接到本地的 PostgreSQL 数据库。
    - [x] **验证**:
        - [x] `files` 表已成功创建。
        - [x] `alembic_version` 表已创建，并包含最新的迁移版本号。
- [x] **回滚测试 (Downgrade & Fix Cycle)**:
    - **第一步: 降级 (Downgrade)**
        - **目的**: 测试迁移脚本的 `downgrade` 函数是否能正确撤销 `upgrade` 操作。
        - **工具与命令**: `poetry run alembic downgrade base`。
        - **结果**: 命令本身成功执行。通过 `docker exec ... \\dt` 验证后发现，`file` 表被成功删除，但 `alembic_version` 表被保留。这是 Alembic 的预期行为，证明 `downgrade` 的核心功能是正常的。
    - **第二步: 重新升级与问题发现**
        - **目的**: 测试迁移脚本是否能在一个已经被降级过的数据库上重新应用。
        - **工具与命令**: `poetry run alembic upgrade head`。
        - **结果**: **出现错误**。终端抛出 `psycopg2.errors.DuplicateObject: type "filestatusenum" already exists`。
        - **分析**: 这暴露了 Alembic `autogenerate` 的一个缺陷。它生成的 `downgrade` 函数只删除了表，但没有删除表所依赖的自定义 `ENUM` 类型 `filestatusenum`。导致该类型在数据库中残留，使下一次升级失败。
    - **第三步: 修复与清理**
        - **目的**: 1. 完善迁移脚本，使其能清理自定义类型，做到完全可逆。 2. 手动清理数据库中的残留类型，为下一次测试做准备。
        - **工具与修改**:
            1.  **修改文件**: 编辑 `alembic/versions/c1a696167488_create_initial_tables.py` 文件。
            2.  **具体位置**: 在 `downgrade()` 函数中，`op.drop_table('file')` 之后。
            3.  **具体内容**: 添加了 `op.execute("DROP TYPE filestatusenum")`。
        - **工具与命令**: `docker exec -it nexusmind_postgres psql -U nexusmind_user -d nexusmind_db -c "DROP TYPE filestatusenum;"`
        - **结果**: **输出我们所期待的结果**。终端返回 `DROP TYPE`，确认残留类型已被成功手动删除。
    - **第四步: 最终验证**
        - **目的**: 在一个干净的数据库上，完整地测试一次“升级-降级”循环，验证我们修复后的脚本是完美可逆的。
        - **工具与命令**:
            1. `poetry run alembic upgrade head`
            2. `poetry run alembic downgrade base`
        - **结果**: **巨大成功！**
            - `upgrade` 命令成功执行，无错误。
            - `downgrade` 命令成功执行，无错误。
            - **最终验证**: 运行 `docker exec ... \\dT` 后，输出为 `(0 rows)`，证明自定义类型 `filestatusenum` 已被我们的脚本成功自动删除。
- **记录**:
  - **目的**: 将生成的迁移脚本应用到数据库，实际创建表结构。
  - **命令**: `poetry run alembic upgrade head`
  - **结果**: **成功**。在修复了迁移脚本中缺失的 `import sqlmodel` 和清理了数据库中遗留的 `filestatusenum` 类型后，命令成功执行。
  - **验证**: 运行 `docker exec ... \\dt` 后，可以清楚地看到 `file` 和 `alembic_version` 两个表已存在于数据库中，与预期完全一致。

### 最终提交

- [x] 将所有新文件 (`alembic` 目录, `alembic.ini`, `DEVLOG_11a...`) 和修改过的文件 (`pyproject.toml`, `poetry.lock`, `alembic/env.py`, `alembic/versions/...`) 添加到暂存区。
- [x] 创建一个清晰的 `git commit`。

---
## 复盘与总结

**主要挑战**:
*   **空迁移脚本**: 核心挑战是 Alembic 的 `autogenerate` 持续生成空脚本。我们系统地排除了路径问题、`__init__.py` 缺失问题、模型定义问题、循环导入问题和配置加载问题。
*   **根本原因**: 最终发现问题并非出在代码或配置，而是数据库中已存在一个旧的 `files` 表，导致 Alembic 认为代码与数据库之间没有差异。
*   **`downgrade` 的不完整性**: 第二个挑战是 `autogenerate` 生成的 `downgrade` 函数默认不包含删除自定义 ENUM 类型的代码，导致 `upgrade -> downgrade -> upgrade` 的测试流程失败。

**学到的知识点**:
*   Alembic 的 `autogenerate` 是一个**比较**工具，它比较的是 `SQLModel.metadata` 和**当前数据库状态**。如果数据库状态不符合预期（例如，不干净），`autogenerate` 的结果也可能不符合预期。
*   对于使用了自定义类型（如 ENUM）的模型，必须手动检查并完善 `downgrade` 函数，确保这些类型能被正确地删除，以保证迁移的完全可逆性。
*   `\dt` (列出表) 和 `\dT` (列出类型) 是 PostgreSQL 命令行中非常有用的调试工具。

**对未来工作的启示**:
*   在运行 `alembic revision --autogenerate` 之前，最好能保证目标数据库是一个已知的、干净的状态。
*   永远不要完全信任 `autogenerate` 的结果，尤其要仔细审查 `downgrade` 函数的逻辑是否完整。

### 生产级缺陷分析

尽管本次任务的功能实现是成功的，但如果以生产环境的严格标准来审查，我们的流程中存在一些可以被认为是“生产级缺陷”的方面。记录这些缺陷对于未来的项目健壮性至关重要。

1.  **`downgrade` 函数需要手动修复**:
    *   **缺陷**: Alembic 的 `autogenerate` 功能未能自动在 `downgrade` 函数中添加删除自定义 `ENUM` 类型的代码。我们必须手动编辑迁移脚本来补全这个逻辑。
    *   **风险**: 在快节奏的团队协作中，未被审查的 `autogenerate` 脚本可能导致一个不可完全回滚的迁移被合并，为未来的线上部署和故障恢复埋下隐患。
    *   **改进建议**: 建立强制性的代码审查（Code Review）规范，要求所有迁移脚本都必须被审查，尤其要关注 `downgrade` 的逻辑是否与 `upgrade` 完全对应。

2.  **数据库清理依赖于手动操作**:
    *   **缺陷**: 在调试和测试周期中，我们多次使用了手动的 `docker exec ... psql -c "DROP ..."` 命令来重置数据库状态。
    *   **风险**: 手动操作容易出错、难以追踪，并且在真实的生产环境中，开发者直接执行 `DROP` 命令是极大的安全风险。
    *   **改进建议**: 将所有重置开发环境数据库的操作封装成一个可重复执行的脚本（如 `scripts/reset_dev_db.sh`），并严格分离生产环境的数据库操作权限。

3.  **迁移流程未与 CI/CD 集成**:
    *   **缺陷**: 我们所有的 `alembic` 命令都是在本地手动运行的。
    *   **风险**: 这依赖于开发者的自觉性。如果一个包含了数据库结构变更的代码被部署，但对应的 `alembic upgrade head` 命令没有被执行，将直接导致生产环境的应用因找不到列或表而崩溃。
    *   **改进建议**: 将数据库迁移作为 CI/CD 流水线中的一个自动化步骤。
        *   **CI 阶段**: 自动运行 `alembic upgrade head` 并在此之上跑完整的单元和集成测试。
        *   **CD 阶段**: 在部署新版本应用**之前**，自动运行 `alembic upgrade head` 命令。 