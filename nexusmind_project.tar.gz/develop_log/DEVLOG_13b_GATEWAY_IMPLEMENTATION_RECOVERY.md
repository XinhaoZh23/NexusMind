# 13b - 网关实现恢复开发日志

## 步骤 1: 设置 Express 和 WebSocket 服务器

**操作**:
根据 `13b_GATEWAY_IMPLEMENTATION.md` 的第一步，重写了 `websocket_gateway/index.js`，只包含启动 Express 和 WebSocket 服务器的基础代码。

**代码 (`websocket_gateway/index.js`):**
```javascript
const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');

const app = express();
const server = http.createServer(app);

// Use a different port for the WebSocket gateway
const PORT = process.env.PORT || 8080;

const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  console.log('Client connected');

  ws.on('close', () => {
    console.log('Client disconnected');
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });
});

server.listen(PORT, () => {
  console.log(`Gateway server listening on port ${PORT}`);
});
```

**测试结果**:
服务成功启动，测试输出符合预期。

```bash
(base) xhz@kpl-cs-pdx-edu:~/documents/code_project/NEXUSMIND/websocket_gateway$ npm run dev

> websocket_gateway@1.0.0 dev
> nodemon index.js

[nodemon] 3.1.10
[nodemon] to restart at any time, enter `rs`
[nodemon] watching path(s): *.*
[nodemon] watching extensions: js,mjs,cjs,json
[nodemon] starting `node index.js`
Gateway server listening on port 8080
```

---

## 步骤 2: 处理 WebSocket 连接

**操作**:
在 `index.js` 中添加了 `wss.on('connection', ...)` 事件监听器，并为每个连接添加了 `close` 和 `error` 的处理器，以处理客户端的连接和断开事件。

**代码 (`websocket_gateway/index.js`):**
```javascript
const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');

const app = express();
const server = http.createServer(app);

// Use a different port for the WebSocket gateway
const PORT = process.env.PORT || 8080;

const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  console.log('Client connected');

  ws.on('close', () => {
    console.log('Client disconnected');
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });
});

server.listen(PORT, () => {
  console.log(`Gateway server listening on port ${PORT}`);
});
```

**测试结果**:
使用 `wscat` 连接和断开 WebSocket 服务器，服务器端正确打印了 "Client connected" 和 "Client disconnected" 日志。

**服务器日志:**
```
Gateway server listening on port 8080
Client connected
Client disconnected
```

---

## 步骤 3: 消息代理逻辑 (框架)

**操作**:
在 `index.js` 的 `connection` 处理器中，为每个客户端添加了 `message` 事件监听器。实现了消息的 JSON 解析，并打印日志来模拟将要发往 FastAPI 的请求，但尚未实现真正的 HTTP 请求。

**代码 (`websocket_gateway/index.js`):**
```javascript
const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');

const app = express();
const server = http.createServer(app);

// Use a different port for the WebSocket gateway
const PORT = process.env.PORT || 8080;

const wss = new WebSocketServer({ server });

const FASTAPI_URL = 'http://api-server:5001/chat';

wss.on('connection', (ws) => {
  console.log('Client connected');

  ws.on('close', () => {
    console.log('Client disconnected');
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });

  ws.on('message', async (message) => {
    try {
      const parsedMessage = JSON.parse(message);
      console.log('Received message, forwarding to FastAPI:', parsedMessage);
      console.log(`Pretending to send to ${FASTAPI_URL}`);
    } catch (error) {
      console.error('Error parsing message or preparing request:', error.message);
      ws.send(JSON.stringify({ error: 'Invalid message format.' }));
    }
  });
});

server.listen(PORT, () => {
  console.log(`Gateway server listening on port ${PORT}`);
});
```

**测试结果**:
通过 `wscat` 发送 JSON 消息后，网关服务器成功接收并打印了预期的日志，验证了消息处理框架的正确性。

**服务器日志:**
```
Client connected
Received message, forwarding to FastAPI: { question: 'What is the capital of France?' }
Pretending to send to http://api-server:5001/chat
```

---

## 步骤 4 & 5: 实现流式转发和错误处理

**操作**:
在 `message` 处理器中，使用 `axios.post` 实现了对 FastAPI 服务的真实请求。
-   配置了 `responseType: 'stream'` 来处理流式数据。
-   添加了 `response.data.on('data', ...)` 监听器，将收到的数据块实时通过 WebSocket 转发回客户端。
-   添加了 `response.data.on('end', ...)` 监听器，在流结束后发送一个结束信号。
-   实现了 `try...catch` 块来捕获请求过程中的错误，并向客户端发送格式化的错误消息。

**代码 (`websocket_gateway/index.js`):**
```javascript
const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');

const app = express();
const server = http.createServer(app);

// Use a different port for the WebSocket gateway
const PORT = process.env.PORT || 8080;

const wss = new WebSocketServer({ server });

const FASTAPI_URL = 'http://api-server:5001/chat';

wss.on('connection', (ws) => {
  console.log('Client connected');

  ws.on('close', () => {
    console.log('Client disconnected');
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });

  ws.on('message', async (message) => {
    try {
      const parsedMessage = JSON.parse(message);
      console.log('Received message, forwarding to FastAPI:', parsedMessage);

      const response = await axios.post(FASTAPI_URL, parsedMessage, {
        responseType: 'stream',
      });

      response.data.on('data', (chunk) => {
        ws.send(chunk.toString());
      });

      response.data.on('end', () => {
        console.log('FastAPI stream ended.');
        ws.send(JSON.stringify({ type: 'stream_end' }));
      });

    } catch (error) {
      console.error('Error forwarding message to FastAPI:', error.message);
      ws.send(JSON.stringify({ error: 'The backend service is currently unavailable.' }));
    }
  });
});

server.listen(PORT, () => {
  console.log(`Gateway server listening on port ${PORT}`);
});
```

**测试结果 (初次):**
测试暴露了一个网络配置问题。

*   **现象**:
    *   客户端收到了 `{"error":"The backend service is currently unavailable."}`。
    *   网关日志显示 `getaddrinfo EAI_AGAIN api-server`。
*   **原因分析**:
    网关作为本地 Node.js 进程运行，无法解析 Docker 内部网络的主机名 `api-server`。它需要使用 FastAPI 服务映射到 `localhost` 的端口。
*   **修复**:
    根据 `docker-compose.yml` (`8000:8000` 映射)，将 `websocket_gateway/index.js` 中的 `FASTAPI_URL` 从 `http://api-server:5001/chat` 修正为 `http://localhost:8000/chat/stream`。

**测试结果 (第二次):**
在修正了主机名和端口后，测试揭示了一个新的问题。

*   **现象**:
    *   客户端仍然收到错误消息。
    *   网关日志显示 `Error forwarding message to FastAPI: Request failed with status code 404`。
*   **原因分析**:
    `404 Not Found` 错误表明，网关成功地向 `localhost:8000` 上的 FastAPI 服务发送了请求，但 FastAPI 服务表示它没有定义 `/chat/stream` 这个路由。这说明我们使用的 URL **路径** 不正确。
*   **修复**:
    根据 `main.py` 的路由定义，将 `FASTAPI_URL` 路径修正为 `/chat`。

**测试结果 (第三次):**
修正路径后，我们遇到了一个新的认证错误。

*   **现象**:
    *   客户端收到错误消息。
    *   网关日志显示 `Error forwarding message to FastAPI: Request failed with status code 403`。
*   **原因分析**:
    `403 Forbidden` 错误表明我们成功命中了 `/chat` 端点，但请求被拒绝。检查 `main.py` 发现，此端点需要一个 `X-API-Key` HTTP-Header 用于认证。我们的网关请求中未包含此 Header。
*   **修复方案**:
    1.  **定义密钥**: 在 `.env` 文件中明确添加 `API_KEYS=["your-super-secret-key"]`。
    2.  **传递密钥**: 修改 `docker-compose.yml`，将 `API_KEYS` 环境变量传递给 `nexusmind-api` 容器。
    3.  **发送密钥**: 修改 `websocket_gateway/index.js`，在 `axios` 请求头中包含 `'X-API-Key': 'your-super-secret-key'`。
    4.  **修正响应处理**: 同时，移除了所有流式处理逻辑 (`responseType: 'stream'` 和 `data`/`end` 事件监听)，改为直接处理和转发 FastAPI 返回的单个 JSON 对象。

**测试结果 (第四次):**
在解决了认证和数据格式问题后，我们遇到了一个网络连接错误。

*   **现象**:
    *   客户端收到错误消息。
    *   网关日志显示 `Error forwarding message to FastAPI: connect ECONNREFUSED 127.0.0.1:8000`。
*   **原因分析**:
    `ECONNREFUSED` (Connection Refused) 错误是一个网络层错误，表明操作系统拒绝了对 `localhost:8000` 的连接请求。这强烈暗示 `nexusmind-api` 容器在 `docker compose up` 之后没有成功运行或监听该端口，可能是在启动过程中遇到了错误而崩溃。
*   **调查与修复**:
    1.  通过 `docker compose logs nexusmind-api` 查看日志，发现 `nexusmind-api` 容器因 `pydantic_settings.exceptions.SettingsError` 而崩溃。
    2.  根本原因是 `API_KEYS` 环境变量未能从 `.env` 正确传递到容器，导致 Pydantic 尝试将一个空字符串解析为 JSON 列表时出错。
    3.  **临时修复**: 修改 `docker-compose.yml`，使用 `env_file` 指令直接加载 `.env` 文件。

**最终配置修正**:
根据 `12c` 的生产实践，`env_file` 方法与生产部署策略存在冲突。为了统一本地开发和生产配置，执行了以下最终修正：
1.  **保障安全**: 将 `.env` 文件添加到 `.gitignore` 中。
2.  **恢复配置**: 将 `docker-compose.yml` 恢复为使用 `${VAR}` 占位符的模式。利用 Docker Compose V2 会自动加载本地 `.env` 文件来填充这些变量的特性，从而实现了本地开发便利性与生产配置一致性的统一。

**第五次测试与最终修复**:
*   **现象**: `ECONNREFUSED` 错误复现，`docker compose logs` 显示 `API_KEYS` 变量未设置的警告和 Pydantic 的 JSON 解析错误依然存在。
*   **原因分析**: 明确了在当前用户环境中，Docker Compose V2 未能按预期自动加载 `.env` 文件来解析 `docker-compose.yml` 中的变量。
*   **最终解决方案**: 为消除所有不确定性，将 `docker-compose.yml` 修改为**仅使用 `env_file: [ './.env' ]` 指令**。这是一种最明确、最强制的配置加载方式，可以确保 `.env` 文件中的所有变量（包括格式特殊的 `API_KEYS`）都被完整加载到容器中，从而解决了根本问题。

**第六次测试与修复**:
*   **现象**: 应用启动时抛出 `ModuleNotFoundError: No module named 'nexusmind'`。
*   **原因分析**: 上一步的修复移除了 `environment` 块，导致 `PYTHONPATH=/app/src` 这个关键的环境变量丢失。没有它，Python 解释器无法在容器内的 `/app/src` 目录找到 `nexusmind` 模块。
*   **修复**: 在 `docker-compose.yml` 中同时使用 `env_file` 和 `environment`，并将 `PYTHONPATH` 添加回 `environment` 块。

**第七次测试与最终修复**:
*   **现象**: `ECONNREFUSED` 错误依然存在。日志显示新的启动错误： `ValidationError` for `MinioConfig`，缺少 `endpoint` 字段。
*   **原因分析**: 在之前的修改中，不仅 `PYTHONPATH`，其他特定于 Docker 环境的变量（如 `MINIO_ENDPOINT`）也被遗漏了。
*   **最终解决方案**: 将所有特定于 Docker 环境（即服务间通信）的变量 (`PYTHONPATH`, `MINIO_ENDPOINT` 等) 全部重新添加到 `docker-compose.yml` 的 `environment` 块中，同时保留 `env_file` 来加载所有其他配置。这完成了最终的、健壮的配置。

--- 

*   **结论**: **成功！** 整个通信链路（客户端 -> 网关 -> FastAPI -> 网关 -> 客户端）已完全打通并且工作正常。收到的 `404` 错误是**预期的业务逻辑错误**，因为测试用的 `brain_id` 尚不存在。这证明了网关不仅能成功代理请求，还能正确处理和转发后端的业务错误。`13b` 的开发和调试工作已圆满完成。

**创建测试大脑时遇到的问题**:
*   **现象**: 运行 `docker compose exec nexusmind-api python create_test_brain.py` 时，出现 `ModuleNotFoundError: No module named 'pydantic'`。
*   **原因分析**: 该命令调用了容器的系统级 Python，而不是 Poetry 管理的、安装了所有项目依赖的虚拟环境。
*   **解决方案**: 必须使用 `poetry run` 来确保脚本在正确的环境中执行。正确的命令是 `docker compose exec nexusmind-api poetry run python create_test_brain.py`。

**最终成功验证**:
*   **操作**:
    1.  使用 `docker compose exec nexusmind-api poetry run python create_test_brain.py` 成功创建了一个新的大脑，ID 为 `a5976c77-1412-4f87-94a8-d9bdf4ca5654`。
    2.  通过 `wscat` 客户端，使用这个新的 `brain_id` 发送了聊天请求。
*   **结果**: 客户端成功收到了来自后端的 AI 应答： `{"answer":"Quivr is a virtual reality archery game..."}`。
*   **结论**: `13b` 阶段的开发、调试和恢复工作已全部成功完成。

--- 