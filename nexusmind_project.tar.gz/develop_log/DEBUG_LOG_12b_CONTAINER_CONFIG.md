# 调试日志：解决 'ContainerConfig' 错误

## 问题描述

在修改 `main.py` 以添加 Prometheus 中间件后，执行 `sudo docker-compose up -d --build` 命令失败。镜像成功构建，但在“重新创建容器 (Recreating)”阶段，抛出 `KeyError: 'ContainerConfig'` 错误。

## 调试步骤

### 步骤 1：分析错误并制定计划

*   **反馈**: 用户提供了 `docker-compose up -d --build` 命令的完整输出。
*   **分析**:
    1.  Docker 镜像的构建过程是成功的，这证明我们对 `main.py` 的修改没有语法或依赖问题。
    2.  错误发生在 `docker-compose` 尝试用新镜像替换旧容器的“recreate”步骤中。
    3.  `KeyError: 'ContainerConfig'` 是一个已知的环境状态问题。它表明 `docker-compose` 无法正确读取旧容器的配置信息，导致替换操作失败。这通常是因为旧容器处于一个不稳定或已损坏的状态。
    4.  这不是一个新的代码错误，而是我们之前遇到过的环境状态问题的重现。
*   **操作**: 解决这个问题的最直接、最可靠的方法是绕过“recreate”这个不稳定的操作。我们应该先手动、彻底地清理掉所有现存的容器和网络，为 Docker Compose 提供一个干净的、无冲突的运行环境。
*   **待执行**: 等待用户执行 `sudo docker-compose down` 命令。

### 步骤 2：在干净的环境中重启并验证

*   **反馈**: 用户成功执行了 `sudo docker-compose down` 命令，所有相关的容器和网络都已被移除。
*   **分析**: 环境已经被成功清理。现在，我们可以安全地在一个干净的状态下重新启动所有服务，这应该可以完全避免 `ContainerConfig` 错误。
*   **操作**:
    1.  使用 `sudo docker-compose up -d --build` 命令来启动所有服务。因为没有旧容器存在，它将直接执行“create”操作，而不是“recreate”。
    2.  等待所有容器启动完成后，通过 `curl http://localhost:8000/metrics` 来验证 `/metrics` 端点是否按预期工作。
*   **待执行**: 等待用户执行上述命令并报告 `curl` 的结果。

### 步骤 3：遭遇新的运行时错误 (Connection Refused)

*   **反馈**: 用户执行了 `up` 和 `curl` 命令。但 `curl http://localhost:8000/metrics` 命令失败，并返回了错误 `curl: (7) Failed to connect to localhost port 8000 after 0 ms: Connection refused`。
*   **分析**:
    1.  这个错误标志着我们已经从“环境状态问题” (`ContainerConfig`) 前进到了一个新的“应用运行时问题”。
    2.  `Connection refused` 表明 `nexusmind-api` 容器在启动后，因为一个内部的致命错误而立即退出了，导致主机端口 `8000` 上没有任何进程在监听。
    3.  这个新的崩溃很可能是由我们刚刚在 `main.py` 中添加的 `PrometheusMiddleware` 引起的。它可能在初始化时有我们未满足的依赖或配置要求。
*   **操作**: 我们的首要任务是确认容器的当前状态，以证实我们的“崩溃-重启循环”猜想。
*   **待执行**: 等待用户执行 `sudo docker-compose ps` 命令并提供输出。

### 步骤 4：确认崩溃-重启循环并检查日志

*   **反馈**: `sudo docker-compose ps` 的输出显示 `nexusmind-api` 容器的状态是 `Restarting`，而其他所有服务都是 `Up`。
*   **分析**: 这个状态明确地证实了我们的猜想。API 容器在启动后遇到了一个致命错误并崩溃，然后被 Docker 自动重启，如此循环往复。问题的根源就隐藏在容器崩溃前输出的日志中。
*   **操作**: 我们需要检查 `nexusmind-api` 容器的日志，以捕获导致其崩溃的运行时错误和堆栈跟踪（Traceback）。
*   **待执行**: 等待用户执行 `sudo docker-compose logs nexusmind-api` 并提供输出。

### 步骤 5：定位到依赖缺失问题

*   **反馈**: 用户提供了 `nexusmind-api` 的容器日志。
*   **分析**: 日志中的错误非常明确，反复出现 `ModuleNotFoundError: No module named 'starlette_exporter'`。这表明，虽然我们在 `main.py` 中添加了使用 `starlette-exporter` 的代码，但我们从未将这个包本身添加到项目的依赖项中。因此，当 Docker 镜像被构建时，`poetry install` 命令没有安装这个包，导致应用在启动时因找不到模块而崩溃。
*   **操作**: 解决这个问题的唯一方法是使用 `poetry` 将 `starlette-exporter` 添加为项目依赖。这将更新 `pyproject.toml` 和 `poetry.lock` 文件。
*   **待执行**: 等待用户在项目根目录下执行 `poetry add starlette-exporter` 命令。

### 步骤 6：应用依赖修复并最终验证

*   **反馈**: 用户成功执行了 `poetry add starlette-exporter` 命令。`pyproject.toml` 和 `poetry.lock` 文件已被更新。
*   **分析**: 导致 `ModuleNotFoundError` 的根本原因——依赖缺失——已经解决。现在，我们需要将这个依赖修复和之前的代码修改（在 `main.py` 中添加中间件）一起应用到容器中。为了确保一个干净的启动并避免任何潜在的环境状态问题，最佳实践是先彻底清理，再进行构建和启动。
*   **操作**:
    1.  使用 `sudo docker-compose down` 命令来彻底清理环境。
    2.  使用 `sudo docker-compose up -d --build` 命令来使用最新的代码和依赖关系重建镜像并启动所有服务。
    3.  最后，通过 `curl http://localhost:8000/metrics` 来验证 `/metrics` 端点是否最终成功运行。
*   **待执行**: 等待用户执行上述命令并报告最终结果。

### 调试成功

*   **反馈**: 用户完全按照指示，先执行 `sudo docker-compose down` 清理环境，然后执行 `sudo docker-compose up -d --build` 重建并启动服务。最后，`curl http://localhost:8000/metrics` 命令成功返回了预期的 Prometheus 指标列表。
*   **结论**: 所有问题均已解决。`ModuleNotFoundError` 的根源是 `starlette-exporter` 依赖缺失，通过 `poetry add` 解决。之前遇到的所有环境问题，通过严格执行“先清理后构建”的流程也得以规避。应用现在已经可以稳定地在 Docker 环境中运行，并成功暴露了监控端点。本次调试结束。 