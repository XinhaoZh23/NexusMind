# 开发日志：12c - 管理生产环境密钥

## 原始计划

> # 第 12c 步：管理生产环境密钥
>
> ## 任务目标
>
> 建立一套安全的生产环境密钥管理流程。目标是停止使用 `.env` 文件来管理生产密钥，转而使用 CI/CD 服务提供商（如 GitHub Actions）的加密密钥存储功能，并将密钥作为环境变量在部署时动态注入到应用中。
>
> ## 提示词 (Prompt)
>
> "为了提升项目的安全性，我们需要重构密钥管理方式，使其适用于生产环境：
>
> 1.  **代码重构**:
>     *   检查代码，确保所有敏感信息（例如 `DATABASE_URL`, `OPENAI_API_KEY`, `CELERY_BROKER_URL` 等）都是通过环境变量读取的。
>     *   移除或确保 `.env` 文件不会被打包到生产的 Docker 镜像中。在 `.dockerignore` 文件中加入 `.env` 是一个好习惯。
>     *   更新项目的配置文件（例如 `quivr_core/config.py`），让它能够优雅地处理缺少 `.env` 文件的情况，完全依赖于运行时环境变量。
>
> 2.  **更新 Docker 配置**:
>     *   修改 `docker-compose.yml` 或生产环境的部署文件。移除 `env_file` 指令，改为通过 `environment` 指令直接从运行环境中读取变量。这使得配置更加灵活，可以通过外部方式注入变量。
>     *   示例 `docker-compose.yml` 修改:
>         ```diff
>         -    env_file:
>         -      - .env
>         +    environment:
>         +      - OPENAI_API_KEY=${OPENAI_API_KEY}
>         +      - DATABASE_URL=${DATABASE_URL}
>         +      # ... 其他需要的环境变量
>         ```
>
> 3.  **配置 CI/CD 流水线**:
>     *   在 `ci.yml` 的 `deploy` 作业中，当你通过 SSH 连接到服务器并执行部署命令时，需要将存储在 GitHub Secrets 中的密钥传递给部署脚本。
>     *   修改 `appleboy/ssh-action` 的 `script` 部分，在执行 `docker-compose` 命令前，先将从 GitHub Secrets 获取的变量导出为环境变量。
>     *   示例 `ci.yml` 中 `ssh-action` 的 `script` 部分:
>         ```yaml
>         # ...
>         with:
>           host: ${{ secrets.SSH_HOST }}
>           username: ${{ secrets.SSH_USERNAME }}
>           key: ${{ secrets.SSH_PRIVATE_KEY }}
>           script: |
>             # 将从 GitHub Secrets 获取的变量导出为环境变量
>             export OPENAI_API_KEY=${{ secrets.OPENAI_API_KEY }}
>             export DATABASE_URL=${{ secrets.PROD_DATABASE_URL }}
>             # ... 其他需要的环境变量
>             
>             # 进入项目目录
>             cd /path/to/your/project
>             
>             # 拉取最新镜像并重启服务
>             docker-compose pull
>             docker-compose up -d --force-recreate
>         # ...
>         ```
> "
>
> ## 测试方法
>
> **测试计划**：
> 1.  **配置 GitHub Secrets**:
>     *   在 GitHub 仓库的 "Settings" -> "Secrets and variables" -> "Actions" 中，创建所有你的应用需要的生产环境变量。例如 `OPENAI_API_KEY`，`PROD_DATABASE_URL` 等。
>
> 2.  **本地运行（模拟）**:
>     *   在本地终端，手动 `export` 所有需要的环境变量，然后运行 `docker-compose up`。**断言**：应用应该能正常启动并运行，这证明了应用可以正确地从环境变量中读取配置。
>     *   `unset` 一个必要的环境变量，再次尝试启动。**断言**：应用应该启动失败或在日志中明确报错，说明配置是必需的。
>
> 3.  **触发部署**:
>     *   将所有修改推送到 `main` 分支以触发 `deploy` 工作流。
>     *   **断言**：流水线应该成功执行。检查 `deploy` 作业的日志，确认没有密钥被明文打印出来。
>     *   **最终验证**: 访问你部署的应用，测试其核心功能（例如，进行一次 RAG 查询）。**断言**：功能一切正常，证明应用成功获取并使用了通过 CI/CD 注入的密钥。

---

## 开发步骤

### 步骤 1：确保 .env 文件不被打包进镜像

*   **计划**: `12c` 任务的第一步是代码重构，确保密钥安全。其中最基础的一项是保证 `.env` 文件绝对不会被包含在生产的 Docker 镜像里。我们将通过检查并修改 `.dockerignore` 文件来实现这一点。
*   **操作**: 检查 `.dockerignore` 文件的内容，确认其中是否包含了 `.env`。
*   **下一步**: 读取 `.dockerignore` 文件。

### 步骤 1 反馈与修正

*   **反馈**: 读取了 `.dockerignore` 文件的内容。
*   **分析**: 该文件目前没有包含 `.env` 条目。这意味着 `.env` 文件（如果存在）会被复制到 Docker 镜像中，这在生产环境中是不安全的。
*   **操作**: 将 `.env` 添加到 `.dockerignore` 文件中，以确保它被排除在 Docker 构建上下文之外。
*   **下一步**: 修改 `.dockerignore` 文件。

### 步骤 2：重构配置加载逻辑

*   **进展**: `步骤 1` 已完成，`.dockerignore` 文件已被修正。
*   **计划**: `12c` 任务要求我们重构代码，使其优先依赖运行时环境变量，而不是强制绑定 `.env` 文件。我们之前为了修复本地开发问题，在 `base_config.py` 的 `SettingsConfigDict` 中强制指定了 `env_file=".env"`。这个设置不适用于灵活的生产环境部署。
*   **分析**: Pydantic v2 的默认行为是首先尝试加载真正的环境变量，如果找不到，它会自动（如果安装了 `python-dotenv`）查找并加载 `.env` 文件。因此，最理想的、同时兼容本地开发和生产部署的方案，就是移除 `env_file=".env"` 这个强制性配置，让 Pydantic 回归其默认的、更灵活的行为。
*   **操作**: 修改 `src/nexusmind/base_config.py` 文件，移除所有 `SettingsConfigDict` 中的 `env_file=".env"` 和 `env_file_encoding="utf-8"` 这两项配置。
*   **下一步**: 修改 `src/nexusmind/base_config.py` 文件。

### 步骤 3：更新 Docker Compose 配置

*   **进展**: `步骤 2` 已完成，配置加载逻辑已被重构。
*   **计划**: `12c` 任务要求我们更新 `docker-compose.yml`，移除对 `.env` 文件的直接依赖，以便将来通过运行时环境变量注入生产密钥。
*   **操作**: 修改 `docker-compose.yml` 文件，移除 `nexusmind-api` 服务下的 `env_file` 指令。
*   **下一步**: 修改 `docker-compose.yml` 文件。

### 步骤 4：测试代码重构效果

*   **进展**: `步骤 3` 已完成，`docker-compose.yml` 已更新。
*   **计划**: 在本地测试我们的代码重构是否成功。理想情况下，即便 `docker-compose.yml` 不再指定 `env_file`，应用也应能通过 Pydantic 的自动回退机制，成功加载本地的 `.env` 文件并正常启动。
*   **问题**: 执行 `sudo docker-compose down` 命令失败，返回 `network has active endpoints` 错误。
*   **分析**: 这是因为我们之前使用了多个 `docker-compose` 文件启动了服务（包括监控服务），但在关闭时只指定了主文件。这导致 `down` 命令无法移除仍连接着监控容器的网络。
*   **操作**: 使用正确的 `down` 命令，包含所有相关的配置文件，来彻底清理环境。
*   **下一步**: 执行正确的 `down` 命令，然后继续执行 `up` 和 `curl` 验证。 