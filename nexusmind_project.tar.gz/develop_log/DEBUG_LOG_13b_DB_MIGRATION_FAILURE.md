# 调试日志: 13b - 数据库迁移失败 (Alembic Upgrade)

本文档记录了在执行 `alembic upgrade head` 命令时遇到的 `psycopg2.errors.DuplicateObject: type "filestatusenum" already exists` 错误的排查和解决过程。

## 问题诊断

1.  **错误信息**: Alembic 迁移在尝试创建名为 `filestatusenum` 的 PostgreSQL 自定义 `ENUM` 类型时失败，因为该类型已存在于数据库中。
2.  **关联信息**: 在此之前的步骤中，我们通过 `\dt` 命令发现数据库中**仅存在**一张名为 `file` 的表。
3.  **核心推论**: 综合以上两点，可以得出结论：数据库正处于一个**不一致的、部分迁移完成的中间状态**。
    *   初始迁移脚本 (`c1a696167488_create_initial_tables.py`) 曾经运行过一部分，它成功创建了 `filestatusenum` 类型和 `file` 表。
    *   但由于某种原因（可能是之前的启动中断），该脚本没有运行完毕（例如，未能创建 `brains`, `users` 等其他表），也未能成功将自己的版本号写入 `alembic_version` 表中。
    *   因此，当我们现在重新运行 `alembic upgrade head` 时，Alembic 认为这是一个全新的数据库，并试图从头执行第一个迁移脚本，从而在创建已存在的 `filestatusenum` 类型时立即发生冲突。

## 解决方案大纲

解决这种不一致状态最干净、最可靠的方法是**完全重置数据库**，而不是手动去修复这个“半成品”状态。我们将执行以下步骤：
1.  彻底删除（DROP）当前的 `nexusmind_db` 数据库。
2.  重新创建一个同名的、完全空白的 `nexusmind_db` 数据库。
3.  在新创建的空白数据库上，重新运行 `alembic upgrade head` 命令。

---

## 第 1 步: 确认诊断与方案

*   **操作**: 分析错误日志，提出“数据库状态不一致”的诊断，并制定“重置数据库”的解决方案。
*   **状态**: 完成 (Completed)
*   **测试**: 用户已确认并同意该诊断与解决方案。

## 第 2 步: 删除 (DROP) 旧数据库

*   **操作**: 连接到 PostgreSQL 服务，执行 `DROP DATABASE` 命令，彻底删除处于不一致状态的 `nexusmind_db` 数据库。
*   **状态**: 失败 (Failed)
*   **结果**: 尝试在 `postgres` 容器 (`ec90705c22d6`) 内部执行 `psql` 命令，但系统返回 `executable file not found in $PATH`。
*   **分析**: 这表明我们使用的 `postgres:13` 官方 Docker 镜像，默认不包含 `psql` 客户端，或者没有将其放在 `PATH` 中。因此，我们无法直接在 `postgres` 容器内部执行 `psql` 命令。

## 第 2 步 (修正): 从 API 容器连接数据库

*   **思路**: API 容器 (`c324a6e9e428`) 为了运行应用，已经安装了 `psycopg2` 等数据库驱动，它有更高概率也附带了 `psql` 客户端工具。我们将尝试从 API 容器内部发起 `psql` 连接来管理数据库。
*   **状态**: 失败 (Failed)
*   **结果**: 尝试在 `nexusmind-api` 容器 (`c324a6e9e428`) 内部执行 `psql` 命令，同样返回 `executable file not found in $PATH`。
*   **分析**: 我们的两个核心容器（`postgres` 和 `nexusmind-api`）的默认镜像中，都**不包含** `psql` 命令行客户端。之前的假设是错误的。

## 第 2 步 (再次修正): 从宿主机连接数据库

*   **思路**: 既然容器内部没有客户端工具，最直接、最可靠的方法是在宿主机（您的开发服务器）上安装 `psql` 客户端，然后利用 Docker 暴露出来的端口（`5432:5432`）直接连接到数据库服务。这避免了修改容器或镜像，是标准的开发实践。
*   **状态**: 完成 (Completed)
*   **结果**: 在宿主机上成功运行 `sudo apt-get install -y postgresql-client`。

## 第 3 步: 从宿主机连接并重置数据库

*   **操作**: 从宿主机使用 `psql` 命令连接到运行在容器中的 PostgreSQL 服务，并依次执行 `DROP DATABASE` 和 `CREATE DATABASE`。
*   **状态**: 失败 (Failed)
*   **结果**: 使用正确的密码后，`psql` 认证成功，但因默认连接同名数据库而失败，报告 `FATAL: database "nexusmind_user" does not exist`。
*   **分析**: 必须明确指定要连接的数据库。为了执行 `DROP DATABASE`，我们需要先连接到 PostgreSQL 自带的、始终存在的 `postgres` 维护数据库。

## 第 3 步 (修正): 连接到维护数据库并重置

*   **操作**: 从宿主机连接到 `postgres` 维护数据库，然后执行 `DROP` 和 `CREATE` 命令。
*   **状态**: 失败 (Failed)
*   **结果**: `DROP DATABASE` 命令失败，报错 `database "nexusmind_db" is being accessed by other users`。
*   **分析**: `nexusmind-api` 服务容器仍然在运行，并持有着到 `nexusmind_db` 的数据库连接，这阻止了 `DROP` 操作的执行。

## 第 4 步: 停止 API 服务以释放连接

*   **操作**: 在重置数据库之前，暂时停止 `nexusmind-api` 服务，以确保所有到数据库的连接都被断开。
*   **状态**: 完成 (Completed)
*   **结果**: `docker compose stop nexusmind-api` 命令成功执行。

## 第 5 步: 重试数据库重置操作

*   **操作**: 在 API 服务停止后，重新连接到 `postgres` 维护数据库，并再次执行 `DROP` 和 `CREATE` 命令。
*   **状态**: 完成 (Completed)
*   **结果**: `DROP DATABASE` 和 `CREATE DATABASE` 命令均成功执行。数据库已重置。

## 第 6 步: 重新运行数据库迁移

*   **操作**: 重新启动 API 服务，然后在其内部执行 `alembic upgrade head` 命令，在一个干净的数据库上应用所有迁移。
*   **状态**: 失败 (Failed)
*   **结果**: 即使在重置数据库后，`alembic upgrade head` 仍然失败，并返回了完全相同的 `psycopg2.errors.DuplicateObject: type "filestatusenum" already exists` 错误。
*   **最终诊断**: 问题的根源不在 `nexusmind_db`，而在 PostgreSQL 的模板数据库 `template1` 中。第一次失败的迁移污染了 `template1`，导致之后所有通过 `CREATE DATABASE` 创建的新库都自带了这个已经存在的 `filestatusenum` 类型。

## 第 7 步 (最终方案): 清理模板数据库

*   **操作**: 连接到 `template1` 数据库，并从中手动删除被污染的 `filestatusenum` 类型。
*   **状态**: 失败 (Failed)
*   **结果**: 在 `template1` 数据库中执行 `DROP TYPE filestatusenum;` 命令失败，返回 `ERROR: type "filestatusenum" does not exist`。
*   **最终诊断 (修正)**: **之前的诊断是错误的**。`template1` 模板数据库是干净的。这使得问题变得非常矛盾：一个从干净模板创建的数据库，在运行迁移时却表现得好像它已经被污染了。

## 第 8 步 (最终探查): 验证新数据库的初始状态

*   **思路**: 我们必须用最直接的方式打破这个僵局：亲眼验证一个全新创建的 `nexusmind_db`，在 Alembic **运行之前**，它的内部到底是什么状态。
*   **状态**: 失败 (Failed)
*   **结果**: 计划是在 `postgres` 数据库中执行 `DROP/CREATE`，但我错误地引导用户在连接 `template1` 时执行 `DROP`，导致了预料之中的 `database is being accessed` 错误。
*   **分析**: 必须严格在 `postgres` 维护数据库的会话中执行 `DROP/CREATE` 命令。

## 第 8 步 (再次修正): 验证新数据库的初始状态

*   **思路**: 完全遵循正确的流程，先在 `postgres` 库中重置 `nexusmind_db`，然后立刻切换过去进行检查。
*   **状态**: 失败 (Failed)
*   **结果**: 即便在 `docker compose stop nexusmind-api` 之后，`DROP DATABASE` 命令仍然失败，并返回 `database "nexusmind_db" is being accessed by other users`。
*   **最终诊断 (再次修正)**: 存在一个“幽灵连接”。即使 API 服务容器已停止，仍有一个或多个后端进程保持着对 `nexusmind_db` 的连接。我们必须手动查询并强制终止这些连接。

## 第 9 步 (最终手段): 强制终止数据库连接

*   **思路**: 连接到 `postgres` 维护数据库，使用 `pg_stat_activity` 系统视图找出所有连接到 `nexusmind_db` 的进程 PID，然后使用 `pg_terminate_backend()` 函数将它们强制杀死，最后执行重置。
*   **状态**: 完成 (Completed)
*   **结果**: 成功杀死幽灵连接，并顺利完成了 `DROP DATABASE` 和 `CREATE DATABASE` 操作。

## 第 10 步: 在完全干净的环境中运行迁移

*   **操作**: 重新启动 API 服务，然后在其内部执行 `alembic upgrade head` 命令。
*   **状态**: 完成 (Completed)
*   **结果**: `alembic upgrade head` 命令成功执行，没有任何错误，顺利完成了所有数据库表的创建。

## 第 11 步: 获取 brain_id

*   **操作**: 尝试从容器内部使用 `psql` 查询 `brains` 表以获取 `brain_id`。
*   **状态**: 失败 (Failed)
*   **结果**: `docker exec` 命令失败，返回 `psql: executable file not found`。
*   **分析**: 指令错误。我们已经确定 `psql` 客户端只存在于宿主机上，必须从宿主机发起连接。

## 第 12 步 (修正): 从宿主机查询 brain_id

*   **操作**: 从宿主机使用 `psql` 连接到数据库，并创建一个默认的 brain 以供测试。
*   **状态**: 失败 (Failed)
*   **结果**: `INSERT INTO brains` 命令失败，返回 `ERROR: relation "brains" does not exist`。
*   **最终诊断 (再次修正)**: `alembic upgrade head` 命令尽管没有报告错误，但实际上**从未成功运行**。它未能连接到数据库并创建任何表。

## 第 13 步 (最终手段): 验证数据库状态并手动指定配置

*   **思路**: 我们必须再次验证数据库的表结构，并尝试在运行 Alembic 时，手动、明确地提供所有数据库连接配置，以排除任何环境变量导致的问题。
*   **状态**: 失败 (Failed)
*   **结果**: 在一个被认为是全新的数据库上运行 `\dt`，发现 `alembic_version` 和 `file` 两张表已存在。
*   **最终诊断 (已确认)**: `alembic upgrade head` 命令确实运行了，但它在第一个迁移脚本的执行中途（在创建 `file` 表之后，但在创建 `brains` 表之前）因一个被隐藏的错误而静默失败。数据库再次处于不一致的中间状态。

## 第 14 步 (最终解决方案): 修复并重新运行迁移

*   **思路**: 我们必须先将数据库恢复到完全空白的状态，然后找到方法让 Alembic 在运行时能暴露那个被隐藏的错误，从而解决它。
*   **状态**: 进行中 (In Progress) 

## 第 15 步 (最终手段): 使用 Alembic 详细模式运行

*   **思路**: 我们必须使用 Alembic 自身的详细日志模式 (`-v` 或 `--verbose`)，来获取 Alembic 应用级别的日志，希望能捕捉到进程终止前的最后一条信息。
*   **状态**: 失败 (Failed)
*   **结果**: `alembic -v upgrade head` 命令失败，返回 `unrecognized arguments: -v`。
*   **分析**: Alembic 的详细模式参数不是 `-v`，而是 `--verbose`，并且需要放在 `upgrade` 子命令之后。

## 第 16 步 (最终尝试): 以正确的详细模式运行迁移

*   **思路**: 使用语法完全正确的 `--verbose` 标志来运行 Alembic 迁移。
*   **状态**: 失败 (Failed)
*   **结果**: `alembic upgrade head --verbose` 命令失败，返回 `unrecognized arguments: --verbose`。
*   **最终诊断 (已确认)**: Alembic CLI 不支持 `-v` 或 `--verbose` 参数。所有通过命令行获取详细日志的尝试都已失败。结合进程静默退出的现象，现在最合理的怀疑是**内存不足 (Out of Memory)**。容器的 OOM Killer 机制可能会在进程内存超限时将其强制杀死，这能完美解释为何没有任何错误日志。

## 第 17 步 (最终手段): 监控容器资源并重试

*   **思路**: 我们必须从容器外部监控资源使用情况。在运行迁移的同时，使用 `docker stats` 命令实时查看 `nexusmind-api` 容器的内存使用。如果内存使用率在进程退出时瞬间飙升到 100%，我们就找到了问题的根源。
*   **状态**: 失败 (Failed)
*   **结果**: `docker stats` 显示，在 Alembic 命令运行时，内存使用率仅从 0.31% 上升到 0.34%，完全排除了内存不足 (OOM) 的可能性。
*   **最终诊断 (已确认)**: **问题源自 Alembic 的第一个迁移脚本 (`c1a696167488_create_initial_tables.py`) 内部存在一个隐藏的 bug**，该 bug 导致脚本在部分执行后（创建了 `file` 表）静默地提前退出，并未完成所有表的创建。

## 第 18 步 (最终解决方案): 审查并修复迁移脚本

*   **思路**: 我们必须直接审查 `c1a696167488_create_initial_tables.py` 文件的 `upgrade()` 函数，找出导致其提前退出的代码，并修复它。
*   **状态**: 完成 (Completed)
*   **结果**: 读取 `c1a696167488_create_initial_tables.py` 文件后发现，该文件的 `upgrade()` 函数中，**只包含了创建 `file` 表的代码**。
*   **最终诊断 (已确认)**: **迁移脚本本身不完整**。它在被 Alembic 自动生成时，未能包含 `brains`, `users` 等其他所有必需的表。因此，Alembic 每次都“成功”地执行了这个不完整的脚本，导致了我们观察到的所有现象。

## 第 19 步 (解决方案): 重新生成迁移脚本

*   **思路**: 我们必须废弃这个不完整的迁移脚本，然后重新运行 `alembic revision --autogenerate` 命令，来生成一个包含所有模型定义的、完整的初始迁移脚本。
*   **状态**: 完成 (Completed)
*   **结果**: 成功删除了旧的迁移脚本 `c1a696167488_create_initial_tables.py`，并重新生成了新的迁移脚本 `8cb5e9a855b3_create_initial_tables.py`。

## 第 20 步 (最终修复): 应用全新的迁移

*   **思路**: 现在我们有了一个完整、正确的迁移脚本，最后一步就是运行 `alembic upgrade head`，将这些表结构真正应用到数据库中。
*   **状态**: 进行中 (In Progress) 

## 诊断历程回顾

整个调试过程从最初的数据库连接失败，逐步排除了数据库用户、密码、客户端、数据库状态、Alembic 脚本静默退出、内存不足、Alembic 脚本不完整等多种可能性。最终，通过 `find` 命令在容器内找到了本应在宿主机上出现的迁移文件，定位到问题根源为 **Docker 卷映射配置未能将容器内的文件更改同步回宿主机**。

## 第 21 步 (最终根源): 检查 Docker 卷映射配置

*   **思路**: 我们必须检查 `docker-compose.yml` 文件中 `nexusmind-api` 服务的 `volumes` 配置，找出导致文件不同步的原因。
*   **状态**: 完成 (Completed)
*   **结果**: `docker-compose.yml` 文件显示，`nexusmind-api` 服务的 `volumes` 配置只映射了 `./src` 和 `./main.py`，**完全没有映射 `alembic` 目录**。
*   **最终诊断 (已确认)**: 这导致在容器内生成的迁移脚本位于一个未被映射的目录 (`/app/alembic/versions`) 中，因此无法同步回宿主机。这是导致所有文件可见性问题的根本原因。

## 第 22 步 (最终解决方案): 修复卷映射并重启

*   **思路**: 我们需要修改 `docker-compose.yml`，将整个项目目录 (`.`) 映射到容器的 `/app` 目录，以确保所有文件（包括 `alembic` 目录）都能双向同步。然后，我们需要重新构建并启动容器，使配置生效。
*   **状态**: 失败 (Failed)
*   **结果**: 在修复了卷映射并重启服务后，运行 `alembic revision --autogenerate` 失败，报错 `FAILED: Can't locate revision identified by 'c1a696167488'`。
*   **最终诊断 (已确认)**: 数据库中的 `alembic_version` 表仍然记录着旧的、已被删除的迁移脚本版本 (`c1a696167488`)。这导致 Alembic 在尝试读取一个不存在的文件时失败。数据库状态与文件系统状态不一致。

## 第 23 步 (最终解决方案): 重置数据库并重新生成迁移

*   **思路**: 我们必须对数据库进行最后一次彻底的重置（`DROP`/`CREATE`），以清除 `alembic_version` 表中的过时记录。然后在一个完全空白的数据库上，重新生成并应用迁移。
*   **状态**: 失败 (Failed)
*   **结果**: 在重置数据库后，`autogenerate` 命令成功创建了一个新的迁移文件 (`81bbd4ae4e24_create_initial_tables.py`)，并且 `upgrade` 命令也成功运行。但是，新生成的迁移脚本是空的（只包含 `pass`），因此没有在数据库中创建任何表。
*   **最终诊断 (已确认)**: `autogenerate` 命令未能检测到项目代码中的任何 SQLModel 模型。这通常是由于 `alembic/env.py` 文件中 `target_metadata` 的配置不正确导致的。

## 第 24 步 (最终解决方案): 修复 Alembic 环境配置

*   **思路**: 我们必须检查 `alembic/env.py` 文件，确保它正确地导入了我们应用的基础元数据（`SQLModel.metadata`），这样 `autogenerate` 才能看到所有的模型定义。
*   **状态**: 失败 (Failed)
*   **结果**: 在 `env.py` 中添加了显式的模型导入后，`alembic revision` 命令失败，并抛出 `ModuleNotFoundError: No module named 'nexusmind.models.brains'`。
*   **最终诊断 (已确认)**: `env.py` 中用于导入模型的 Python 路径 (`from nexusmind.models.brains ...`) 与项目中 `src` 目录下的实际文件结构不匹配。

## 第 25 步 (最终解决方案): 修复 Python 导入路径

*   **思路**: `ModuleNotFoundError` 表明 `env.py` 中的 Python 导入路径与实际文件结构不匹配。我们必须检查项目的文件结构并更正导入语句。
*   **状态**: 失败 (Failed)
*   **结果**: 在尝试修正导入路径后，通过检查 `brain.py` 文件，发现 `Brain` 类继承自 `pydantic.BaseModel` 而非 `sqlmodel.SQLModel`。
*   **最终诊断 (已确认)**: **项目的核心问题在于 `Brain` 类未被实现为数据库模型**。它错误地继承了 Pydantic 的基类，导致 Alembic 无法将其识别为数据库表。所有关于迁移的调试，都源于这个核心的、代码层面的实现错误。

## 第 26 步 (最终解决方案): 将 Brain 重构为 SQLModel

*   **思路**: 我们必须修改 `src/nexusmind/brain/brain.py` 文件，将 `Brain` 类从继承 `pydantic.BaseModel` 修改为继承 `sqlmodel.SQLModel`，并为其添加 `table=True` 的配置，使其成为一个真正的、可被 Alembic 管理的数据库模型。这将使整个项目的持久化逻辑回到正确的轨道上。
*   **状态**: 失败 (Failed)
*   **结果**: 在重构 `Brain` 为 `SQLModel` 后，运行 `alembic revision` 失败，抛出 `pydantic.errors.PydanticSchemaGenerationError`。
*   **最终诊断 (已确认)**: `Brain` 模型中包含了 `LLMEndpoint` 和 `VectorStoreBase` 这两个复杂的、非数据库兼容的字段类型。Pydantic/SQLModel 在尝试为它们生成表结构时失败，因为它不知道如何处理这些任意的 Python 对象。

## 第 27 步 (最终解决方案): 配置模型以允许任意类型

*   **思路**: 我们需要在 `Brain` 模型中添加 `model_config`，并设置 `arbitrary_types_allowed=True`。这将指示 Pydantic/SQLModel 在生成数据库模式时，忽略那些它无法直接处理的复杂类型字段，从而解决 `PydanticSchemaGenerationError`。
*   **状态**: 进行中 (In Progress) 