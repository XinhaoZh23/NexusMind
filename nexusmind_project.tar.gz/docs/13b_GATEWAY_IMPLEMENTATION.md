# 第 13b 步：实现 WebSocket 网关核心逻辑

## 任务目标

在 `websocket_gateway/index.js` 文件中，实现完整的 WebSocket 服务器逻辑。该服务器将管理客户端连接，接收来自客户端的消息，将其转发给后端的 FastAPI 服务，并将 FastAPI 返回的流式响应再通过 WebSocket 实时推送回客户端。

## 提示词 (Prompt)

"现在，请在 `index.js` 中实现 WebSocket 网关的核心功能：

1.  **设置 Express 和 WebSocket 服务器**:
    *   引入 `express` 和 `ws` 库。
    *   创建一个 Express 应用实例，并让它监听一个端口（例如 8080）。
    *   基于这个 Express 服务器，创建一个 WebSocket.Server 实例。

2.  **处理 WebSocket 连接**:
    *   为 WebSocket 服务器设置一个 `connection` 事件监听器。当有新的前端客户端连接进来时，此回调函数将被触发。
    *   在此回调函数中，为每一个客户端的 `connection` 对象设置一个 `message` 事件监听器。

3.  **消息代理逻辑 (核心)**:
    *   当收到来自某个客户端的 `message` 时：
        *   解析消息内容（应为一个 JSON 字符串，包含用户提问等信息）。
        *   使用 `axios` 向后端的 FastAPI 服务 (`http://api-server:5001/chat`) 发起一个 **流式 POST 请求**。确保将从客户端收到的数据作为请求体发送。
        *   **关键**: 在 `axios` 请求的配置中，必须设置 `responseType: 'stream'`，这样才能处理 FastAPI 返回的流式数据。

4.  **响应流转发**:
    *   监听 `axios` 返回的响应流的 `data` 事件。
    *   每当接收到一块数据（`chunk`）时，立即通过当前客户端的 WebSocket 连接 (`ws.send()`) 将这块数据原样发送回前端。
    *   监听响应流的 `end` 事件，当后端数据全部发送完毕时，可以发送一个特殊结束信号，或直接关闭连接（根据前端需要决定）。

5.  **错误处理**:
    *   在整个流程中添加健壮的错误处理。
    *   如果 `axios` 请求失败（例如 FastAPI 服务宕机），需要捕获错误，并通过 WebSocket 向客户端发送一个格式化的错误消息。
    *   处理 WebSocket 连接本身可能发生的错误，并在服务器控制台记录日志。"

## 测试方法

**测试计划**：
1.  **启动所有后端服务**:
    *   确保 FastAPI 服务 (`api-server`) 及其所有依赖（Postgres, Redis, Celery worker）正在运行。这是本测试的前提。
    *   在 `websocket_gateway` 目录中，运行 `npm run dev` 启动 Node.js 网关服务。

2.  **使用 WebSocket 客户端工具进行集成测试**:
    *   推荐使用一个专门的 WebSocket 测试工具，例如 Postman 的 WebSocket 功能，或者一个简单的命令行工具如 `wscat`。
    *   **连接测试**:
        *   使用工具连接到 `ws://localhost:8080`。
        *   **断言**: 连接应成功建立，Node.js 服务器的控制台应打印出“客户端已连接”的日志。
    *   **消息代理测试**:
        *   通过工具发送一个模拟的、符合格式的 JSON 消息（例如 `{"question": "What is Quivr?"}`）。
        *   **断言**:
            1.  Node.js 服务器的控制台应打印出接收到消息的日志。
            2.  FastAPI 服务的控制台应打印出 `/chat` 端点被调用的日志。
            3.  你的 WebSocket 客户端工具应能**实时地、一块一块地**接收到来自 FastAPI 的流式响应。
            4.  这证明了从 `客户端 -> Node网关 -> FastAPI -> Node网关 -> 客户端` 的完整数据链路是通畅的。

3.  **错误处理测试**:
    *   在保持 WebSocket 连接的情况下，手动停止 FastAPI 服务 (`docker-compose stop api-server`)。
    *   再次通过 WebSocket 客户端发送一个消息。
    *   **断言**: 你的 WebSocket 客户端应能收到一个格式化的错误消息（例如 `{"error": "Backend service is unavailable"}`），而不是连接被粗暴地断开。这证明了错误处理逻辑是有效的。 