# 第 16 步：生产级加固

## 任务目标

为项目增加三个关键的、轻量级的生产级加固措施。这些措施将极大地提升服务的健壮性、安全性与成本可控性，是从“原型”到“产品”的关键一步，投入产出比极高。

## 提示词 (Prompt)

"为了让我们部署的服务能够抵御基础的攻击并具备自愈能力，请在现有代码和配置的基础上，完成以下三项加固：

1.  **在 Node.js 网关中实现速率限制**:
    *   **目标文件**: `websocket_gateway/index.js`
    *   **操作**:
        *   安装 `express-rate-limit` 库 (`npm install express-rate-limit`)。
        *   引入该库，并创建一个速率限制中间件实例。配置它在一定时间窗口内（例如 15 分钟）只允许来自同一个 IP 的数百次请求。
        *   将此中间件应用到 Express 应用上，确保它在处理 WebSocket 连接之前生效。

2.  **为核心服务配置健康检查 (Healthcheck)**:
    *   **目标文件**: `docker-compose.yml`
    *   **操作**:
        *   为 `api-server` (FastAPI) 服务添加 `healthcheck` 指令。`test` 命令应使用 `curl` 定期请求 `http://localhost:5001/health` 端点。
        *   为 `websocket-gateway` (Node.js) 服务添加 `healthcheck` 指令。由于 Node.js 服务没有专门的 health 接口，我们可以通过一个简单的 `test` 命令来检查端口是否仍在监听。
        *   为这两个 `healthcheck` 配置合理的 `interval`, `timeout`, `retries` 和 `start_period`。

3.  **在 Nginx 中限制请求体大小**:
    *   **目标文件**: `nginx/nginx.conf`
    *   **操作**:
        *   在 `http` 或 `server` 配置块中，添加一行指令 `client_max_body_size 10m;`。
        *   这将把允许客户端上传的文件大小（或其他请求体）限制在 10MB，有效防止恶意大文件攻击。

## 测试方法

**测试计划**：
1.  **速率限制测试**:
    *   编写一个简单的脚本（或手动快速操作），在短时间内向 WebSocket 网关发起大量连接请求。
    *   **断言**: 在达到阈值后，新的连接请求应该被拒绝，并返回 HTTP 429 "Too Many Requests" 错误。

2.  **健康检查测试**:
    *   启动所有服务后，运行 `docker-compose ps`。
    *   **断言**: `api-server` 和 `websocket-gateway` 服务的状态栏应在短暂的“starting”后，显示为“healthy”。
    *   **模拟故障**: 手动进入 `api-server` 容器并杀掉 Uvicorn 进程。
    *   **断言**: 几分钟后，再次运行 `docker-compose ps`，该容器的状态会变为“unhealthy”，并最终被 Docker 自动重启，恢复到“healthy”状态。这证明了服务的自愈能力。

3.  **请求大小限制测试**:
    *   通过 UI 或 API 测试工具（如 Postman），尝试上传一个大于 10MB 的文件。
    *   **断言**: Nginx 应直接拒绝该请求，并返回 HTTP 413 "Payload Too Large" 错误，该请求甚至不会到达后端的 FastAPI 服务。 