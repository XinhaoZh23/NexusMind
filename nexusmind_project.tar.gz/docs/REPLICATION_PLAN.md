# Quivr 项目复现计划

本项目旨在通过一系列精确的指令，引导一个大型语言模型（LLM）逐步复现 Quivr 项目的核心功能，并最终将其打造为一个生产级的云原生应用。

每个阶段的详细指令都存放在一个单独的 Markdown 文件中。请按照以下顺序执行。

## 复现步骤

### 阶段一：项目奠基与 MVP

*   **[第 0-9 步]**: 包含从基础架构到 MVP 功能实现的所有原始步骤，最终产出一个功能完整、经过充分测试、已容器化的后端核心应用。
    *   **[第 0 步：项目基础架构搭建](./00_PROJECT_SETUP.md)**
    *   **[第 1 步：配置管理系统](./01_CONFIGURATION.md)**
    *   **[第 1a 步：代码质量与自动化](./01a_CODE_QUALITY.md)**
    *   **[第 2 步：核心数据实体定义](./02_CORE_ENTITIES.md)**
    *   **[第 3 步：存储层抽象与实现](./03_STORAGE.md)**
    *   **[第 4 步：文档处理器](./04_PROCESSORS.md)**
    *   **[第 5 步：大语言模型（LLM）集成](./05_LLM_INTEGRATION.md)**
    *   **[第 6 步：核心智能体（Brain）构建](./06_BRAIN.md)**
    *   **[第 7 步：RAG 检索增强生成流水线](./07_RAG_PIPELINE.md)**
    *   **[第 7a 步：向量数据库集成](./07a_VECTOR_STORE.md)**
    *   **[第 7b 步：RAG 流水线重构](./07b_RAG_REFACTOR.md)**
    *   **[第 7c 步：引入结构化日志](./07c_LOGGING.md)**
    *   **[第 8 步：API 服务接口](./08_API_SERVER.md)**
    *   **[第 8a 步：异步任务处理](./08a_ASYNC_TASKS.md)**
    *   **[第 8b 步：API 安全性与认证](./08b_API_SECURITY.md)**
    *   **[第 8c 步：容器化 (Docker)](./08c_CONTAINERIZATION.md)**
    *   **[第 9 步：项目最终确定与文档化](./09_FINALIZATION.md)**

---
### **阶段二：迈向生产级与云原生**
---

10. **[第 10 步：升级到生产级任务队列 (Celery & Redis)](./10_CELERY_INTEGRATION.md)**
    -   **目标**: 使用 Celery 和 Redis 替换 `BackgroundTasks`，实现健壮的、可独立扩展的后台任务处理。

11. **[第 11 步：升级到生产级数据持久化 (PostgreSQL & S3)](./11_PROD_DATA_STORE.md)**
    -   **目标**: 使用 PostgreSQL 和 S3 替换本地文件存储，实现高可用和可扩展的数据持久化。

12. **[第 11a 步：引入数据库迁移 (Alembic)](./11a_DATABASE_MIGRATIONS.md)**
    -   **目标**: 集成 `Alembic`，以编程方式、可版本化的方式管理数据库结构变更。

13. **[第 12 步：建立 CI/CD 流水线 (GitHub Actions)](./12_CICD_PIPELINE.md)**
    -   **目标**: 建立 GitHub Actions 流水线，自动化测试、代码检查与构建流程。

14. **[第 13 步：构建前端界面与最终部署](./13_FRONTEND_AND_FINALIZATION.md)**
    -   **目标**: 构建 Streamlit 前端，并更新文档以反映最终的全栈云原生架构。

---
### **阶段三：高级技能展示 (可选)**
---

这个阶段的任务是可选的，其主要目的不是为了完善项目功能，而是为了在求职过程中，以极低的成本、极具说服力地展示您在云原生部署和复杂架构设计方面的深度与广度。

15. **[第 14 步 (可选)：模拟生产环境部署 (Kubernetes)](./14_OPTIONAL_K8S_DEPLOYMENT.md)**
    -   **目标**: 通过为项目编写完整的 K8s 部署清单，展示您对容器编排和生产环境部署的理解。

16. **[第 15 步 (可选)：撰写架构决策文档](./15_OPTIONAL_ARCHITECTURE_DOC.md)**
    -   **目标**: 通过撰写一份技术选型文档（如 Redis vs. Kafka），展示您进行技术权衡和架构演进规划的能力。 