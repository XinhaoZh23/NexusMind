# 第 10 步：升级到生产级任务队列 (Celery & Redis)

## 任务目标

将我们在步骤 `8a` 中实现的、基于 FastAPI `BackgroundTasks` 的异步处理，升级为使用 `Celery` 和 `Redis` 的、真正健壮且可独立扩展的生产级后台任务系统。

## 提示词 (Prompt)

"我们的应用现在需要处理更重的负载并保证任务不丢失。是时候用行业标准的 Celery 来替换内置的后台任务了。请执行以下重构：

1.  将 `celery` 和 `redis` 添加到项目的依赖中。

2.  在 `quivr_clone/` 目录下创建一个新文件 `celery_app.py`。在这里，你需要：
    *   初始化一个 `Celery` 应用实例。
    *   配置 Celery 使用 Redis 作为其消息中间件（Broker）和结果后端（Backend）。这些配置（如 Redis 的 URL）应从我们的 `CoreConfig` 中读取。

3.  在 `main.py` 所在的目录或一个专门的 `tasks.py` 文件中，将被 `@celery_app.task` 装饰器修饰的 `process_uploaded_file` 函数定义为一个 Celery 任务。

4.  重构 `main.py` 中的 `POST /upload` 端点：
    *   移除所有与 `BackgroundTasks` 和内存任务状态字典相关的代码。
    *   在接收到文件后，调用 `.delay()` 方法来异步执行 Celery 任务，例如 `process_uploaded_file.delay(file_content, file_name)`。
    *   Celery 任务的 `delay()` 方法会返回一个 `AsyncResult` 对象，其中包含 `task_id`。将这个 `task_id` 返回给客户端。

5.  重构 `GET /upload/status/{task_id}` 端点：
    *   现在，你需要使用 `Celery` 的 `AsyncResult(task_id)` 来从 Redis 结果后端获取任务的真实状态，而不是从内存字典中读取。"

## 测试方法

测试 Celery 的集成需要我们同时运行 API 服务器和 Celery Worker。

**测试计划**：
1.  **环境准备**：
    *   启动一个 Redis 实例（可以使用 Docker `docker run -d -p 6379:6379 redis`）。
    *   在终端中，启动 Celery Worker：`celery -A celery_app.app worker --loglevel=info`。
    *   在另一个终端中，启动 FastAPI 服务器：`uvicorn main:app --reload`。

2.  **手动端到端测试 (`curl`)**:
    *   调用上传接口 `curl -X POST -F "file=@test.txt" http://127.0.0.1:8000/upload`。
    *   你应该立即获得一个包含 `task_id` 的响应。
    *   观察 Celery Worker 的终端，你应该能看到一条日志，显示 Worker 已接收并开始处理该任务。
    *   使用 `curl http://127.0.0.1:8000/upload/status/<your-task-id>` 来查询状态。
    *   **断言**：最终，状态查询接口应返回 `SUCCESS`，并且 Celery Worker 的日志会显示任务已成功完成。

3.  **健壮性测试**：
    *   在 Worker 处理任务的过程中，手动重启 FastAPI 服务器。
    *   **断言**：API 服务器的重启不应影响 Worker 对任务的执行。这验证了任务处理与 API 服务的解耦。 