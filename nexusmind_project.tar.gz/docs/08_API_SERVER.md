# 第 8 步：API 服务接口

## 任务目标

将我们后端实现的强大 RAG 功能通过一个标准的 Web API 暴露出来，使其可以被前端应用或其他服务调用。我们将使用 FastAPI 框架来快速构建这个 API。

## 提示词 (Prompt)

"为了让我们的项目能够被实际使用，我们需要创建一个 API 服务。请使用 FastAPI 来实现这个服务。

1.  在 `quivr_clone/` 的根目录下创建一个新文件 `main.py`。
2.  将 `fastapi` 和 `uvicorn` 添加到项目的依赖中。
3.  在 `main.py` 中，创建一个 FastAPI 应用实例。
4.  实现以下两个 API 端点（Endpoint）：
    *   **`POST /upload`**:
        *   这个端点应该能接收上传的文件（使用 `UploadFile`）。
        *   它的逻辑是：
            1.  将上传的文件保存到 `LocalStorage`。
            2.  创建一个 `QuivrFile` 实例来表示这个文件。
            3.  使用 `ProcessorRegistry` 获取合适的处理器。
            4.  调用处理器的 `process` 方法来处理文件并生成 `Chunk`。
            5.  **注意**：在这一步，你还需要将生成的 `Chunk` 连同其嵌入向量一起存储起来。因为我们还没有真正的向量数据库，你可以将 `Chunk` 和它的嵌入（通过 `LLMEndpoint` 生成）存储在一个简单的内存列表或字典中，以备后续检索使用。
    *   **`POST /chat`**:
        *   这个端点应该接收一个包含 `question` 和 `brain_id` 的 JSON 请求体。
        *   它的逻辑是：
            1.  根据 `brain_id` 加载或创建一个 `Brain` 实例。
            2.  实例化 `QuivrRAG`，并传入该 `Brain`。
            3.  调用 `generate_answer` 方法获取答案。
            4.  返回包含答案的 JSON 响应。

5.  在 `main.py` 的末尾，添加必要的代码以便使用 `uvicorn` 来运行这个 FastAPI 应用。"

## 测试方法

对于 API 端点，最有效的测试方法是模拟客户端请求并验证响应。这可以通过 `curl`、Postman 等工具手动进行，也可以通过专门的测试客户端在自动化测试中完成。

**测试计划**：

1.  **手动测试（使用 `curl`）**：
    *   **启动服务器**：在终端中运行 `uvicorn main:app --reload` 来启动 API 服务器。
    *   **测试文件上传**：
        *   准备一个示例文本文件，例如 `test.txt`。
        *   执行 `curl` 命令：`curl -X POST -F "file=@test.txt" http://127.0.0.1:8000/upload`。
        *   预期服务器返回 `200 OK` 状态码和成功的消息。
    *   **测试聊天接口**：
        *   执行 `curl` 命令：`curl -X POST -H "Content-Type: application/json" -d '{"question": "What is in the document?", "brain_id": "some-uuid"}' http://127.0.0.1:8000/chat`。
        *   预期服务器返回 `200 OK` 状态码，并且响应的 JSON 体中包含一个由 LLM 生成的答案字符串。

2.  **自动化集成测试**：
    *   我们还可以创建一个 `tests/test_api.py` 文件，并使用 `fastapi.testclient.TestClient`。
    *   在测试代码中，我们可以模拟一个完整的用户流程：先通过 `/upload` 端点上传一个文件，然后通过 `/chat` 端点就该文件的内容提问，最后断言返回的答案是否符合预期。这提供了一种无需手动运行 `curl` 的、可重复的端到端测试。 