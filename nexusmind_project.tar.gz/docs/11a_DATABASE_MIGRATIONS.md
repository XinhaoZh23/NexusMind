# 第 11a 步：引入数据库迁移 (Alembic)

## 任务目标

为项目集成 `Alembic`，一个强大的数据库迁移工具。这将使我们能够以编程方式、可版本化的方式管理 PostgreSQL 数据库的结构（schema）变更，是任何生产级应用的关键组成部分。

## 提示词 (Prompt)

"我们的数据库模式现在是手动管理的，这在团队协作和部署中是不可靠的。现在请为项目集成 Alembic 来自动化这个过程：

1.  **添加依赖**: 将 `alembic` 添加到项目的 `pyproject.toml` 文件中，然后运行依赖安装。

2.  **初始化 Alembic**:
    *   在项目的根目录运行命令 `alembic init alembic`。
    *   这个命令会创建一个 `alembic` 目录和一个 `alembic.ini` 配置文件。

3.  **配置 Alembic**:
    *   打开 `alembic.ini` 文件，找到 `sqlalchemy.url` 这一行。
    *   将其修改为从我们的 `CoreConfig` 中读取数据库连接字符串，而不是硬编码。你需要在 `env.py` 中进行配置加载的逻辑。

4.  **配置模型元数据**:
    *   打开 `alembic/env.py` 文件。
    *   找到 `target_metadata = None` 这一行。
    *   修改此文件，使其能够导入你在 `core/quivr_core/models/` 目录下定义的所有 `SQLModel` 模型，并将 `target_metadata` 设置为这些模型的元数据 (`SQLModel.metadata`)。这是让 Alembic 的 `autogenerate` 功能能够检测到模型变更的关键。

5.  **创建第一个迁移脚本**:
    *   运行命令 `alembic revision --autogenerate -m "Create initial tables"`。
    *   **断言**: 命令执行成功后，检查 `alembic/versions/` 目录下是否生成了一个新的 Python 文件。打开它，确认其中包含了创建 `files` 表的 `op.create_table()` 代码。

6.  **应用迁移**:
    *   运行命令 `alembic upgrade head`，将迁移应用到数据库中。"

## 测试方法

Alembic 的测试核心是验证迁移脚本能否正确地在数据库中创建、修改或删除表结构。

**测试计划**:
1.  **应用迁移测试**:
    *   在运行 `alembic upgrade head` 之后。
    *   使用任何数据库客户端（如 `psql` 或 DBeaver）连接到你的 PostgreSQL 开发数据库。
    *   **断言**:
        1.  数据库中出现了一个名为 `alembic_version` 的新表，并且其中有一条记录。
        2.  `files` 表已成功创建，并且其列（`id`, `file_name`, `s3_path`, `status` 等）与你在 `SQLModel` 中定义的完全一致。

2.  **回滚测试（非常重要）**:
    *   运行 `alembic downgrade base` 命令。
    *   再次连接数据库。
    *   **断言**: `files` 表应该已被删除。
    *   再次运行 `alembic upgrade head`。
    *   **断言**: `files` 表应该被重新创建。这个测试证明了你的迁移脚本是可逆的，这对于修复错误的迁移至关重要。

3.  **未来变更测试流程**:
    *   在未来，当你修改了任何 `SQLModel` 模型（比如给 `File` 模型增加一个新列 `created_at`）时，你的工作流程将是：
        1.  运行 `alembic revision --autogenerate -m "Add created_at to files"`
        2.  检查新生成的迁移脚本。
        3.  运行 `alembic upgrade head`。
        4.  连接数据库，断言新列已添加。 