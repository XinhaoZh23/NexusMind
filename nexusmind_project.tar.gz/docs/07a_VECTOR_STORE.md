# 第 7a 步：向量数据库集成

## 任务目标

弥补项目中缺失的关键一环：实现一个真正的向量存储。我们将定义一个向量存储的通用接口，并使用 `faiss-cpu` 这个流行的库来实现一个高效的内存向量数据库。

## 提示词 (Prompt)

"我们之前的 RAG 实现缺少了真正的检索引擎。现在，我们将构建它。请执行以下操作：

1.  将 `faiss-cpu` 添加到项目的依赖中。

2.  在 `core/quivr_core/storage/` 目录下创建一个新文件 `vector_store_base.py`。
3.  在 `vector_store_base.py` 中，定义一个名为 `VectorStoreBase` 的抽象基类。它应包含以下核心抽象方法：
    *   `add_documents(self, chunks: List[Chunk]) -> None`: 接收一个 `Chunk` 列表，为每个 `Chunk` 生成嵌入向量，并将它们添加到向量索引中。
    *   `similarity_search(self, query: str, k: int = 5) -> List[Chunk]`: 接收一个查询字符串，为其生成嵌入向量，然后在索引中执行相似性搜索，返回最相似的 `k` 个 `Chunk`。

4.  在 `core/quivr_core/storage/` 目录下再创建一个新文件 `faiss_vector_store.py`。
5.  在 `faiss_vector_store.py` 中，定义一个名为 `FaissVectorStore` 的类，继承自 `VectorStoreBase`。这个类需要使用 `faiss` 库来维护一个向量索引。它还需要一个 `LLMEndpoint` 实例来生成文本的嵌入向量。
6.  在 `FaissVectorStore` 中具体实现 `add_documents` 和 `similarity_search` 方法。"

## 测试方法

我们将通过单元测试来验证向量数据库的核心功能：添加文档和进行相似性搜索。

**测试计划**：
我们将创建一个新的测试文件 `tests/test_vector_store.py`。

单元测试将覆盖以下场景：
1.  **设置模拟环境**：
    *   创建几个模拟的 `Chunk` 对象，它们有不同的文本内容。
    *   创建一个模拟的 `LLMEndpoint`，其 `get_embedding` 方法对于特定的输入文本会返回预定义的、固定的向量。例如，让 `Chunk1` 的内容向量靠近"猫"的查询向量，而 `Chunk2` 的向量靠近"狗"的查询向量。

2.  **测试添加和搜索**：
    *   实例化 `FaissVectorStore`，并传入模拟的 `LLMEndpoint`。
    *   调用 `add_documents` 方法添加我们创建的模拟 `Chunk`。
    *   调用 `similarity_search` 方法并使用查询"猫"。
    *   断言返回的 `Chunk` 列表是否正确地包含了 `Chunk1`，并且是相似度最高的那个。
    *   对查询"狗"重复此过程，验证返回的是 `Chunk2`。这可以确保我们的添加和检索逻辑是正确的。 