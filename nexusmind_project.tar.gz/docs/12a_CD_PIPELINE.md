# 第 12a 步：建立 CD (持续部署) 流水线

## 任务目标

将现有的 CI 流水线升级为包含持续部署（CD）的完整 CI/CD 流水线。当代码合并到 `main` 分支后，流水线将自动构建 Docker 镜像，将其推送到容器镜像仓库，并自动部署到服务器。

## 提示词 (Prompt)

"我们需要将 `ci.yml` 升级为完整的 CI/CD 工作流。请在现有 CI 作业成功的基础上，添加一个新的 `deploy` 作业：

1.  **触发条件**:
    *   `deploy` 作业只应在 `push` 到 `main` 分支时触发。
    *   `deploy` 作业需要依赖 (`needs`) `build` 和 `test` 作业成功完成。

2.  **容器镜像仓库登录**:
    *   在 `deploy` 作业中，添加一个步骤，使用预先配置好的 `DOCKER_USERNAME` 和 `DOCKER_PASSWORD` 秘密（Secrets）登录到一个容器镜像仓库（例如 Docker Hub 或 GitHub Container Registry）。

3.  **构建并推送镜像**:
    *   构建生产环境的 Docker 镜像。
    *   为镜像打上标签，一个使用 `latest`，另一个使用 Git 提交的 SHA 值 (`${{ github.sha }}`) 以便追溯。
    *   将这两个标签的镜像推送到容器镜像仓库。

4.  **执行部署**:
    *   **（方案A：简单部署）**: 添加一个步骤，使用 `appleboy/ssh-action` 这个 GitHub Action。通过 SSH 连接到你的目标服务器，并执行一个脚本来拉取最新的 Docker 镜像并用 `docker-compose up -d` 重启服务。
    *   **（方案B：高级部署）**: 如果你使用 Kubernetes，这一步将是使用 `kubectl` 或 `helm` 来更新你的 Deployment，将镜像版本指向最新的 Git SHA 标签。

请为方案 A 提供具体的 `yml` 配置示例。"

## 测试方法

CD 流水线的测试直接关系到你的生产（或预生产）环境。

**测试计划**：
1.  **配置 Secrets**:
    *   在你的 GitHub 仓库 "Settings" -> "Secrets and variables" -> "Actions" 中，创建以下几个 Repository secrets:
        *   `DOCKER_USERNAME`: 你的容器仓库用户名。
        *   `DOCKER_PASSWORD`: 你的容器仓库密码或访问令牌。
        *   `SSH_HOST`: 你要部署的服务器 IP 地址或域名。
        *   `SSH_USERNAME`: 登录服务器的用户名。
        *   `SSH_PRIVATE_KEY`: 用于登录服务器的 SSH 私钥。

2.  **触发部署**:
    *   将修改后的 `ci.yml` 文件推送到 `main` 分支（或通过 Pull Request 合并）。
    *   **断言**：导航到 GitHub "Actions" 标签页。CI 步骤应该成功，随后 `deploy` 作业会被触发并执行。
    *   **验证镜像**: 登录你的容器镜像仓库，确认带有 `latest` 和 Git SHA 标签的新镜像已被成功推送。
    *   **验证服务**: SSH 登录到你的目标服务器，或直接访问你的应用 URL。确认服务已经更新到了最新版本。例如，如果你在代码中修改了一个接口的返回文本，新版本应该能立即体现出来。 