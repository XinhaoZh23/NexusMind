# 第 2 步：核心数据实体定义

## 任务目标

定义项目中用于流转和处理的核心数据结构，主要包括代表原始文件的 `QuivrFile` 和代表文件分割后数据块的 `Chunk`。

## 提示词 (Prompt)

"接下来，我们需要定义项目的核心数据实体。这些实体将作为数据在系统内部流转的标准化格式。请执行以下步骤：

1.  在 `core/quivr_core/files/` 目录下创建一个新文件 `file.py`。
2.  在 `file.py` 中，定义一个名为 `QuivrFile` 的 Pydantic 模型。它应该至少包含以下属性：
    *   `file_id`: 唯一标识符（例如 `UUID`）。
    *   `file_name`: 文件名（`str`）。
    *   `file_path`: 文件在存储中的路径（`str`）。
    *   `metadata`: 一个字典，用于存储文件的任意元数据。

3.  在 `core/quivr_core/processor/` 目录下创建一个新文件 `splitter.py`。
4.  在 `splitter.py` 中，定义一个名为 `Chunk` 的 Pydantic 模型。它应该至少包含以下属性：
    *   `chunk_id`: 唯一标识符（`UUID`）。
    *   `document_id`: 所属 `QuivrFile` 的 `file_id`。
    *   `content`: 文本块的内容（`str`）。
    *   `metadata`: 一个字典，用于存储该数据块的元数据（例如，其在原始文档中的页码或位置）。"

## 测试方法

我们将通过单元测试来确保这些核心数据模型能够被正确地创建和使用。

**测试计划**：
我们计划创建一个新的测试文件 `tests/test_quivr_file.py`。在这个文件中，我们将编写单元测试来覆盖以下场景：

1.  **`QuivrFile` 实例化**：测试能否使用有效的模拟数据成功创建一个 `QuivrFile` 的实例，并验证所有属性都被正确赋值。
2.  **`Chunk` 实例化**：测试能否成功创建一个 `Chunk` 的实例，并验证其所有属性都被正确赋值。
3.  **元数据处理**：测试能否在创建 `QuivrFile` 和 `Chunk` 实例时，正确地传入和读取 `metadata` 字典中的键值对。 