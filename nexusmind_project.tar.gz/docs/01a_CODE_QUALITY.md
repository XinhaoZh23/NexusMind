# 第 1a 步：代码质量与自动化

## 任务目标

为项目配置自动化代码格式化与质量检查工具。我们将使用 `black`, `isort`, 和 `flake8`，并通过 `pre-commit` 钩子确保这些检查在每次代码提交前自动运行，从而保证代码库的风格一致性和质量。

## 提示词 (Prompt)

"在正式开始编写大量代码之前，我们需要先建立好代码质量的护栏。请执行以下步骤：

1.  将 `black`, `isort`, `flake8`, 和 `pre-commit` 添加到 `pyproject.toml` 的开发依赖中。

2.  配置 `pyproject.toml` 文件，为 `black` 和 `isort` 提供配置。例如，设置 `black` 的行长限制。

3.  在项目根目录的 `.flake8` 文件中，配置 `flake8` 的规则，可以设置 `max-line-length` 并忽略一些不必要的警告。

4.  在根目录的 `.pre-commit-config.yaml` 文件中，配置 pre-commit 钩子。为 `black`, `isort`, 和 `flake8` 分别创建一个钩子，使其在每次 `git commit` 时运行。

5.  运行 `pre-commit install` 命令，在你的本地 git 仓库中激活钩子。"

## 测试方法

这个步骤的测试非常直观，我们需要验证 pre-commit 钩子是否能正常工作。

**测试计划**：
1.  **准备一个"不合格"的文件**：手动修改一个 Python 文件（例如 `main.py`），在其中故意引入代码风格问题，比如：
    *   使用单引号和双引号混用的字符串。
    *   非常长的、未自动换行的代码行。
    *   混乱的 `import` 顺序。

2.  **尝试提交代码**：
    *   执行 `git add .`。
    *   执行 `git commit -m "Test pre-commit hooks"`。

3.  **观察并断言**：
    *   预期结果：`pre-commit` 会开始运行，并报告 `black`, `isort` 或 `flake8` 检查失败。
    *   `black` 和 `isort` 应该会自动修复文件中的格式问题。
    *   终端会提示你检查修改并重新暂存（`git add`）。
    *   在重新暂存并再次执行 `git commit` 后，所有检查都应通过，提交成功。这个过程验证了我们的自动化质量门禁已经生效。 