# 第 3 步：存储层抽象与实现

## 任务目标

构建一个灵活的、可扩展的存储层，用于处理文件的持久化。我们将首先定义一个通用的存储接口（抽象基类），然后提供一个基于本地文件系统的具体实现。

## 提示词 (Prompt)

"现在，我们要构建项目的存储层。这对于管理上传的文档至关重要。请按照以下步骤操作：

1.  在 `core/quivr_core/storage/` 目录下创建一个新文件 `storage_base.py`。
2.  在 `storage_base.py` 中，定义一个名为 `StorageBase` 的抽象基类（使用 `abc` 模块）。这个类需要定义所有存储实现都必须遵循的接口，至少应包含以下抽象方法：
    *   `save(self, file_path: str, content: bytes) -> None`: 将内容保存到指定的路径。
    *   `get(self, file_path: str) -> bytes`: 从指定路径读取内容。
    *   `delete(self, file_path: str) -> None`: 删除指定路径的文件。
    *   `exists(self, file_path: str) -> bool`: 检查指定路径的文件是否存在。

3.  在 `core/quivr_core/storage/` 目录下再创建一个新文件 `local_storage.py`。
4.  在 `local_storage.py` 中，定义一个名为 `LocalStorage` 的类，它继承自 `StorageBase`。
5.  在 `LocalStorage` 类中，具体实现 `save`, `get`, `delete`, 和 `exists` 四个方法，使其能够在本地文件系统上进行文件的读、写、删除和检查操作。"

## 测试方法

存储层是与外部系统（文件系统）交互的关键部分，因此必须进行彻底的测试。

**测试计划**：
我们将创建一个新的测试文件 `tests/test_storage.py`。在该文件中，我们将利用 Python 的 `tmpdir` 或 `tempfile` 模块来创建一个临时目录，以确保测试不会影响到实际的文件系统且测试之间是隔离的。

单元测试将覆盖以下操作：
1.  **文件保存**：测试调用 `save` 方法后，文件是否确实被创建在临时目录的预期位置，并且内容正确。
2.  **文件存在性检查**：在保存文件后，测试 `exists` 方法对该文件路径返回 `True`，对一个不存在的路径返回 `False`。
3.  **文件读取**：测试 `get` 方法能否正确读取已保存文件的内容，并与原始内容进行比对。
4.  **文件删除**：测试调用 `delete` 方法后，文件是否已从临时目录中被移除，并且 `exists` 方法返回 `False`。 