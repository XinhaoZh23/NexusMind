# 第 12c 步：管理生产环境密钥

## 任务目标

建立一套安全的生产环境密钥管理流程。目标是停止使用 `.env` 文件来管理生产密钥，转而使用 CI/CD 服务提供商（如 GitHub Actions）的加密密钥存储功能，并将密钥作为环境变量在部署时动态注入到应用中。

## 提示词 (Prompt)

"为了提升项目的安全性，我们需要重构密钥管理方式，使其适用于生产环境：

1.  **代码重构**:
    *   检查代码，确保所有敏感信息（例如 `DATABASE_URL`, `OPENAI_API_KEY`, `CELERY_BROKER_URL` 等）都是通过环境变量读取的。
    *   移除或确保 `.env` 文件不会被打包到生产的 Docker 镜像中。在 `.dockerignore` 文件中加入 `.env` 是一个好习惯。
    *   更新项目的配置文件（例如 `quivr_core/config.py`），让它能够优雅地处理缺少 `.env` 文件的情况，完全依赖于运行时环境变量。

2.  **更新 Docker 配置**:
    *   修改 `docker-compose.yml` 或生产环境的部署文件。移除 `env_file` 指令，改为通过 `environment` 指令直接从运行环境中读取变量。这使得配置更加灵活，可以通过外部方式注入变量。
    *   示例 `docker-compose.yml` 修改:
        ```diff
        -    env_file:
        -      - .env
        +    environment:
        +      - OPENAI_API_KEY=${OPENAI_API_KEY}
        +      - DATABASE_URL=${DATABASE_URL}
        +      # ... 其他需要的环境变量
        ```

3.  **配置 CI/CD 流水线**:
    *   在 `ci.yml` 的 `deploy` 作业中，当你通过 SSH 连接到服务器并执行部署命令时，需要将存储在 GitHub Secrets 中的密钥传递给部署脚本。
    *   修改 `appleboy/ssh-action` 的 `script` 部分，在执行 `docker-compose` 命令前，先将从 GitHub Secrets 获取的变量导出为环境变量。
    *   示例 `ci.yml` 中 `ssh-action` 的 `script` 部分:
        ```yaml
        # ...
        with:
          host: ${{ secrets.SSH_HOST }}
          username: ${{ secrets.SSH_USERNAME }}
          key: ${{ secrets.SSH_PRIVATE_KEY }}
          script: |
            # 将从 GitHub Secrets 获取的变量导出为环境变量
            export OPENAI_API_KEY=${{ secrets.OPENAI_API_KEY }}
            export DATABASE_URL=${{ secrets.PROD_DATABASE_URL }}
            # ... 其他需要的环境变量
            
            # 进入项目目录
            cd /path/to/your/project
            
            # 拉取最新镜像并重启服务
            docker-compose pull
            docker-compose up -d --force-recreate
        # ...
        ```
"

## 测试方法

**测试计划**：
1.  **配置 GitHub Secrets**:
    *   在 GitHub 仓库的 "Settings" -> "Secrets and variables" -> "Actions" 中，创建所有你的应用需要的生产环境变量。例如 `OPENAI_API_KEY`，`PROD_DATABASE_URL` 等。

2.  **本地运行（模拟）**:
    *   在本地终端，手动 `export` 所有需要的环境变量，然后运行 `docker-compose up`。**断言**：应用应该能正常启动并运行，这证明了应用可以正确地从环境变量中读取配置。
    *   `unset` 一个必要的环境变量，再次尝试启动。**断言**：应用应该启动失败或在日志中明确报错，说明配置是必需的。

3.  **触发部署**:
    *   将所有修改推送到 `main` 分支以触发 `deploy` 工作流。
    *   **断言**：流水线应该成功执行。检查 `deploy` 作业的日志，确认没有密钥被明文打印出来。
    *   **最终验证**: 访问你部署的应用，测试其核心功能（例如，进行一次 RAG 查询）。**断言**：功能一切正常，证明应用成功获取并使用了通过 CI/CD 注入的密钥。 