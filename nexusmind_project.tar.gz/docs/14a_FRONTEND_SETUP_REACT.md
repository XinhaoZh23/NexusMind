# 第 14a 步：React 前端项目初始化与 UI 库集成

## 任务目标

使用 `Vite` 初始化一个新的 React 前端项目，并集成 `Material-UI (MUI)` 作为我们的 UI 组件库。Vite 提供了极快的冷启动和热更新速度，而 MUI 则提供了丰富、美观、生产级的 React 组件。

## 提示词 (Prompt)

"现在，我们将开始构建用户界面。请为项目创建一个新的 React 应用：

1.  **创建项目目录**:
    *   在项目的根目录下，创建一个名为 `frontend` 的新目录。

2.  **使用 Vite 初始化 React 项目**:
    *   进入 `frontend` 目录。
    *   运行命令 `npm create vite@latest . -- --template react-ts`。
        *   注意后面的 `.`，这表示在当前目录 (`frontend`) 中创建项目。
        *   我们选择 `react-ts` 模板，以使用 TypeScript 来保证代码的健壮性。

3.  **安装依赖**:
    *   在上一步完成后，运行 `npm install` 来安装所有基础依赖。

4.  **安装 Material-UI (MUI) 组件库**:
    *   运行 `npm install @mui/material @emotion/react @emotion/styled` 来安装 MUI 的核心组件。
    *   运行 `npm install @mui/icons-material` 来安装官方的图标库。

5.  **安装 WebSocket 客户端库**:
    *   运行 `npm install socket.io-client`。这是一个非常流行且功能强大的库，用于在 React 应用中轻松地管理 WebSocket 连接。

6.  **项目清理与配置**:
    *   删除 `frontend/src` 目录下由 Vite 自动生成的一些示例文件（如 `App.css`, `assets` 目录等）。
    *   修改 `App.tsx`，移除示例代码，只留下一个简单的 "Hello World" 以供测试。

7.  **配置代理 (重要)**:
    *   打开 `frontend/vite.config.ts` 文件。
    *   在其中添加一个 `server.proxy` 配置，将所有指向 `/api` 的请求代理到后端的 WebSocket 网关 (`http://localhost:8080`)。这可以帮助我们在开发环境中解决跨域问题。

## 测试方法

**测试计划**：
1.  **验证项目结构**:
    *   检查 `frontend` 目录，确认 Vite 项目的典型结构（`index.html`, `src/`, `package.json`, `vite.config.ts` 等）已正确生成。
    *   打开 `package.json`，**断言**：`react`, `react-dom`, `@mui/material`, `socket.io-client` 等核心依赖都已列在其中。

2.  **开发服务器运行测试**:
    *   在 `frontend` 目录下，运行 `npm run dev`。
    *   **断言**：
        1.  Vite 开发服务器应能极快地启动，并在控制台显示出本地访问地址（通常是 `http://localhost:5173`）。
        2.  在浏览器中打开该地址，页面应显示 "Hello World"。

3.  **MUI 组件集成测试**:
    *   临时修改 `frontend/src/App.tsx` 文件。
    *   从 `@mui/material` 中导入一个简单的组件，例如 `Button`，并在页面上使用它 (`<Button variant="contained">Test Button</Button>`)。
    *   **断言**：页面上应能正确渲染出一个具有 Material Design 风格的按钮。这证明 MUI 已成功集成。

4.  **代理配置测试**:
    *   这是一个隐式测试，将在后续的 UI 开发步骤中与 Node.js 网关联调时得到验证。 