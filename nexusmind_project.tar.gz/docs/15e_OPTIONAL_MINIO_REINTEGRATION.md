# 第 15e 步：(可选) 重新集成 Minio 对象存储

## 任务目标

将本地 S3 兼容对象存储服务 `Minio` 重新集成到我们的 Docker Compose 环境中，以恢复并验证完整的文件上传、处理与存储功能。此任务旨在确保在部署到使用云存储（如 AWS S3）的生产环境之前，本地开发环境的功能是完整且健壮的。

## 任务拆解与测试方法

### 任务 1: 恢复 Minio 服务与配置

*   **操作描述**:
    1.  编辑 `docker-compose.yml` 文件，将 `minio` 服务及其完整的配置（包括镜像、端口映射、健康检查、卷和环境变量）重新添加回来。
    2.  同时，将 `minio-data` 卷的定义也重新添加到 `volumes` 部分。

*   **测试方法**:
    1.  **容器健康度测试**:
        *   在项目根目录运行 `docker compose up -d`。
        *   执行 `docker ps`，**断言**: `nexusmind_minio` 容器应处于 `Up` 和 `healthy` 状态。
        *   执行 `docker logs nexusmind_minio`，**断言**: 日志中不应包含任何错误信息。
    2.  **Minio 控制台可访问性测试**:
        *   在浏览器中打开 `http://localhost:9001`。
        *   使用 `docker-compose.yml` 中定义的 `MINIO_ROOT_USER` 和 `MINIO_ROOT_PASSWORD` 登录。
        *   **断言**: 您应该能够成功登录并看到 Minio 的管理界面。

### 任务 2: 更新依赖服务的配置

*   **操作描述**:
    1.  编辑 `docker-compose.yml` 文件。
    2.  在 `nexusmind-api` 和 `worker` 服务的 `environment` 部分，重新添加指向 `Minio` 的所有环境变量 (`MINIO_ENDPOINT`, `MINIO_ACCESS_KEY`, `MINIO_SECRET_KEY`, `MINIO_BUCKET_NAME`)。
    3.  确保 `nexusmind-api` 和 `worker` 服务的 `depends_on` 列表中都包含 `minio`。

*   **测试方法**:
    1.  **容器启动与连接测试**:
        *   运行 `docker compose up --build -d` 来重建并启动服务。
        *   执行 `docker logs nexusmind-api` 和 `docker logs nexusmind-worker`。
        *   **断言**: 两个服务的日志中都不应再出现任何与 `MinioConfig` 或 S3 连接相关的错误。`nexusmind-api` 在启动时，应该能成功创建 S3 客户端。

### 任务 3: 端到端文件上传流程验证

*   **操作描述**:
    *   这是一个综合性测试，验证从前端到后端再到存储的完整链路。

*   **测试方法**:
    1.  **前端上传测试**:
        *   在浏览器中打开 `http://localhost`。
        *   在左侧面板选择或创建一个“大脑”。
        *   点击“上传文件”按钮，选择一个 `.txt` 文件并上传。
        *   **断言-1**: 文件上传成功后，该文件应立即出现在右侧的文件列表中，状态可能为 `PENDING`。
        *   **断言-2**: 稍等片刻后，文件的状态应更新为 `PROCESSED`。
    2.  **对象存储验证**:
        *   登录到 Minio 控制台 (`http://localhost:9001`)。
        *   导航到您在 `docker-compose.yml` 中定义的存储桶（Bucket）。
        *   **断言**: 您应该能在这个存储桶中看到刚刚上传的文件。
    3.  **数据库记录验证**:
        *   规划撰写一个新的数据库集成测试脚本，或使用数据库客户端连接到 PostgreSQL 容器。
        *   执行 SQL 查询 `SELECT * FROM file WHERE file_name = 'your_uploaded_file.txt';`。
        *   **断言**: 查询应返回一条记录，其 `s3_path` 和 `status` 字段都应为正确的值。
    4.  **Celery Worker 处理验证**:
        *   执行 `docker logs nexusmind_worker`。
        *   **断言**: 您应该能在日志中看到关于接收到 `process_file` 任务并成功处理该文件的记录。 