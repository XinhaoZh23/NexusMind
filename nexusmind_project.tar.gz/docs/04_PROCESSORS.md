# 第 4 步：文档处理器

## 任务目标

建立一个可扩展的文档处理框架。该框架应能根据文件类型选择合适的解析器，将文件内容提取出来，并使用分割器将其切分成标准化的 `Chunk` 对象。

## 提示词 (Prompt)

"在这一步，我们将构建文档处理的核心逻辑。这个系统需要能够接收一个文件，然后输出一系列的 `Chunk` 对象。请按以下步骤实现：

1.  在 `core/quivr_core/processor/` 目录下创建一个新文件 `processor_base.py`。
2.  在 `processor_base.py` 中，定义一个名为 `ProcessorBase` 的抽象基类。它应该定义一个核心方法 `process(self, file: QuivrFile) -> List[Chunk]`，该方法接收一个 `QuivrFile` 对象，返回一个 `Chunk` 列表。

3.  在 `core/quivr_core/processor/implementations/` 目录下创建一个新文件 `simple_txt_processor.py`。
4.  在 `simple_txt_processor.py` 中，定义一个名为 `SimpleTxtProcessor` 的类，它继承自 `ProcessorBase`。这个类专门用于处理纯文本（`.txt`）文件。在 `process` 方法的实现中，它应该读取文件内容，并可以按行或按固定字符数将其分割成多个 `Chunk` 对象。

5.  在 `core/quivr_core/processor/` 目录下创建一个新文件 `registry.py`。
6.  在 `registry.py` 中，实现一个 `ProcessorRegistry` 类。该类作为一个注册表，负责维护文件扩展名（如 `.txt`）到其对应处理器（如 `SimpleTxtProcessor` 实例）的映射。它应该提供两个方法：
    *   `register_processor(self, file_extension: str, processor: ProcessorBase)`: 注册一个处理器。
    *   `get_processor(self, file_path: str) -> ProcessorBase`: 根据给定的文件路径（通过其扩展名）返回合适的处理器实例。"

## 测试方法

我们将分别测试处理器和注册表的功能，以确保文档处理流水线的正确性。

**测试计划**：

1.  **针对 `SimpleTxtProcessor` 的测试**：
    *   创建一个新文件 `tests/processor/test_simple_txt_processor.py`。
    *   在测试中，创建一个临时的 `.txt` 文件并写入几行示例文本。
    *   创建一个 `QuivrFile` 对象指向这个临时文件。
    *   将该对象传递给 `SimpleTxtProcessor` 的 `process` 方法。
    *   断言返回的 `Chunk` 列表的长度是否符合预期，并检查每个 `Chunk` 的 `content` 是否正确。

2.  **针对 `ProcessorRegistry` 的测试**：
    *   创建一个新文件 `tests/processor/test_registry.py`。
    *   在测试中，实例化 `ProcessorRegistry` 和 `SimpleTxtProcessor`。
    *   调用 `register_processor` 方法，将 `.txt` 扩展名与 `SimpleTxtProcessor` 实例关联起来。
    *   调用 `get_processor` 方法并传入一个文件名如 `document.txt`。
    *   断言返回的对象是否是我们刚刚注册的 `SimpleTxtProcessor` 实例。
    *   测试当请求一个未注册的扩展名时，系统是否能优雅地处理（例如，抛出一个特定的异常）。 