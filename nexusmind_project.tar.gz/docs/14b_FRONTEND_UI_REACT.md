# 第 14b 步：React 界面开发与 WebSocket 集成

## 任务目标

使用 React 和 Material-UI (MUI) 组件，在 `frontend/src` 目录下开发一个功能完整、界面美观的聊天应用。应用的核心功能是通过 WebSocket 与 Node.js 网关进行实时通信，实现文件上传和问答。

## 提示词 (Prompt)

"现在，请在 `frontend` 项目中实现完整的用户界面和交互逻辑：

1.  **组件化布局**:
    *   在 `src` 目录下创建 `components` 文件夹。
    *   设计并创建至少三个核心组件：
        *   `Layout.tsx`: 使用 MUI 的 `Box`, `AppBar`, `Drawer` 等组件，搭建包含顶部导航栏、侧边栏和主内容区的基础页面布局。
        *   `ChatHistory.tsx`: 用于渲染聊天消息列表。每条消息（来自用户或机器人）都是一个独立的、样式精美的 `Paper` 或 `Card` 组件。
        *   `MessageInput.tsx`: 包含一个 `TextField` 用于输入问题和一个 `IconButton` (例如发送图标) 用于提交。

2.  **状态管理 (React Hooks)**:
    *   在主应用组件（如 `App.tsx`）中，使用 `useState` 来管理核心状态，包括：
        *   聊天历史记录 (`messages`)
        *   文本输入框的当前值 (`inputValue`)
        *   WebSocket 连接状态 (`isConnected`)

3.  **WebSocket 连接逻辑**:
    *   创建一个自定义 Hook（例如 `useWebSocket.ts`）或一个服务类来封装 `socket.io-client` 的逻辑。
    *   使用 `useEffect` Hook 在应用加载时建立到 `ws://localhost:8080` 的 WebSocket 连接。
    *   设置事件监听器：
        *   `connect`: 连接成功时，更新 `isConnected` 状态，并在 UI 上给出提示。
        *   `disconnect`: 连接断开时，进行提示和可能的重连尝试。
        *   `message`: 收到来自服务器（Node.js 网关）的消息时，将其追加到 `messages` 数组中，触发界面自动更新。

4.  **实现核心交互**:
    *   **发送消息**: 当用户在 `MessageInput` 组件中点击发送按钮时，调用 WebSocket 的 `emit` 或 `send` 方法，将输入框的内容以 JSON 格式发送给 Node.js 网关。
    *   **文件上传**:
        *   在侧边栏中添加一个 MUI 的 `Button` 和一个隐藏的 `<input type="file" />`。
        *   当用户选择文件后，使用 `axios` 或 `fetch` API，将文件 `POST` 到 FastAPI 的 `/upload` 端点 (例如 `http://localhost:5001/upload`)。
        *   **注意**: 文件上传仍然通过传统的 HTTP POST 请求，而不是 WebSocket。
        *   显示上传进度和成功/失败的状态。

## 测试方法

**测试计划**：
1.  **启动完整的开发环境**:
    *   你需要同时运行三个服务：
        1.  `docker-compose up api-server worker ...` (启动 FastAPI 后端及依赖)
        2.  在 `websocket_gateway` 目录运行 `npm run dev` (启动 Node.js 网关)
        3.  在 `frontend` 目录运行 `npm run dev` (启动 React 开发服务器)

2.  **组件独立测试 (Storybook - 可选但推荐)**:
    *   对于 `ChatHistory` 和 `MessageInput` 等纯 UI 组件，可以引入 `Storybook` 来独立地、在隔离环境中进行开发和测试。
    *   为每个组件编写 "stories"，分别测试它们在不同 props（例如，不同长度的消息，不同用户类型）下的渲染表现。
    *   **断言**: 每个组件的行为和外观都符合预期。

3.  **端到端手动测试**:
    *   在浏览器中打开 React 应用 (`http://localhost:5173`)。
    *   **连接测试**:
        *   **断言**: 页面加载后，应显示“已连接”状态，并且 Node.js 网关的控制台应打印连接日志。
    *   **上传测试**:
        *   通过 UI 上传一个文件。
        *   **断言**: UI 应显示上传成功，并且 FastAPI 和 Celery 的日志应显示文件正在被正确处理。
    *   **聊天测试**:
        *   在输入框中输入一个问题并发送。
        *   **断言**:
            1.  你输入的消息应立刻出现在聊天记录中。
            2.  随后，由机器人返回的回答应以**流式**的方式逐字出现在一个新的聊天气泡中。
            3.  整个交互过程应流畅，无卡顿。这证明了从 `React -> Node.js -> FastAPI -> LLM -> FastAPI -> Node.js -> React` 的完整实时数据链路是通畅且高效的。 