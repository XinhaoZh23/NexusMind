# 第 6 步：核心智能体（Brain）构建

## 任务目标

构建项目的中央控制单元，我们称之为"Brain"。Brain 负责管理和协调其他组件（如 LLM、存储、向量数据库等），维护对话历史，并最终驱动整个 RAG 流程。它也是状态持久化的核心。

## 提示词 (Prompt)

"在这一步，我们将构建项目的大脑——`Brain` 类。这个类是所有功能的核心协调者。请按以下步骤操作：

1.  在 `core/quivr_core/brain/brain.py` 文件中，定义一个名为 `Brain` 的类。

2.  `Brain` 类的 `__init__` 方法应该接收并存储配置信息，例如 `brain_id`、`model`、`temperature` 等。它还应该初始化一些状态属性，比如 `history`（一个用于存储对话历史的列表）。

3.  在 `core/quivr_core/brain/` 目录下创建一个新文件 `serialization.py`。
4.  在 `serialization.py` 中，实现两个函数：
    *   `save_brain(brain: Brain)`: 接收一个 `Brain` 实例，将其当前的状态（包括 `brain_id`、配置、历史记录等）序列化并保存到文件中（例如，一个 JSON 文件）。文件的命名可以与 `brain_id` 相关联。
    *   `load_brain(brain_id: UUID) -> Brain`: 接收一个 `brain_id`，从对应的文件中读取数据，并重建一个 `Brain` 实例。

5.  在 `Brain` 类中，添加对这些序列化函数的调用方法，例如 `save()` 和 `load()`。"

## 测试方法

`Brain` 的核心功能之一是状态管理和持久化。我们的测试将重点验证这一能力。

**测试计划**：
我们将创建一个新的测试文件 `tests/test_brain.py`。测试将围绕 `Brain` 的创建、状态变更和持久化展开。

单元测试将覆盖以下场景：
1.  **Brain 初始化**：测试能否成功创建一个 `Brain` 实例，并验证其初始状态（如 `history` 为空）是否正确。
2.  **状态变更**：向 `Brain` 实例的 `history` 列表中添加一些模拟的对话条目，并验证 `history` 的内容是否已按预期更新。
3.  **保存与加载**：
    *   创建一个 `Brain` 实例并更改其状态（例如，添加对话历史）。
    *   调用 `save_brain` 函数将其保存。
    *   使用 `load_brain` 函数和相同的 `brain_id` 加载它，得到一个新的 `Brain` 实例。
    *   断言新的 `Brain` 实例的状态（特别是 `history`）与保存前的原始实例的状态完全一致。这将验证我们的序列化和反序列化逻辑是否无损。 