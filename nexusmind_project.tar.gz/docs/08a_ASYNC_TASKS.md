# 第 8a 步：异步任务处理

## 任务目标

将文件上传和处理的流程从同步操作重构为异步后台任务。这可以防止 API 请求因处理时间过长而超时，极大地提升用户体验和系统的健壮性。

## 提示词 (Prompt)

"当前的文件上传接口是同步的，对于大文件处理会阻塞并超时。我们需要将其改造为异步任务。请使用 FastAPI 内置的 `BackgroundTasks` 来实现：

1.  重构 `main.py` 中的 `POST /upload` 端点。
2.  创建一个新的函数，例如 `process_uploaded_file(file_content: bytes, file_name: str)`，将原来在 `upload` 端点中的所有耗时逻辑（保存、处理、生成嵌入）都移动到这个新函数中。
3.  在 `POST /upload` 端点中：
    *   接收上传的文件。
    *   生成一个唯一的 `task_id` (例如，使用 `uuid.uuid4()`)。
    *   将 `process_uploaded_file` 函数及其所需参数添加为一个后台任务。
    *   **立即**向客户端返回 `202 Accepted` 状态码，响应体中包含这个 `task_id`。
4.  为了让客户端能够查询任务状态，你需要实现一个简单的内存状态追踪机制。例如，一个全局字典 `TASK_STATUSES = {}`。在任务开始时设置 `TASK_STATUSES[task_id] = "PENDING"`，在 `process_uploaded_file` 函数的开头更新为 `PROCESSING`，在成功结束时更新为 `SUCCESS`，在发生异常时更新为 `FAILURE`。
5.  创建一个新的端点 `GET /upload/status/{task_id}`，它从 `TASK_STATUSES` 字典中读取并返回指定任务的当前状态。"

## 测试方法

我们将通过模拟客户端与 API 的完整交互来测试这个异步流程。

**测试计划**：
1.  **启动 API 服务器**。
2.  **使用 `curl` 调用上传接口**:
    ```bash
    curl -X POST -F "file=@test.txt" http://127.0.0.1:8000/upload
    ```
    *   **断言**：这个命令应该几乎立刻返回一个 `202 Accepted` 响应，并且响应体中包含一个 JSON 对象，如 `{"task_id": "some-uuid-string"}`。记下这个 `task_id`。

3.  **使用 `curl` 轮询状态接口**:
    *   立即查询状态：
        ```bash
        curl http://127.0.0.1:8000/upload/status/<your-task-id>
        ```
        *   **断言**：响应可能是 `{"status": "PENDING"}` 或 `{"status": "PROCESSING"}`。
    *   等待几秒钟后再次查询。
        *   **断言**：最终，响应应该是 `{"status": "SUCCESS"}`。

4.  **自动化测试 (`TestClient`)**：在 `tests/test_api.py` 中，可以编写一个测试用例，它先调用上传接口，然后在一个循环中轮询状态接口，直到状态变为 `SUCCESS` 或超时，以此来自动验证整个流程。 