# 第 13a 步：Node.js 网关服务初始化

## 任务目标

创建一个新的 Node.js 项目，作为实时 WebSocket 网关。此任务包括初始化项目、安装必要的依赖，并建立基本的项目结构。

## 提示词 (Prompt)

"我们需要为项目创建一个新的微服务：一个基于 Node.js 的 WebSocket 网关。请执行以下操作来初始化该服务：

1.  **创建项目目录**:
    *   在项目的根目录下，创建一个名为 `websocket_gateway` 的新目录。

2.  **初始化 Node.js 项目**:
    *   进入 `websocket_gateway` 目录，并运行 `npm init -y` 命令。
    *   这将创建一个默认的 `package.json` 文件。

3.  **安装核心依赖**:
    *   运行 `npm install` 命令，一次性安装以下核心库：
        *   `express`: 用于创建基础的 HTTP 服务器。
        *   `ws`: 一个高性能、易于使用的 WebSocket 库，用于处理实时连接。
        *   `axios`: 用于在 Node.js 服务和后端的 FastAPI 服务之间进行可靠的 HTTP 通信。
        *   `cors`: 用于处理跨域资源共享问题。

4.  **安装开发依赖**:
    *   运行 `npm install --save-dev` 命令，安装 `nodemon`。
    *   `nodemon` 将在开发过程中自动监视文件变化并重启服务器，极大地提升开发效率。

5.  **配置启动脚本**:
    *   打开 `package.json` 文件。
    *   在 `scripts` 部分，添加一个 `start` 脚本用于生产环境 (`"start": "node index.js"`) 和一个 `dev` 脚本用于开发环境 (`"dev": "nodemon index.js"`)。

6.  **创建入口文件**:
    *   在 `websocket_gateway` 目录下，创建一个新的、空的 JavaScript 文件，命名为 `index.js`。"

## 测试方法

**测试计划**：
1.  **验证目录和文件结构**:
    *   检查项目根目录，确认 `websocket_gateway` 目录已被创建。
    *   检查 `websocket_gateway` 目录内部，**断言**：`package.json`, `package-lock.json` 和 `node_modules` 目录以及 `index.js` 文件都已存在。

2.  **验证 `package.json` 配置**:
    *   打开 `websocket_gateway/package.json` 文件。
    *   **断言**：
        1.  `dependencies` 部分应包含 `express`, `ws`, `axios`, `cors`。
        2.  `devDependencies` 部分应包含 `nodemon`。
        3.  `scripts` 部分应包含 `start` 和 `dev` 脚本。

3.  **初步运行环境测试**:
    *   在 `index.js` 文件中添加几行最简单的服务器启动代码（例如，只启动一个 Express 服务器并监听端口）。
    *   在 `websocket_gateway` 目录下，运行 `npm run dev`。
    *   **断言**：
        1.  Nodemon 应该成功启动服务器，并且没有报错。
        2.  控制台应显示服务器正在监听指定端口的日志消息。
        3.  修改并保存 `index.js` 文件。
        4.  **断言**：Nodemon 应该能检测到变化并自动重启服务器。这证明整个开发环境已正确配置。 