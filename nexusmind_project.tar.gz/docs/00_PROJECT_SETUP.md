# 第 0 步：项目基础架构搭建

## 任务目标

为我们的项目 `quivr_clone` 搭建基础的目录结构和初始配置文件。这是一个纯粹的结构性任务，为后续所有代码的存放位置提供规范。

## 提示词 (Prompt)

"你好，我们的第一个任务是为即将开始的项目 `quivr_clone` 建立标准的目录结构。请严格按照以下规划在根目录下创建文件夹和文件：

```
quivr_clone/
├── .gitignore
├── .pre-commit-config.yaml
├── core/
│   └── quivr_core/
│       ├── __init__.py
│       ├── brain/
│       │   └── __init__.py
│       ├── files/
│       │   └── __init__.py
│       ├── llm/
│       │   └── __init__.py
│       ├── processor/
│       │   ├── __init__.py
│       │   └── implementations/
│       │       └── __init__.py
│       ├── rag/
│       │   └── __init__.py
│       ├── storage/
│       │   └── __init__.py
│       └── base_config.py
├── docs/
├── examples/
├── pyproject.toml
├── README.md
└── tests/
    ├── __init__.py
    └── processor/
        └── __init__.py
```

请确保所有 `__init__.py` 文件都被创建，但保持内容为空。其他文件如 `.gitignore`, `pyproject.toml` 和 `README.md` 也暂时创建为空文件即可。"

## 测试方法

这个阶段的成果是纯粹的目录和文件结构，因此测试方法也很直接。

**测试指令**：
当上述任务完成后，请在 `quivr_clone` 的父目录执行 `ls -R quivr_clone` (Linux/macOS) 或 `tree /F quivr_clone` (Windows) 命令。然后，仔细核对命令的输出，确保其与提示词中要求的目录结构完全一致。 