# 第 12b 步：实现应用监控与告警

## 任务目标

为我们的 FastAPI 应用集成基本的监控和可观测性能力。这包括一个健康检查端点，以及通过 Prometheus 和 Grafana 实现的性能指标监控。

## 提示词 (Prompt)

"为了在生产环境中监控我们的应用，我们需要实现以下功能：

1.  **健康检查端点**:
    *   在 FastAPI 应用 (`main.py` 或你的 API router 中) 添加一个新的路由 `/health`。
    *   这个端点应该非常简单，只返回一个 HTTP 200 OK 状态码和一个 JSON 响应，例如 `{"status": "ok"}`。这用于外部服务（如负载均衡器或 uptime 监控器）检查应用是否正在运行。

2.  **暴露 Prometheus 指标**:
    *   将 `starlette-exporter` 这个库添加到你的项目依赖中 (`poetry add starlette-exporter`)。
    *   在 FastAPI 的中间件 (middleware) 中，集成 `starlette-exporter`，让它在 `/metrics` 路径上自动暴露一系列标准的性能指标（如请求延迟、请求总数、错误数等）。

3.  **设置监控基础设施**:
    *   在项目根目录创建一个 `docker-compose.monitoring.yml` 文件。
    *   在该文件中，定义两个新的服务：`prometheus` 和 `grafana`。
    *   **Prometheus 服务**:
        *   使用官方的 `prom/prometheus` 镜像。
        *   创建一个 `prometheus.yml` 配置文件，将其挂载到容器中。这个配置文件需要包含一个抓取任务（scrape job），用于定期从我们的 FastAPI 应用的 `/metrics` 端点拉取数据。请注意，在 Docker 网络中，Prometheus 需要通过 `host.docker.internal:8000` 或服务名 `api:8000` 来访问 API 服务，而不是 `localhost`。
    *   **Grafana 服务**:
        *   使用官方的 `grafana/grafana` 镜像。
        *   将 Grafana 服务暴露在 `3000` 端口。
        *   可以预先配置一个数据源，使其自动连接到 `prometheus` 服务。
        *   （可选）可以预先配置一个仪表盘（Dashboard）的 JSON 文件，用于可视化 `/metrics` 端点收集到的关键指标。"

## 测试方法

**测试计划**：
1.  **启动所有服务**:
    *   使用命令 `docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up --build` 同时启动应用和监控服务。
2.  **验证端点**:
    *   在浏览器或使用 `curl` 访问 `http://localhost:8000/health`。**断言**：应返回 `{"status": "ok"}` 和 200 状态码。
    *   访问 `http://localhost:8000/metrics`。**断言**：应返回一个文本格式的、符合 Prometheus 规范的指标列表。
3.  **配置并验证 Grafana**:
    *   访问 `http://localhost:3000` 打开 Grafana。默认用户名/密码通常是 `admin`/`admin`。
    *   **断言**：你应该能成功登录。
    *   导航到 "Connections" -> "Data sources"，确认 Prometheus 数据源已存在且连接正常。
    *   导航到 "Dashboards"，创建一个新的仪表盘。添加一个图表（Panel），选择 Prometheus 作为数据源，然后在查询（query）字段中输入一个指标名称（例如 `starlette_requests_total`）。
    *   **断言**：图表上应该能显示出数据。可以向你的 API 发送一些请求，观察图表上的数据变化，以确认整个监控链路是通的。 