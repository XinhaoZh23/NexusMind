# 第 5 步：大语言模型（LLM）集成

## 任务目标

构建一个与大语言模型（LLM）交互的抽象层。这个抽象层将封装调用不同 LLM 提供商（如 OpenAI, Anthropic 等）的复杂性，为上层应用提供统一、简洁的调用接口。

## 提示词 (Prompt)

"现在，我们需要集成项目与大语言模型（LLM）对话的能力。为了保持灵活性，我们将创建一个统一的端点来处理与各种 LLM 的交互。请执行以下操作：

1.  在 `core/quivr_core/llm/llm_endpoint.py` 文件中，定义一个名为 `LLMEndpoint` 的类。这个类将作为与 LLM 交互的主要接口。

2.  为了支持多个 LLM 提供商而无需为每个提供商编写不同的代码，我们将使用 `litellm` 这个库。请将 `litellm` 添加到项目的依赖中。

3.  `LLMEndpoint` 类应该在其 `__init__` 方法中接收必要的配置，比如 `model`（模型名称）、`api_key`、`temperature` 等。

4.  在 `LLMEndpoint` 类中实现以下两个核心方法：
    *   `get_chat_completion(self, messages: list) -> str`: 接收一个符合 OpenAI 格式的消息列表，并调用 `litellm.completion` 来获取模型的文本响应。
    *   `get_embedding(self, text: str) -> List[float]`: 接收一段文本，并调用 `litellm.embedding` 来获取其对应的向量表示（嵌入）。

5.  确保在方法中妥善处理可能的 API 错误，并可以进行重试。"

## 测试方法

直接调用 LLM API 会产生费用且速度较慢，不适合在常规单元测试中执行。因此，我们将使用"模拟（Mocking）"技术来测试 `LLMEndpoint`。

**测试计划**：
我们将创建一个新的测试文件 `tests/test_llm_endpoint.py`。在该文件中，我们将使用 `unittest.mock` 库中的 `patch` 功能来模拟 `litellm.completion` 和 `litellm.embedding` 函数的行为。

测试将覆盖以下场景：
1.  **聊天补全调用测试**：
    *   模拟 `litellm.completion`，使其在被调用时返回一个预设的、格式正确的响应对象。
    *   调用 `LLMEndpoint` 实例的 `get_chat_completion` 方法。
    *   断言 `litellm.completion` 是否被以正确的参数（如 `model`, `messages`）调用了一次。
    *   断言我们的方法是否能正确解析模拟的响应并返回期望的文本内容。

2.  **嵌入生成调用测试**：
    *   模拟 `litellm.embedding`，使其返回一个预设的向量（浮点数列表）。
    *   调用 `LLMEndpoint` 实例的 `get_embedding` 方法。
    *   断言 `litellm.embedding` 是否被以正确的参数（如 `model`, `input`）调用。
    *   断言我们的方法返回的向量是否与模拟的向量一致。

3.  **API 异常处理测试**：
    *   模拟 `litellm.completion`，使其在被调用时抛出一个 API 异常。
    *   调用 `get_chat_completion` 方法，并断言我们的代码是否能捕获这个异常并按预期逻辑处理（例如，返回 `None` 或重新抛出一个自定义异常）。 