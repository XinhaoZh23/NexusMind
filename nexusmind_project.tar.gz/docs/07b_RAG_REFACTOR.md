# 第 7b 步：RAG 流水线重构

## 任务目标

将我们在上一步中创建的 `VectorStore` 集成到 `QuivrRAG` 流水线中，用真正的相似性搜索替换掉原来临时的"伪检索"逻辑。

## 提示词 (Prompt)

"现在我们有了一个功能完备的向量数据库，是时候将它集成到我们的核心 RAG 流程中了。请按以下步骤重构现有代码：

1.  修改 `core/quivr_core/brain/brain.py` 中的 `Brain` 类。在它的 `__init__` 方法中，初始化一个 `VectorStore` 实例（例如，`self.vector_store = FaissVectorStore(...)`）。这意味着 `Brain` 现在不仅管理对话历史，还负责管理其对应的知识库。

2.  修改 `core/quivr_core/rag/quivr_rag.py` 中的 `QuivrRAG` 类。
    *   在其 `generate_answer` 方法中，找到之前实现的"伪检索"逻辑。
    *   将其替换为对 `Brain` 的 `vector_store` 进行的真实调用。具体来说，是调用 `self.brain.vector_store.similarity_search(query=question)`。

3.  现在，`Brain` 的序列化和反序列化逻辑也需要更新。修改 `core/quivr_core/brain/serialization.py` 中的 `save_brain` 和 `load_brain` 函数。
    *   在 `save_brain` 中，除了保存 `Brain` 的其他属性外，还需要调用一个方法来保存 `VectorStore` 的状态（例如，保存 FAISS 索引到文件）。
    *   在 `load_brain` 中，相应地也需要加载 `VectorStore` 的状态。"

## 测试方法

这次的测试重点是验证 `QuivrRAG` 是否正确地调用了 `VectorStore`，以及整个流程是否能协同工作。

**测试计划**：
我们将更新 `tests/test_quivr_rag.py` 中的集成测试。

集成测试将覆盖以下流程：
1.  **设置模拟环境**：
    *   创建一个模拟的 `Brain` 对象。
    *   为这个 `Brain` 对象附加一个**模拟的 `VectorStore`** 实例。
    *   配置这个模拟的 `VectorStore`，使其 `similarity_search` 方法在被调用时，返回一个我们预先定义的、包含特定 `Chunk` 的列表。
    *   同时，继续模拟 `LLMEndpoint` 的 `get_chat_completion` 方法。

2.  **执行并验证**：
    *   实例化 `QuivrRAG` 并传入模拟的 `Brain`。
    *   调用 `generate_answer`。
    *   **断言 `VectorStore` 被调用**：使用 `unittest.mock` 来断言 `brain.vector_store.similarity_search` 方法是否被以正确的查询参数调用了一次。
    *   **断言提示词内容**：断言传递给 `LLMEndpoint` 的提示词中，包含的上下文是否与我们模拟的 `VectorStore` 返回的 `Chunk` 内容一致。 