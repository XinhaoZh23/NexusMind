# 第 1 步：配置管理系统

## 任务目标

实现一个强大且灵活的配置管理系统。该系统应能从默认值、环境变量等多个来源加载配置，并为项目的其他部分提供统一的配置访问接口。

## 提示词 (Prompt)

"现在，我们需要为项目构建一个配置管理系统。这个系统将使用 Pydantic 库来定义和验证配置项。请执行以下操作：

1.  在 `core/quivr_core/base_config.py` 文件中，定义一个名为 `BaseConfig` 的类，它继承自 `pydantic.BaseSettings`。这个类将作为所有配置类的基类。

2.  在 `core/quivr_core/` 目录下创建一个新文件 `config.py`。

3.  在 `core/quivr_core/config.py` 文件中，定义一个名为 `CoreConfig` 的类，它继承自我们刚刚创建的 `BaseConfig`。

4.  在 `CoreConfig` 类中，添加至少三个配置项，例如：
    *   `model_name`: 一个字符串类型，默认值为 "gpt-4"。
    *   `temperature`: 一个浮点数类型，默认值为 0.0。
    *   `max_tokens`: 一个整数类型，默认值为 1000。

该配置系统应能自动从环境变量中读取同名变量来覆盖默认值（例如，环境变量 `MODEL_NAME` 会覆盖 `model_name` 的默认值）。"

## 测试方法

配置系统的正确性至关重要，我们将通过单元测试来验证它。

**测试计划**：
我们计划创建一个新的测试文件 `tests/test_config.py`。在该文件中，我们将编写单元测试来验证以下几个关键行为：

1.  **默认值加载**：测试在不设置任何环境变量的情况下，实例化 `CoreConfig` 时，其属性值是否与我们设定的默认值相匹配。
2.  **环境变量覆盖**：测试在启动测试前通过代码设置一个环境变量（例如 `os.environ['MODEL_NAME'] = 'test-model'`），然后实例化 `CoreConfig`，并断言 `model_name` 属性的值是否已成功被环境变量覆盖为 'test-model'。
3.  **类型验证**：测试如果设置一个类型不匹配的环境变量（例如 `MAX_TOKENS=abc`），Pydantic 是否能按预期抛出验证错误。 