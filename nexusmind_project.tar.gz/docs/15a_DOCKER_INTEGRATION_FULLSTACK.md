# 第 14c 步：全栈 Docker 集成与 Nginx 部署

## 任务目标

更新 `docker-compose.yml` 文件，以编排整个全栈应用，包括 FastAPI 后端、Node.js 网关和 React 前端。引入 Nginx 作为反向代理和静态文件服务器，将所有服务整合到一个统一的访问入口下，实现生产级的部署。

## 提示词 (Prompt)

"为了实现一键化部署，我们需要将所有服务整合到 Docker Compose 中，并使用 Nginx 进行统一管理：

1.  **为 Node.js 网关创建 Dockerfile**:
    *   在 `websocket_gateway` 目录下，创建一个 `Dockerfile`。
    *   这个 Dockerfile 应基于一个官方的 Node.js 镜像（如 `node:18-alpine`）。
    *   它需要将 `package.json` 复制到容器中，运行 `npm install`，然后复制所有源代码。
    *   最后的 `CMD` 应该是 `["npm", "start"]`。

2.  **为 React 前端创建生产 Dockerfile**:
    *   在 `frontend` 目录下，创建一个 `Dockerfile.prod` 文件。
    *   这个 Dockerfile 需要使用**多阶段构建 (multi-stage build)**，这是一个关键的优化技巧：
        *   **第一阶段 (build stage)**: 基于 `node:18-alpine` 镜像，复制源代码，运行 `npm install` 和 `npm run build`。这将生成优化的、静态的 HTML/CSS/JS 文件。
        *   **第二阶段 (final stage)**: 基于一个非常轻量的 Nginx 镜像（如 `nginx:1.21-alpine`）。将第一阶段生成的静态文件（位于 `build` 目录）复制到 Nginx 的 HTML 目录下。

3.  **创建 Nginx 配置文件**:
    *   在项目根目录创建一个 `nginx` 文件夹，并在其中创建 `nginx.conf`。
    *   这个配置文件需要实现以下路由逻辑：
        *   `location /`: 默认指向 React 应用的 `index.html`，由 Nginx 提供静态文件服务。
        *   `location /ws/`: **反向代理**所有 WebSocket 请求到 `websocket-gateway` 服务（例如 `http://websocket-gateway:8080`）。需要正确配置 `Upgrade` 和 `Connection` 头，以支持 WebSocket 代理。
        *   `location /api/`: **反向代理**所有 API 请求（如文件上传）到 `api-server` 服务（例如 `http://api-server:5001`）。

4.  **更新 `docker-compose.yml`**:
    *   这是一个核心步骤。你需要重新组织 `docker-compose.yml`，使其包含以下所有服务：
        *   `api-server`: 现有的 FastAPI 服务。
        *   `worker`, `postgres`, `redis`: 现有的依赖服务。
        *   `websocket-gateway`: 新的 Node.js 服务，使用 `websocket_gateway/Dockerfile` 构建。
        *   `nginx`: **新的 Nginx 服务**。它将 `nginx/nginx.conf` 挂载到容器中，并将主机的 `80` 端口映射到容器的 `80` 端口。它需要 `depends_on` `api-server` 和 `websocket-gateway`。

## 测试方法

**测试计划**：
1.  **构建并启动全栈环境**:
    *   在项目根目录运行 `docker-compose up --build`。
    *   **断言**: 所有服务（PostgreSQL, Redis, api-server, worker, websocket-gateway, nginx）都应该无错误地启动。

2.  **通过 Nginx 统一入口进行端到端测试**:
    *   **关键**: 此时，所有交互都应该通过 Nginx 的 `80` 端口进行。
    *   在浏览器中打开 `http://localhost` (不再是 5173 或 8080)。
    *   **断言**: React 应用的界面应该被成功加载。
    *   **上传文件**:
        *   在 UI 上上传文件。打开浏览器的开发者工具（Network 面板），观察请求。
        *   **断言**: 该文件上传请求应该被发送到 `http://localhost/api/upload`，并成功完成。
    *   **进行聊天**:
        *   在 UI 上发送一条聊天消息。
        *   **断言**:
            1.  Network 面板显示一个到 `ws://localhost/ws/` 的 WebSocket 连接已成功建立。
            2.  聊天功能完全正常，可以实时接收到流式响应。
            3.  这个测试证明了 Nginx 成功地将静态文件请求、API 请求和 WebSocket 请求正确地分发到了后端的不同服务，整个生产架构已经完全打通。 