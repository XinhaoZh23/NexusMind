# 第 11 步：升级到生产级数据持久化 (PostgreSQL & S3)

## 任务目标

将项目的存储后端从本地文件系统升级为云原生架构，使用 PostgreSQL 存储元数据，使用 AWS S3 存储原始文件。这为应用提供了高可用性、可扩展性和数据的持久性保障。

## 提示词 (Prompt)

"现在，我们需要让我们的数据存储变得真正健壮。请将所有基于本地文件的存储替换为云服务和专业数据库：

1.  将 `SQLModel` (或 `SQLAlchemy`) 和 `boto3` (AWS SDK for Python) 添加到项目依赖中。

2.  **为 S3 创建一个新的存储实现**:
    *   在 `core/quivr_core/storage/` 目录下创建一个新文件 `s3_storage.py`。
    *   在其中定义一个 `S3Storage` 类，它继承自我们之前定义的 `StorageBase`。
    *   使用 `boto3` 实现 `save`, `get`, `delete`, `exists` 四个方法，使其能够与 AWS S3 存储桶进行交互。S3 的配置（如 bucket name, access key）应从 `CoreConfig` 读取。

3.  **定义数据模型 (ORM)**:
    *   在 `core/quivr_core/` 目录下创建一个新目录 `models`，并在其中创建 `files.py`。
    *   在 `models/files.py` 中，使用 `SQLModel` 定义一个 `File` 模型，它映射到数据库中的 `files` 表。这个模型应包含 `file_name`, `s3_path`, `status` 等字段。

4.  **重构业务逻辑**:
    *   在 `Celery` 的 `process_uploaded_file` 任务中，进行以下修改：
        *   不再将原始文件保存到本地，而是使用 `S3Storage` 将其上传到 S3。
        *   不再将元数据保存在易失的 `Brain` 文件中，而是在任务开始时就创建一个 `File` ORM 对象，并将其状态设置为 `PROCESSING`，然后存入 PostgreSQL 数据库。
        *   任务成功后，将该 `File` 对象的状态更新为 `SUCCESS`。

5.  **更新 API**:
    *   现在 `GET /upload/status/{task_id}` 不仅应返回 Celery 任务状态，还应能从 PostgreSQL 中查询对应文件的持久化状态。"

## 测试方法

这个重构涉及与外部云服务和数据库的交互，测试需要确保连接和操作的正确性。

**测试计划**：
1.  **环境准备**：
    *   使用 Docker Compose 启动一个 PostgreSQL 实例。
    *   你需要一个可用的 AWS S3 存储桶和一个具有访问权限的 IAM 用户凭证。对于本地测试，强烈推荐使用 **MinIO**，这是一个兼容 S3 API 的开源对象存储，可以作为本地 S3 的替代品。

2.  **集成测试 (`pytest`)**:
    *   我们将创建一个新的测试文件 `tests/test_prod_storage.py`。
    *   测试将使用真实的（或通过 MinIO 模拟的）S3 连接和连接到测试数据库。
    *   **测试 S3Storage**: 独立测试 `S3Storage` 类，验证其 `save`, `get`, `delete` 方法是否能在 S3 存储桶中正确地创建和操作对象。
    *   **测试端到端流程**: 编写一个集成测试，它调用 `/upload` API，然后轮询状态，最后断言：
        1.  一个文件对象是否已成功上传到 S3。
        2.  一条记录是否已成功插入到 PostgreSQL 的 `files` 表中。
        3.  该记录的状态最终是否被更新为 `SUCCESS`。

3.  **数据库迁移**:
    *   为了管理数据库结构（schema）的变更，我们需要引入数据库迁移工具。我们将计划在下一步中添加 `Alembic`。现在，可以手动在数据库中创建表以进行测试。 