# 第 14c 步：前端功能增强 - 多“大脑”支持与文件管理

## 任务目标

对现有的 React 前端进行重大功能升级，实现一个支持多“大脑”（Multi-Brain）切换、管理每个大脑内文件，并能进行上下文感知聊天的完整交互界面。这将把应用从一个单一聊天原型，转变为一个功能丰富的知识管理工具。

## 提示词 (Prompt)

"为了让应用更加强大和实用，现在请对前端进行以下三项核心功能增强：

1.  **后端 API 依赖梳理**:
    *   在开始前端开发前，首先确认后端需要提供（或已经提供）以下 API 接口来支撑新功能：
        *   `GET /brains`: 获取所有可用“大脑”的列表。
        *   `POST /brains`: (可选，用于UI创建) 创建一个新的“大脑”。
        *   `GET /brains/{brain_id}/files`: 获取指定“大脑”内的所有文件列表。
        *   `DELETE /files/{file_id}`: 删除一个指定的文件。
    *   确认 `/upload` 和 WebSocket 聊天接口能够接受 `brain_id` 参数，以将操作限定在特定“大脑”的上下文中。

2.  **全局状态与逻辑重构 (`App.tsx`)**:
    *   使用 `useState` 和 `useEffect` 增强全局状态管理，引入：
        *   `brains: Brain[]`: 存储从后端获取的大脑列表。
        *   `currentBrainId: string | null`: 存储当前选中的大脑 ID。
        *   `files: File[]`: 存储当前选中大脑的文件列表。
    *   应用加载时，自动调用 `GET /brains` 获取大脑列表，并默认选中第一个。
    *   创建一个 `selectBrain(brainId)` 函数。当调用时，它会：
        1.  更新 `currentBrainId` 状态。
        2.  调用 `GET /brains/{brain_id}/files` 来获取并更新 `files` 状态。
        3.  （可选）清空当前的聊天记录。

3.  **左侧面板：大脑选择器 (`Layout.tsx`)**:
    *   重构 `Layout.tsx` 中的左侧 `Drawer` 组件。
    *   使用 MUI 的 `List` 和 `ListItemButton` 组件，动态渲染 `brains` 列表。
    *   每个列表项都应显示大脑的名称，并将其 `onClick` 事件绑定到 `selectBrain` 函数。
    *   在列表顶部或底部添加一个“+ 新建大脑”的按钮。点击此按钮应触发对 `POST /brains` 接口的调用，并在成功后刷新大脑列表。

4.  **右侧面板：文件管理器 (新建 `FileExplorer.tsx`)**:
    *   创建一个新的组件 `FileExplorer.tsx`，它将作为右侧边栏。
    *   该组件接收 `files` 数组和 `currentBrainId` 作为 props。
    *   它负责渲染文件列表，每个文件项旁边应有一个“删除”图标按钮。
    *   点击删除按钮会触发一个 API 调用 (`DELETE /files/{file_id}`)，成功后需要刷新文件列表。
    *   将 `FileExplorer.tsx` 集成到 `App.tsx` 的主布局中，可以考虑使用一个固定在右侧的 `Drawer` (variant="permanent")。

5.  **（新）大脑重命名功能 (`Layout.tsx` 与 `RenameBrainDialog.tsx`)**:
    *   **背景**: 为了方便测试和管理，需要一个在前端重命名大脑的功能。
    *   **后端依赖**:
        *   `PUT /brains/{brain_id}`: 创建一个新的端点，接收包含 `name` 的 JSON 请求体，用于更新指定大脑的名称。
    *   **UI 与交互**:
        *   在 `Layout.tsx` 的大脑列表项中，现有名称旁边添加一个“编辑”图标按钮 (`<EditIcon />`)。
        *   创建一个新的 `RenameBrainDialog.tsx` 组件。这是一个由 `Dialog`, `DialogTitle`, `DialogContent`, `TextField`, 和 `DialogActions` 构成的模态对话框。
        *   当用户点击“编辑”按钮时，调用一个在 `App.tsx` 中定义的函数 (例如 `handleOpenRenameDialog`)，传入要重命名的大脑对象，并设置状态以打开对话框。
        *   对话框打开时，其文本输入框应显示当前大脑的名称。
        *   用户在对话框中点击“保存”按钮时，调用另一个在 `App.tsx` 中定义的函数 (例如 `handleRenameBrain`)。
    *   **逻辑实现 (`App.tsx`)**:
        *   `handleRenameBrain` 函数会调用 `PUT /brains/{brain_id}` API。
        *   API 调用成功后，它会更新 `brains` 数组中对应大脑的名称，然后关闭对话框。

6.  **中心聊天区：实现上下文感知的 WebSocket 通信**:
    *   **目标**: 确保所有聊天交互都严格绑定到当前选中的 `currentBrainId`，实现真正的大脑隔离。
    *   **前端 (`useWebSocket.ts` & `App.tsx`)**:
        *   修改 `useWebSocket.ts` 中的 `sendMessage` 函数，使其能够接收 `brainId` 作为参数。
        *   在 `App.tsx` 的 `handleSendMessage` 函数中，调用 `sendMessage` 时，必须将当前的 `currentBrainId` 传递过去。
        *   Payload 示例: `{ "type": "qna", "payload": { "question": "...", "brain_id": "..." } }`
    *   **网关 (`websocket_gateway/index.js`)**:
        *   网关的 `message` 事件监听器需要从客户端发来的 payload 中动态解析出 `brain_id`。
        *   在将请求转发给后端 FastAPI 服务时，必须将这个 `brain_id` 包含在 `POST /chat` 请求的 JSON body 中。
        *   **移除所有硬编码的 `brain_id`**。
    *   **前端状态管理 (`App.tsx`)**:
        *   **目标**: 为每个大脑维护独立的聊天记录，切换大脑时能恢复对应的对话。
        *   **状态重构**: 将 `messages` 状态从 `Message[]` (单一聊天记录) 修改为 `{[brainId: string]: Message[]}` (一个以 brainId 为键，聊天记录数组为值的对象)。
        *   **逻辑修改**:
            *   `handleSelectBrain`: 切换大脑时，根据新的 `brainId` 从状态对象中查找并设置当前要显示的 `messages`。
            *   `addMessage`: 接收到新消息时，应将其添加到当前 `currentBrainId` 对应的聊天记录数组中，并更新整个状态对象。

## 测试方法

**测试计划**:
1.  **启动完整的开发环境**: 确保后端 API、网关和前端开发服务器全部运行。

2.  **端到端手动测试**:
    *   **大脑切换测试**:
        *   **断言**:
            1.  页面加载后，左侧面板正确显示所有大脑。
            2.  点击不同的大脑，右侧的文件列表会相应更新。
            3.  聊天窗口的上下文（或标题）会随之改变。
    *   **文件管理测试**:
        *   选择一个大脑，通过现有的上传功能上传一个新文件。
        *   **断言**: 新文件应立即出现在右侧文件列表中。
        *   点击文件旁的删除按钮。
        *   **断言**: 文件应从列表中消失，并且后端确认文件已被删除。
    *   **上下文隔离与聊天功能测试**:
        *   **场景**:
            1.  启动所有服务，包括 `websocket_gateway`。
            2.  在浏览器中，确认底部的消息输入框处于可用状态（非“Connecting”）。
            3.  创建并选择“大脑A”，上传一份关于“React Hooks”的文档 `react-hooks.txt`。
            4.  创建并选择“大脑B”，上传一份关于“Vue Composition API”的文档 `vue-api.txt`。
            5.  保持在“大脑B”的上下文中，提问：“什么是 `useState`?”。
        *   **断言**:
            1.  LLM 的回答应该是通用的，或者表示不清楚，因为它不应该知道“大脑A”中的内容。
            2.  **日志验证**: 检查 `websocket_gateway` 日志，确认发送给后端的请求中包含了“大脑B”的 `brain_id`。
            3.  切换到“大脑A”，再次提问：“什么是 `useState`?”。
            4.  **断言**: LLM 现在应该能根据 `react-hooks.txt` 的内容，给出非常具体和详细的回答。这证明了前后端的上下文隔离和传递是成功的。
            5.  **日志验证**: 再次检查 `websocket_gateway` 和 `nexusmind-api` 日志，确认请求是针对“大脑A”的 `brain_id` 处理的。 