# 第 14 步 (可选)：模拟生产环境部署 (Kubernetes)

## 任务目标

通过在本地 Kubernetes 环境中部署整个应用，展示您对云原生部署、容器编排和基础设施管理的深刻理解。这并非为了实际投产，而是为了证明您具备将应用推向高可用生产环境的核心技能。

## 提示词 (Prompt)

"为了展示我们将应用部署到现代化、可伸缩集群环境的能力，现在请为项目准备一套完整的 Kubernetes 部署清单。

1.  **安装本地 Kubernetes 工具**: 请确保你已安装 `Minikube` 或 `k3d`，以及 `kubectl` 命令行工具。

2.  **创建部署清单目录**: 在项目根目录下，创建一个名为 `kubernetes/` 的新目录。所有 K8s 相关的 YAML 文件都将存放在这里。

3.  **编写 Kubernetes YAML 清单**: 在 `kubernetes/` 目录下，为应用的每一个组件分别创建 YAML 文件：
    *   `configmap.yaml`: 用于存储所有非敏感的配置信息。
    *   `secrets.yaml`: 用于存储敏感信息，如数据库密码和 API 密钥。**注意**：在模板中应使用 base64 编码的占位符，并将此文件加入 `.gitignore`。
    *   `redis-deployment.yaml`: 包含一个 `StatefulSet` 用于部署 Redis，并附带一个 `Service`。
    *   `postgres-deployment.yaml`: 包含一个 `StatefulSet` 用于部署 PostgreSQL，并附带一个 `Service` 和一个 `PersistentVolumeClaim` 用于数据持久化。
    *   `api-deployment.yaml`: 包含一个 `Deployment` 用于部署 FastAPI 应用，并附带一个 `Service` (类型可以是 `NodePort` 或 `LoadBalancer`)。
    *   `worker-deployment.yaml`: 包含一个 `Deployment` 用于部署 Celery Worker。
    *   `frontend-deployment.yaml`: 包含一个 `Deployment` 和 `Service` 用于部署 Streamlit 前端。

4.  确保所有 `Deployment` 和 `StatefulSet` 都正确地从 `ConfigMap` 和 `Secret` 中引用环境变量。"

## 测试方法

测试 Kubernetes 部署的关键在于验证应用的所有部分是否能在集群中正确启动、互相通信并对外提供服务。

**测试计划**：
1.  **启动本地集群**: 运行 `minikube start` 或 `k3d cluster create` 来创建一个本地 K8s 集群。

2.  **应用部署清单**:
    *   在项目根目录，运行 `kubectl apply -f kubernetes/`。
    *   **断言**: 命令应成功执行，没有 YAML 语法或配置错误。

3.  **验证 Pod 状态**:
    *   持续运行 `kubectl get pods -w`。
    *   **断言**: 等待一段时间后，所有 Pods (postgres, redis, api, worker, frontend) 的状态都应变为 `Running`。

4.  **服务连通性测试**:
    *   使用 `kubectl port-forward svc/<your-frontend-service-name> 8501:8501` 将前端服务的端口转发到本地。
    *   打开浏览器访问 `http://localhost:8501`。
    *   **进行端到端测试**: 像在步骤 13 中一样，通过 UI 上传文件并进行一次完整的问答。
    *   **断言**: 整个流程应该能够成功完成。这次成功将证明你的应用不仅能在 `docker-compose` 环境下工作，更能在一个模拟的、真正分布式的生产环境中协同运行。 