# 第 13a 步：前端环境设置与依赖管理

## 任务目标

为项目添加 Streamlit 前端框架的依赖，并创建前端应用的入口文件。这是构建用户界面的第一步。

## 提示词 (Prompt)

"我们需要为项目集成 Streamlit 框架。请执行以下操作：

1.  **添加依赖**: 使用 `poetry` 将 `streamlit` 和 `requests`（用于在前端和后端之间进行 HTTP 通信）添加到项目的 `pyproject.toml` 文件中。
2.  **创建入口文件**: 在项目的根目录下，创建一个新的、空的 Python 文件，命名为 `app_frontend.py`。这个文件将作为我们 Streamlit 应用的主文件。"

## 测试方法

**测试计划**：
1.  **验证依赖**:
    *   打开 `pyproject.toml` 文件。
    *   **断言**: 检查 `[tool.poetry.dependencies]` 部分，确认 `streamlit` 和 `requests` 已经被添加，并且有指定的版本号。
    *   在终端中运行 `poetry lock`，然后检查 `poetry.lock` 文件是否已更新。
    *   **断言**: `poetry lock` 命令应成功执行，无任何错误。这证明依赖关系是兼容的。

2.  **验证文件创建**:
    *   使用 `ls -l` 或文件浏览器查看项目根目录。
    *   **断言**: 确认 `app_frontend.py` 文件已成功创建。

3.  **初步运行环境测试**:
    *   在 `app_frontend.py` 文件中只添加一行用于测试的代码（例如，一个简单的 `import streamlit as st` 和 `st.title("Test")`）。
    *   在激活了 Poetry 虚拟环境的终端中，运行 `streamlit run app_frontend.py`。
    *   **断言**:
        1.  该命令应无错误地启动一个本地 Web 服务器。
        2.  浏览器应自动打开一个新标签页，地址为 `http://localhost:8501`。
        3.  页面上应显示标题 "Test"。
        4.  这个测试确认了 Streamlit 已正确安装，并且基础应用可以成功运行。测试完成后，可以清空 `app_frontend.py` 以便进行下一步的开发。 