# 第 13c 步：前端与后端的 Docker 集成

## 任务目标

更新 `Dockerfile` 和 `docker-compose.yml` 文件，使 FastAPI 后端服务和 Streamlit 前端应用可以在同一个容器中被管理，或在同一个 Docker Compose 配置下协同工作，并能通过 `docker-compose` 命令一键启动所有服务。

## 提示词 (Prompt)

"为了实现一键部署，我们需要将前端和后端服务整合到我们的 Docker 环境中。请执行以下步骤：

**方案一：单容器，双进程 (推荐)**

1.  **创建启动脚本**:
    *   在项目根目录创建一个名为 `start.sh` 的 shell 脚本。
    *   此脚本需要同时启动两个进程：
        1.  使用 `uvicorn` 启动 FastAPI 后端服务。
        2.  使用 `streamlit run` 启动 Streamlit 前端应用。
    *   确保两个进程都在后台运行，以便脚本可以继续执行。

2.  **修改 Dockerfile**:
    *   将 `start.sh` 脚本复制到 Docker 镜像中。
    *   为 `start.sh` 添加可执行权限 (`RUN chmod +x /path/to/start.sh`)。
    *   将 Dockerfile 的 `CMD` 或 `ENTRYPOINT` 指令修改为执行这个 `start.sh` 脚本。

3.  **修改 docker-compose.yml**:
    *   在 `api-server` 服务的 `ports` 映射中，为 Streamlit 应用添加一个新的端口映射，将容器的 `8501` 端口映射到主机的 `8501` 端口。

**方案二：多容器，独立服务 (备选方案)**

1.  **创建前端 Dockerfile**:
    *   在项目根目录创建一个 `frontend.Dockerfile`。
    *   这个 Dockerfile 基于主 Dockerfile，但其 `CMD` 专门用于启动 Streamlit 应用。

2.  **修改 docker-compose.yml**:
    *   在 `docker-compose.yml` 中，定义一个全新的服务，例如 `frontend-server`。
    *   该服务使用 `frontend.Dockerfile` 进行构建。
    *   为它配置端口映射 `8501:8501`。
    *   确保它依赖于 (`depends_on`) `api-server` 服务。

请优先尝试实现方案一。"

## 测试方法

**测试计划**：
1.  **构建并启动容器**:
    *   在对 Dockerfile 和 docker-compose.yml 做出修改后，从项目根目录运行 `docker-compose up --build --force-recreate`。
    *   **断言**:
        1.  Docker 镜像应成功构建，没有任何错误。
        2.  所有在 `docker-compose.yml` 中定义的服务（api-server, worker, postgres, redis 等）都应成功启动并运行。

2.  **验证服务可访问性**:
    *   **验证后端**:
        *   使用 `curl http://localhost:8000/health` 或在浏览器中访问该地址。
        *   **断言**: 应收到 `{"status": "ok"}` 的成功响应。
    *   **验证前端**:
        *   在浏览器中打开 `http://localhost:8501`。
        *   **断言**: Streamlit 应用的界面应该被成功加载并显示。

3.  **检查容器日志**:
    *   运行 `docker-compose logs -f api-server`（或你定义的服务名称）。
    *   **断言**: 日志中应该能同时看到来自 Uvicorn (FastAPI) 和 Streamlit 的输出。这确认了两个进程都在容器内成功启动。

4.  **端到端功能验证**:
    *   通过访问 `http://localhost:8501` 上的前端界面，完整地执行一次文件上传和问答流程。
    *   **断言**: 整个流程应该和在本地直接运行 `streamlit run` 时一样顺畅。这证明了在 Docker 容器化的环境下，前端和后端的通信是正常的。 