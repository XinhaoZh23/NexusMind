# 第 8b 步：API 安全性与认证

## 任务目标

为所有需要保护的 API 端点添加一层基础的认证机制。我们将实现一个基于 `X-API-Key` 请求头的 API 密钥认证方案。

## 提示词 (Prompt)

"我们的 API 目前是开放的，这在生产环境中是不可接受的。现在，我们将为其添加 API 密钥认证：

1.  首先，更新 `core/quivr_core/config.py` 中的 `CoreConfig` 类，添加一个新的配置项 `api_keys: List[str]`。这将允许我们从环境变量（例如，一个逗号分隔的字符串 `API_KEYS=key1,key2`）中加载一个或多个有效的 API 密钥。

2.  在 `main.py` 中，使用 FastAPI 的安全工具 `fastapi.security.APIKeyHeader` 来定义一个期望从 `X-API-Key` 头中获取密钥的方案。

3.  创建一个名为 `get_api_key` 的依赖项（一个函数）。这个函数需要：
    *   接收从 `X-API-Key` 头中传入的密钥。
    *   从配置中获取有效的 API 密钥列表。
    *   如果传入的密钥不在有效列表中，就抛出一个 `HTTPException`，状态码为 `401 Unauthorized` 或 `403 Forbidden`。
    *   如果密钥有效，函数正常返回。

4.  将这个 `get_api_key` 依赖项应用到所有需要保护的端点上，例如 `POST /upload` 和 `POST /chat`。"

## 测试方法

测试认证逻辑需要我们模拟合法和非法的客户端请求。

**测试计划**：
1.  **启动 API 服务器**，并确保已通过环境变量设置了至少一个有效的 API 密钥。

2.  **使用 `curl` 进行测试**：
    *   **无密钥的请求**：
        ```bash
        curl -X POST ... http://127.0.0.1:8000/chat
        ```
        *   **断言**：服务器必须返回 `401` 或 `403` 错误。

    *   **使用错误密钥的请求**：
        ```bash
        curl -H "X-API-Key: invalid_key" -X POST ... http://127.0.0.1:8000/chat
        ```
        *   **断言**：服务器必须返回 `401` 或 `403` 错误。

    *   **使用正确密钥的请求**：
        ```bash
        curl -H "X-API-Key: <your_valid_key>" -X POST ... http://127.0.0.1:8000/chat
        ```
        *   **断言**：服务器应该返回 `200 OK` 并成功处理请求。

3.  **自动化测试 (`TestClient`)**：在 `tests/test_api.py` 中，编写三个独立的测试用例，分别模拟上述的三种情况（无密钥、错误密钥、正确密钥），并断言响应的状态码是否符合预期。 